package com.firstlogicmetalab.live_to_smile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
