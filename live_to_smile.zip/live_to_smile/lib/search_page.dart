// import 'dart:developer';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bounce/flutter_bounce.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:live_to_smile/bottom_bar/bottomBar.dart';
// import 'package:live_to_smile/session/session.dart';
// import 'package:intl/intl.dart';
// import 'chat/chat.dart';
// import 'core/routing/routing.dart';
//
//
// class SearchPage extends StatefulWidget {
//   const SearchPage({Key? key}) : super(key: key);
//
//   @override
//   State<SearchPage> createState() => _SearchPageState();
// }
//
// class _SearchPageState extends State<SearchPage> {
//   TextEditingController searchController=TextEditingController();
//
//   @override
//   void initState() {
//     searchController=TextEditingController();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey.shade200,
//       body: SafeArea(child: Padding(
//         padding:  EdgeInsets.all(w*0.05),
//         child: Column(
//           children: [
//             Row(
//               children: [
//                 InkWell(
//                     onTap: (){
//                       Navigator.pop(context);
//                     },
//                     child: Icon(Icons.arrow_back)),
//                 SizedBox(width: 10,),
//                 Expanded(
//                   child: TextFormField(
//                     keyboardType: TextInputType.text,
//                     controller: searchController,
//                     autofocus:true,
//                     onChanged: (value){
//                       print(value);
//                       print(searchController.text);
//                       log(searchController.text);
//                       setState(() {
//
//                       });
//                     },
//                     style: GoogleFonts.lexend(
//                         textStyle: const TextStyle(
//                             fontSize: 14,
//                             fontWeight:
//                             FontWeight.normal,
//                             color: Colors.black
//                         )
//                     ),
//                     decoration: InputDecoration(
//                         contentPadding: const EdgeInsets.all(5),
//                         fillColor: Colors.white,
//                         hintText: 'Search previous sessions',
//                         hintStyle: GoogleFonts.lexend(
//                             textStyle: TextStyle(
//                                 fontSize: 14,
//                                 fontWeight:
//                                 FontWeight.normal,
//                                 color: Colors.black
//                                     .withOpacity(
//                                     0.250))
//                         ),
//                         focusedBorder: OutlineInputBorder(
//                             borderRadius:
//                             BorderRadius
//                                 .circular(
//                                 20),
//                             borderSide: const BorderSide(
//                                 color: Color
//                                     .fromRGBO(
//                                     42,
//                                     172,
//                                     146,
//                                     0.0))),
//                         enabledBorder: OutlineInputBorder(
//                             borderRadius:
//                             BorderRadius
//                                 .circular(
//                                 20),
//                             borderSide: const BorderSide(
//                                 color: Color
//                                     .fromRGBO(
//                                     42,
//                                     172,
//                                     146,
//                                     0.0))),
//                         filled: true,
//                         prefixIcon:  Icon(
//                           Icons.search,
//                           color: Colors.grey,
//                           size: 22,
//                         ),
//                         suffixIcon: searchController.text.isNotEmpty
//                             ? InkWell(
//                           onTap: () => setState(
//                                 () => searchController.clear(),
//                           ),
//                           child: const Icon(
//                             Icons.clear,
//                             color: Colors.grey,
//                             size: 22,
//                           ),
//                         )
//                             :null
//                       // border: OutlineInputBorder(
//                       //     borderRadius: BorderRadius.circular(20),
//                       //     borderSide: BorderSide(color: Colors.yellow)),
//                     ),
//
//                   ),
//                 ),
//               ],
//             ),
//             SizedBox(height: 20,),
//             Expanded(
//               child:searchController.text==''?Center(child: Text('Search Previous Sessions Here...',style: GoogleFonts.lexend(),)): Container(
//                 child: StreamBuilder<QuerySnapshot>(
//                   stream: FirebaseFirestore.instance.collection('zoomClass').where('batch',isEqualTo: CurrentUserClassId).where('status',isEqualTo: 1).where('search',arrayContains: searchController.text.toUpperCase())
//                       .orderBy('scheduled',descending: true).snapshots(),
//                   builder: (context, snapshot) {
//                     if(!snapshot.hasData){
//                       return Center(child: CircularProgressIndicator());
//                     }
//                     if(snapshot.data!.docs.isEmpty){
//                       return Center(child: Text('Can\'t find any classes',style: GoogleFonts.lexend(),));
//                     }
//                     List data=snapshot.data!.docs;
//                     return ListView.builder(
//                       itemCount: data.length,
//                       itemBuilder: (context,index){
//                         DateTime date=data[index]['scheduled'].toDate();
//                         String time=formattedTime(date).toString();
//                         return Padding(
//                           padding:  EdgeInsets.only(bottom: w*0.03),
//                           child: Bounce(
//                             duration: Duration(milliseconds: 110),
//                             onPressed: (){
//                               Navigator.push(context, MaterialPageRoute(builder: (context)=>Session(data: data[index],index: index+1<10?'#0${index+1}':'#${index+1}',)));
//                             },
//                             child: Container(
//                               decoration: BoxDecoration(
//                                   color: Colors.white,
//                                   borderRadius: BorderRadius.circular(15)
//                               ),
//                               child: Row(
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Expanded(
//                                     child: Padding(
//                                       padding:  EdgeInsets.all(w*0.05),
//                                       child: Row(
//                                         children: [
//                                           CircleAvatar(
//                                             backgroundColor: back,
//                                             radius: w*0.08,
//                                             backgroundImage: AssetImage('assets/icons/vplay.png'),
//                                           ),
//                                           SizedBox(width: w*0.05,),
//                                           Column(
//                                             crossAxisAlignment: CrossAxisAlignment.start,
//                                             children: [
//                                               Text(data[index]['name'],style: GoogleFonts.lexend(
//                                                   fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.black
//                                               ),),
//                                               SizedBox(height: w*0.005,),
//                                               Text(data[index]['subject'],style: GoogleFonts.lexend(
//                                                   fontWeight: FontWeight.w400,fontSize: w*0.03,color: darkT
//                                               ),),
//                                               SizedBox(height: w*0.005,),
//                                               Text(((date.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
//                                               'Today':(date.toString().substring(0,10)==DateTime.now().add(Duration(days: -1)).toString().substring(0,10))?
//                                               'Yesterday':DateFormat("MMM dd yyyy").format(date))+'  '+time,style: GoogleFonts.lexend(
//                                                   fontWeight: FontWeight.w500,fontSize: w*0.025,color: Color(0xffFA2B3A)
//                                               ),),
//                                               SizedBox(height: w*0.01,),
//                                               Padding(
//                                                 padding:  EdgeInsets.only(
//                                                   left: w*0.003,
//                                                 ),
//                                                 child: Text('by '+tutorMap[data[index]['tutor']]['display_name'],style: GoogleFonts.lexend(
//                                                     fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                                                 ),),
//                                               ),
//                                             ],
//                                           )
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//                                   Container(
//                                     height: w*0.08,
//                                     width: w*0.1,
//                                     decoration: BoxDecoration(
//                                         color: Color(0xffFEDE00),
//                                         borderRadius: BorderRadius.only(
//                                             topRight: Radius.circular(15)
//                                         )
//                                     ),
//                                     child: Center(child: Text(index+1<10?'#0${index+1}':'#${index+1}',style: GoogleFonts.lexend(
//                                         fontWeight: FontWeight.w500,fontSize: w*0.025
//                                     ),)),
//                                   )
//                                 ],
//                               ),
//                             ),
//                           ),
//                         );
//                       },
//                     );
//                   }
//                 ),
//               ),
//             )
//           ],
//         ),
//       )),
//     );
//   }
// }
