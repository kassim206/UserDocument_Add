// import 'dart:io';
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:live_to_smile/core/providers/firebase_providers.dart';
// import '../../../core/common/showuploadmessage.dart';
// import '../../../core/constants/firebaseconstants/firebase_constants.dart';
//
//
// final editProfileRepository=Provider((ref) {
//  return EditProfileRepository(firestore:ref.read(firestoreProvider), storage: ref.read(storageProvider));
// });
//
//
// class EditProfileRepository{
//   final FirebaseFirestore _firestore;
//   final FirebaseStorage _storage;
//
//   EditProfileRepository({
//     required FirebaseFirestore firestore,
//     required FirebaseStorage storage,
//   })
//       : _firestore = firestore,
//   _storage=storage;
//
//   CollectionReference get _edit =>
//       _firestore.collection(FirebaseConstants.userCollection);
//
//
//   UploadTask? uploadTask;
//   List uploadDocument = [];
//   Map <String, dynamic> data = {};
//   Map <String, dynamic> preData = {};
//   String selected = '';
//   Future uploadFileToFireBase(String name, fileBytes, String ext) async {
//     uploadTask = _storage
//         .ref('uploads/${DateTime.now().toString().substring(0, 10)}-$name.$ext')
//         .putData(fileBytes);
//     final snapshot = await uploadTask?.whenComplete(() {});
//     final urlDownlod = await snapshot?.ref.getDownloadURL();
//     print(urlDownlod);
//     print('******************');
//
//     data.addAll({
//       '$name': urlDownlod,
//     });
//     print(data.keys.toList().toString());
//     print('        SUCCESS           ');
//     selected = name + '1';
//
//   }
//
//   final _firebaseStorage = FirebaseStorage.instance;
//   String imageUrl = "";
//   File? file;
//   int imageStatus = 0;
//   pickGellary(BuildContext context) async {
//     final imgfile =
//     await ImagePicker.platform.pickImage(source: ImageSource.gallery);
//     file = File(imgfile!.path);
//     file = File(imgfile.path);
//     DocumentSnapshot id = await _firestore
//         .collection('settings')
//         .doc("O0juQP9oPBfxZveBeWzn")
//         .get();
//     id.reference.update({"image": FieldValue.increment(1)});
//     var imageId = id['image'];
//     imageStatus = 1;
//     showUploadMessage(context, 'Uploading...', showLoading: true);
//     //Upload to Firebase
//     var snapshot = await _firebaseStorage
//         .ref()
//         .child('registerform/$imageId')
//         .putFile(file!);
//     var downloadUrl = await snapshot.ref.getDownloadURL();
//     imageStatus = 2;
//     showUploadMessage(
//       context,
//       'Success',
//     );
//     imageUrl = downloadUrl;
//     file = File(imgfile.path);
//   }
//
//
//   TextEditingController? name;
//   TextEditingController? lastName;
//   String? preName;
//   String? preLastName;
//   String? preImageUrl;
//   bool loading =true;
//   getCandidate() async {
//     // final studentId=ref.read(studentIdProvider);
//
//     DocumentSnapshot student=await _firestore
//         .collection('candidates').doc("studentId").get();
//
//     if(student.exists){
//       name=TextEditingController(text: student.get('name'));
//       preName=student.get('name');
//       preLastName=student.get('lastName');
//       lastName=TextEditingController(text: student.get('lastName'));
//       imageUrl=student.get('photo');
//       preImageUrl=student.get('photo');
//       data=student.get('documents');
//       preData=student.get('documents');
//     }
//
//   }
//   pickFiles() async {
//     final imgfile =
//     await ImagePicker.platform.pickImage(source: ImageSource.camera);
//     file = File(imgfile!.path);
//     file = File(imgfile.path);
//     imageStatus = 1;
//     DocumentSnapshot id = await _firestore
//         .collection('settings')
//         .doc("O0juQP9oPBfxZveBeWzn")
//         .get();
//     id.reference.update({"image": FieldValue.increment(1)});
//     var imageId = id['image'];
//
//     //Upload to Firebase
//     var snapshot = await _firebaseStorage
//         .ref()
//         .child('registerform/$imageId')
//         .putFile(file!);
//     var downloadUrl = await snapshot.ref.getDownloadURL();
//     imageStatus = 2;
//     // setState(() {
//        imageUrl = downloadUrl;
//     // });
//     // if (mounted) {
//     //   setState(() async {
//          file = File(imgfile!.path);
//     //   });
//     // }
//   }
//
// }