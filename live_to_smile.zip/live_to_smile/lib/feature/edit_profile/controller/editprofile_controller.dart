//
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:live_to_smile/feature/edit_profile/repository/editprofile_repository.dart';
//
// import '../../../core/common/showuploadmessage.dart';
// final editProfileConrollerProvider=Provider((ref) {
//   return EditProfileController(editProfileRepository: ref.read(editProfileRepository));
// });
//
// class EditProfileController{
//   final EditProfileRepository _editProfileRepository;
//   EditProfileController({
//     required EditProfileRepository editProfileRepository
// }): _editProfileRepository=editProfileRepository;
//
//
//   uploadFileToFireBase(String name, fileBytes, String ext,BuildContext context){
//     return _editProfileRepository.uploadFileToFireBase(name, fileBytes, ext);
//     showUploadMessage(context, '$name Uploaded Successfully...');
//
//   }
//   pickGellary(BuildContext context){
//     return _editProfileRepository.pickGellary(context);
//   }
//   getCanditate(){
//     return _editProfileRepository.getCandidate();
//   }
//   picFiles(){
//     return _editProfileRepository.pickFiles();
//   }
// }