import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repository/uni_screen_repository.dart';

final getUniCourseProvider=StreamProvider.family((ref,String id) => ref.read(UniScreenControllerProvider).getCourses(id));

final UniScreenControllerProvider=Provider((ref) {
  return UniScreenController(uniScreenRepository: ref.read(UniScreenRepositoryProvider));
});

class UniScreenController{
  final UniScreenRepository _uniScreenRepository;
  UniScreenController({
    required UniScreenRepository uniScreenRepository,
  }):
        _uniScreenRepository=uniScreenRepository;


  Stream<List>getCourses(String id){
    return _uniScreenRepository.getCourses(id);
  }
}