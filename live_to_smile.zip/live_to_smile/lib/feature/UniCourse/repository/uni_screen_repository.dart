import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/firebase_providers.dart';

final UniScreenRepositoryProvider = Provider((ref) {
  return UniScreenRepository(firestore: ref.read(firestoreProvider));
});

class UniScreenRepository {
  final FirebaseFirestore _firestore;

  UniScreenRepository({
    required FirebaseFirestore firestore,
  }) : _firestore = firestore;

  //
  // Map<String, dynamic> courseName = {};

  Stream<List> getCourses(String documentId) {
    return FirebaseFirestore.instance.collection('university').doc(documentId).snapshots().map((data) {
      List a = [];

        if (data.data()?['courseList'].length != 0) {
          for (var doc in data.data()?['courseList']) {
            a.add({
              'university': data['name'],
              'available': doc['available'],
              'courseId': doc['courseId'],
              'duration': doc['feeList'].length,
              'totalFee': doc['totalFee'],
              'feeList': doc['feeList'],
              'eligibility': doc['eligibility'],
              'monthOrYear': doc['monthOrYear'],
              'classDuration': doc['duration']
            });
          }
        }
      return a;
    });
  }
}
