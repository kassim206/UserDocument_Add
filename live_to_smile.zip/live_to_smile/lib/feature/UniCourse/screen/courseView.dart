import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../../registerForm/RegisterForm.dart';

class coursesView extends ConsumerStatefulWidget {
  final dynamic data;
  final String course;
  final String courseId;
  const coursesView(
      {Key? key,
      required this.data,
      required this.course,
      required this.courseId})
      : super(key: key);

  @override
  ConsumerState<coursesView> createState() => _coursesViewState();
}

class _coursesViewState extends ConsumerState<coursesView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.grey.shade200,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.black,
            )),
        title: Text(
          widget.course,
          style: GoogleFonts.lexend(
              fontWeight: FontWeight.w500,
              fontSize: w * 0.045,
              color: Colors.black),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.all(w * 0.05),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20)),
                      child: Padding(
                        padding: EdgeInsets.all(w * 0.05),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  SvgPicture.asset(
                                    'assets/icons/duration.svg',
                                    height: w * 0.04,
                                    color: Colors.red,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    'Duration : ${widget.data['classDuration']} ${widget.data['monthOrYear']}',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w500,
                                        fontSize: w * 0.04,
                                        color: Colors.black),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SvgPicture.asset(
                                    'assets/icons/univer.svg',
                                    height: w * 0.04,
                                    color: Colors.red,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    child: Text(
                                      'Eligibility : ${widget.data['eligibility']}',
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.w500,
                                          fontSize: w * 0.04,
                                          color: Colors.black),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/icons/univercity.svg',
                                  height: w * 0.04,
                                  color: Colors.red,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  widget.data['university'],
                                  style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w500,
                                      fontSize: w * 0.04,
                                      color: Colors.black),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  color: primary,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                child: Padding(
                                  padding: EdgeInsets.only(top: 10, bottom: 10),
                                  child: Text(
                                    'Course Fee ₹${widget.data['totalFee'].toStringAsFixed(0)}',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w500,
                                        fontSize: w * 0.04,
                                        color: Colors.red),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: widget.data['feeList'].length,
                        itemBuilder: (context, index) {
                          final feeList = widget.data['feeList'][index];
                          return Padding(
                            padding: EdgeInsets.only(top: w * 0.05),
                            child: Stack(
                              children: [
                                Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    Container(
                                      height: w * 0.05,
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      child: Padding(
                                        padding: EdgeInsets.all(w * 0.05),
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              height: w * 0.025,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Admission Fee :',
                                                  style: GoogleFonts.lexend(
                                                      color:
                                                          Colors.grey.shade700),
                                                ),
                                                Text(
                                                  '₹' +
                                                      feeList['admissionFee']
                                                          .toStringAsFixed(0),
                                                  style: GoogleFonts.lexend(),
                                                )
                                              ],
                                            ),
                                            Divider(),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Convocation Fee : ',
                                                  style: GoogleFonts.lexend(
                                                      color:
                                                          Colors.grey.shade700),
                                                ),
                                                Text(
                                                  '₹' +
                                                      feeList['convactionFee']
                                                          .toStringAsFixed(0),
                                                  style: GoogleFonts.lexend(),
                                                )
                                              ],
                                            ),
                                            Divider(),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'University Fee : ',
                                                  style: GoogleFonts.lexend(
                                                      color:
                                                          Colors.grey.shade700),
                                                ),
                                                Text(
                                                  '₹' +
                                                      feeList['universityFee']
                                                          .toStringAsFixed(0),
                                                  style: GoogleFonts.lexend(),
                                                )
                                              ],
                                            ),
                                            Divider(),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Tuition Fee : ',
                                                  style: GoogleFonts.lexend(
                                                      color:
                                                          Colors.grey.shade700),
                                                ),
                                                Text(
                                                  '₹' +
                                                      feeList['tuitionFee']
                                                          .toStringAsFixed(0),
                                                  style: GoogleFonts.lexend(),
                                                )
                                              ],
                                            ),
                                            Divider(),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Total : ',
                                                  style: GoogleFonts.lexend(
                                                      color:
                                                          Colors.grey.shade700,
                                                      fontSize: 18),
                                                ),
                                                Text(
                                                  '₹' +
                                                      feeList['totalFee']
                                                          .toStringAsFixed(0),
                                                  style: GoogleFonts.lexend(
                                                      fontSize: 18),
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Row(
                                    children: [
                                      Expanded(child: Container()),
                                      Container(
                                        height: w * 0.1,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            color: Color(0xffFA2B3A)),
                                        child: Center(
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                              right: w * 0.1,
                                              left: w * 0.1,
                                            ),
                                            child: Text(
                                              feeList['duration'],
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Expanded(child: Container()),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          );
                          Padding(
                            padding: EdgeInsets.only(left: w * .01),
                            child: Container(
                              height: w * .15,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      width: w * .165,
                                      child: Text(
                                        feeList['duration'],
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w500,
                                            fontSize: w * 0.035),
                                      )),
                                  Container(
                                      width: w * .165,
                                      child: Text(
                                        feeList['admissionFee']
                                            .toStringAsFixed(0),
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w500,
                                            fontSize: w * 0.035),
                                      )),
                                  Container(
                                      width: w * .165,
                                      child: Text(
                                        feeList['convactionFee']
                                            .toStringAsFixed(0),
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w500,
                                            fontSize: w * 0.035),
                                      )),
                                  Container(
                                      width: w * .165,
                                      child: Text(
                                        feeList['universityFee']
                                            .toStringAsFixed(0),
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w500,
                                            fontSize: w * 0.035),
                                      )),
                                  Container(
                                      width: w * .165,
                                      child: Text(
                                        feeList['tuitionFee']
                                            .toStringAsFixed(0),
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w500,
                                            fontSize: w * 0.035),
                                      )),
                                  Container(
                                      width: w * .165,
                                      child: Text(
                                        feeList['totalFee'].toStringAsFixed(0),
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w500,
                                            fontSize: w * 0.035),
                                      )),
                                ],
                              ),
                            ),
                          );
                        })
                  ],
                ),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => registerForm(
                            course: widget.course,
                            courseId: widget.courseId,
                            data: widget.data,
                          )));
            },
            child: Container(
              height: w * .15,
              decoration: BoxDecoration(
                  color: Color(0xffFEDE00),
                  borderRadius: BorderRadius.circular(0)),
              width: 120,
              child: Center(
                child: Text(
                  "Select Course",
                  style: GoogleFonts.lexend(
                      fontWeight: FontWeight.w500,
                      fontSize: w * 0.055,
                      color: Colors.black),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
