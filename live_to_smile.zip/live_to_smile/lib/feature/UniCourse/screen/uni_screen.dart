import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/university_model.dart';
import 'package:live_to_smile/core/common/loader.dart';
import 'package:live_to_smile/feature/courses/controller/courses_controller.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../controller/uni_screen_controller.dart';
import 'courseView.dart';


class UniCourses extends ConsumerStatefulWidget {
  final UniversityModel data;
  const UniCourses({Key? key, required this.data}) : super(key: key);

  @override
  ConsumerState<UniCourses> createState() => _UniCoursesState();
}

class _UniCoursesState extends ConsumerState<UniCourses> {
  // List courseList=[];
  // Map<String, dynamic> courseName = {};
  // getCourses()  {
  //   List courses=widget.data['courseList'];
  //   if(courses.length!=0){
  //     for (var doc in courses) {
  //       List feeList=doc['feeList'];
  //       courseList.add({
  //         'university':widget.data['name'],
  //         'available':doc['available'],
  //         'courseId':doc['courseId'],
  //         'duration':feeList.length,
  //         'totalFee':doc['totalFee'],
  //         'feeList':doc['feeList'],
  //         'eligibility':doc['eligibility'],
  //         'monthOrYear':doc['monthOrYear'],
  //         'classDuration':doc['duration']
  //
  //       });
  //       print(doc);
  //     }
  //   }
  //   if (mounted) {
  //     setState(() {
  //
  //     });
  //   }
  //
  // }

  // getCourseName() {
  //   FirebaseFirestore.instance
  //       .collection('course').snapshots().listen((event){
  //     for(DocumentSnapshot doc in event.docs){
  //       courseName[doc.id]=doc.get('name');
  //     }
  //     if(mounted){
  //       setState(() {});
  //     }
  //   });
  // }

  @override
  void initState() {
    // getCourses();
    // getCourseName();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.grey.shade200,
        foregroundColor: Colors.black,
        title: Text("Available Courses",style: GoogleFonts.lexend(
            fontWeight: FontWeight.w500,
            fontSize: w*0.045,color: Colors.black
        ),),

        centerTitle: false,

      ),

      body:
      ref.watch(getUniCourseProvider(widget.data.id)).when(data: (data) {

      print(data);
      print(widget.data.courseList);
          return ListView.builder(
              shrinkWrap: true,
              padding: EdgeInsets.all(w*0.05),
              itemCount: data.length,
              itemBuilder: (context, index) {

                final course=data[index];



                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(

                        decoration: BoxDecoration(
                          color: Colors.white,

                          borderRadius: BorderRadius.circular(20),


                        ),
                        child:
                        ref.watch(getCourseNameProvider).when(data: (courseName) {
                          return  Padding(
                            padding:  EdgeInsets.all(w*0.05),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [

                                Text('${courseName[course['courseId']]}',
                                  style:  GoogleFonts.lexend(fontWeight: FontWeight.bold,fontSize: w*0.045),),
                                SizedBox(height: 5,),
                                Container(
                                  child: Row(
                                    children: [
                                      SvgPicture.asset('assets/icons/duration.svg',height: w*0.03,),
                                      SizedBox(width: 5,),
                                      Text('${course['classDuration']} ${course['monthOrYear']}',
                                        style:  GoogleFonts.lexend(fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.grey.shade700),),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5,),
                                Container(
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SvgPicture.asset('assets/icons/univer.svg',height: w*0.03,),
                                      SizedBox(width: 5,),
                                      Expanded(
                                        child: Text('Eligibility : ${course['eligibility']}',
                                          style:  GoogleFonts.lexend(fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.grey.shade700),),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5,),
                                Row(
                                  children: [
                                    SvgPicture.asset('assets/icons/univercity.svg',height: w*0.03,),
                                    SizedBox(width: 5,),
                                    Text(course['university'],style:  GoogleFonts.lexend(fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.grey.shade700),),
                                  ],
                                ),
                                SizedBox(height: 10,),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text('₹ ${course['totalFee'].toStringAsFixed(1)}',
                                      style:  GoogleFonts.lexend(fontWeight: FontWeight.w700,fontSize: w*0.045,color: Colors.red),),
                                    InkWell(
                                      onTap: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (context)=>coursesView(
                                          data:course,
                                          course:courseName[course['courseId']],
                                          courseId:course['courseId'],
                                        )));
                                      },
                                      child: Container(
                                        height: w*.1,
                                        width: w*.3,
                                        decoration: BoxDecoration(
                                          color: index.isOdd?Color(0xffD1F3A6):Color(0xffFBEBC4),
                                          borderRadius: BorderRadius.circular(10),

                                        ),
                                        child: Center(child: Text('View',style:  GoogleFonts.lexend(fontWeight: FontWeight.bold,fontSize: w*0.05,color: Colors.black),)),

                                      ),
                                    ),

                                  ],
                                ),
                              ],

                            ),
                          );
                        }, error: (error, stackTrace) => Text(error.toString()), loading: () => Loader(),)

                    ),
                  );




              }
          );




      }, error: (error, stackTrace) => Text(error.toString()), loading: () => Loader(),)

    );
  }
}
