

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/feature/AnnounceNotification/repository/announnceRepository.dart';

import '../../../Models/notification_model.dart';

final announceStreamProvider = StreamProvider((ref) => ref.watch(announceControllerProvider).notificationCon());

final announceControllerProvider=Provider((ref) {
  return AnnounceController(announceRepository: ref.watch(announceRepositoryProvider));
});

class AnnounceController{
 final AnnounceRepository _announceRepository;
 AnnounceController({
   required AnnounceRepository announceRepository
}) : _announceRepository = announceRepository;


 Stream<List<NotificationModel>> notificationCon(){
   return _announceRepository.notificationsRep();
 }
 // updateMsg(){
 //   _announceRepository.updateMsg();
 // }
//ToDo change
  updateMsg(String student,String id){
    _announceRepository.updateMsg(student, id);
  }
}
