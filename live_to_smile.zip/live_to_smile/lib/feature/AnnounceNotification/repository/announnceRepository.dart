//final announceRepositoryProvider{}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/notification_model.dart';
import 'package:live_to_smile/core/constants/firebaseconstants/firebase_constants.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';
import 'package:live_to_smile/feature/authentication/repository/auth_repository.dart';

import '../../homepage/screen/home_page.dart';

final announceRepositoryProvider = Provider((ref) {
  return AnnounceRepository(firestore: ref.watch(firestoreProvider));
});

class AnnounceRepository {
  final FirebaseFirestore _firestore;

  AnnounceRepository({required FirebaseFirestore firestore})
      : _firestore = firestore;

  CollectionReference get _notifications =>
      _firestore.collection(FirebaseConstants.notificationsCollection);

  Stream<List<NotificationModel>> notificationsRep() {
    List<NotificationModel> not = [];

    return _notifications
        .where('type', isNotEqualTo: 'Tutors')
        .snapshots()
        .map((event) {
      not = [];
      var data = event.docs;
      data.sort((a, b) => b['date']
          .microsecondsSinceEpoch
          .compareTo(a['date'].microsecondsSinceEpoch));
      for (var i in data) {
        List ids = i['list'];
        if (ids.contains(studentId)) {
          not.add(NotificationModel.fromMap(i.data() as Map<String, dynamic>));
        }
      }
      // not = [];
      // for(var i in event.docs ){
      //   List notificationList = i.data()!["list"];
      //   if(i.data()["list"].conta)
      // }
      return not;
      // return event.docs
      //   .map((e) => NotificationModel.fromMap(e.data() as Map<String,dynamic>))
      //   .toList();
    });
    //
    // return _Notification;
  }

// updateMsg(){
//   FirebaseFirestore.instance.collection('notifications').doc(widget.data['id']).update({
//     'view':FieldValue.arrayUnion([studentId])
//   });
// }
//ToDo Changes
  updateMsg(String student, String id) {
    _firestore.collection('notifications').doc(id).update({
      'view': FieldValue.arrayUnion([student])
    });
  }
}
