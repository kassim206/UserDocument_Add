import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/notification_model.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:live_to_smile/feature/AnnounceNotification/screens/msg_view.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:intl/intl.dart';

class NotificationCard extends ConsumerStatefulWidget {
  NotificationModel notificationDetail;
  NotificationCard({super.key, required this.notificationDetail});

  @override
  ConsumerState<NotificationCard> createState() => _NotificationCardState();
}

class _NotificationCardState extends ConsumerState<NotificationCard> {
  @override
  Widget build(BuildContext context) {
    final student = ref.watch(userProvider);
    var h = MediaQuery.of(context).size.height;
    var W = MediaQuery.of(context).size.width;
    return Bounce(
      duration: Duration(milliseconds: 100),
      onPressed: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ViewMsgs(
                      data: widget.notificationDetail,
                      notDate: widget.notificationDetail.date.toDate(),
                      notTime:
                          formattedTime(widget.notificationDetail.date.toDate())
                              .toString(),
                    )));
      },
      child: Container(
        height: W * 0.4,
        child: Stack(
          children: [
            Center(
              child: Container(
                height: W * 0.35,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(W * 0.05),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade300,
                      offset: const Offset(
                        5.0,
                        2.0,
                      ),
                      blurRadius: 15.0,
                      spreadRadius: -10.0,
                    ), //BoxShadow
                    //BoxShadow
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(W * 0.03),
                  child: Column(
                    children: [
                      Align(
                          alignment: Alignment.topLeft,
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: widget.notificationDetail.view
                                        .contains(candidatesModel!.studentId)
                                    ? Colors.green
                                    : Colors.red,
                                //backgroundColor:view.contains(studentId)?Colors.green: Colors.red,
                                radius: W * 0.02,
                              ),
                              SizedBox(
                                width: W * 0.02,
                              ),
                              Text(
                                  ((widget.notificationDetail.date
                                                  .toString()
                                                  .substring(0, 10) ==
                                              DateTime.now()
                                                  .toString()
                                                  .substring(0, 10))
                                          ? 'Today'
                                          : (widget.notificationDetail.date
                                                      .toString()
                                                      .substring(0, 10) ==
                                                  DateTime.now()
                                                      .add(Duration(days: -1))
                                                      .toString()
                                                      .substring(0, 10))
                                              ? 'Yesterday'
                                              : DateFormat("MMM dd yyyy").format(
                                                  widget.notificationDetail.date
                                                      .toDate())) +
                                      '  ' +
                                      formattedTime(widget.notificationDetail.date
                                          .toDate()),
                                  style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w400,
                                      fontSize: w * 0.025,
                                      color: darkT)),
                            ],
                          )),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: Text(
                                    widget.notificationDetail.title,
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w500,
                                        fontSize: w * 0.03),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: SizedBox(),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: W * 0.003),
                              child: Text(
                                widget.notificationDetail.message,
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w400,
                                    fontSize: w * 0.025,
                                    color: darkT),
                                maxLines: 3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: EdgeInsets.only(right: W * 0.03),
                child: Image.asset(
                  'assets/icons/mike.png',
                  width: W * 0.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
    ;
  }
}

String formattedTime(DateTime dateTime) {
  return DateFormat().add_jm().format(dateTime);
}
