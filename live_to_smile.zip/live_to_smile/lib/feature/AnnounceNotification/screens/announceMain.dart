import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/feature/AnnounceNotification/controller/announceController.dart';
import 'package:live_to_smile/feature/AnnounceNotification/screens/notificationcard.dart';
import '../../../bottom_bar/bottomBar.dart';


class AnnounceMain extends ConsumerStatefulWidget {
  const AnnounceMain({super.key});

  @override
  ConsumerState<AnnounceMain> createState() => _AnnounceMainState();
}

class _AnnounceMainState extends ConsumerState<AnnounceMain> {

  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    return((candidatesModel == null || candidatesModel!.studentId == '') || candidatesModel!.verified == 2)
          ?
      Scaffold(
        backgroundColor: primary,
        body: Center(
          child: Container(
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/icons/splash_back.png'),
                          fit: BoxFit.fill)),
                  child: Padding(
                    padding: EdgeInsets.all(w * 0.05),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            left: w * 0.25,
                            right: w * 0.25,
                          ),
                          child: Image.asset(
                            'assets/icons/logo.png',
                            width: w * 0.5,
                          ),
                        ),
                        SizedBox(
                          height: w * 0.05,
                        ),
                        //TODO studentid
                        Text(
                          candidatesModel == null || candidatesModel!.studentId == ''?
                          'Your haven\'t purchased any course.\nPlease enroll for a course first.'
                                :candidatesModel!.verified==2?'Uploaded Documents Rejected. \nPlease Resubmit your Documents'
                            :'',
                          style: GoogleFonts.lexend(fontSize: 18),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      )
         :
      ref.watch(announceStreamProvider).when(
              data: (data) {
                if(data.isEmpty){
                return  Scaffold(
                  backgroundColor: primary,
                  body: Container(
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/icons/splash_back.png'),
                            fit: BoxFit.fill
                        )
                    ),
                    child: Padding(
                      padding:  EdgeInsets.all(w*0.05),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Padding(
                            padding:  EdgeInsets.only(
                              left: w*0.25,
                              right: w*0.25,
                            ),
                            child: Image.asset('assets/icons/logo.png',width: w*0.5,),
                          ),
                          SizedBox(height: w*0.05,),
                          Text('Your haven\'t any messages.',style: GoogleFonts.lexend(
                              fontSize: 18
                          ),textAlign: TextAlign.center,),
                        ],
                      ),
                    ),
                  ),
                );
                }else{
                  return Scaffold(
                    backgroundColor: back,
                    appBar: AppBar(
                      backgroundColor: back,
                      foregroundColor: Colors.black,
                      automaticallyImplyLeading: false,
                      elevation: 0,
                      title: Text("Announcement",style: GoogleFonts.lexend(
                          fontWeight: FontWeight.w500,
                          fontSize: w*0.045,color: Colors.black
                      ),),

                    ),
                    body: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              padding: EdgeInsets.only(
                                left: w * 0.05,
                                right: w * 0.05,
                                top: w * 0.05,
                              ),
                              itemCount: data.length,
                              itemBuilder: (context, index) {
                                return NotificationCard(
                                    notificationDetail: data[index]);
                              }),
                        ],
                      ),
                    ),
                  );
                }

              },
              error: ((error, stackTrace) => Center(
                    child: Text(error.toString()),
                  )),
              loading: () => const Center(
                    child: CircularProgressIndicator(),
                  )
    );
  }
}
