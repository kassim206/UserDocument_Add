// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:google_fonts/google_fonts.dart';
// import '../../../Models/notification_model.dart';
//
//
// class MsgsView extends ConsumerStatefulWidget {
//   NotificationModel notificationDetail;
//   MsgsView({super.key,required this.notificationDetail});
//
//   @override
//   ConsumerState<MsgsView> createState() => _MsgsViewState();
// }
//
// class _MsgsViewState extends ConsumerState<MsgsView> {
//   @override
//   Widget build(BuildContext context) {
//     var h = MediaQuery.of(context).size.height;
//     var w = MediaQuery.of(context).size.width;
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         foregroundColor: Colors.black,
//
//
//
//
//         // title: Text(((widget.notDate.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
//         // 'Today':(widget.notDate.toString().substring(0,10)==DateTime.now().add(Duration(days: -1)).toString().substring(0,10))?
//         // 'Yesterday':DateFormat("MMM dd yyyy").format(widget.notDate))+'  '+widget.notTime,style: GoogleFonts.lexend(
//         //     fontWeight: FontWeight.w400,fontSize: w*0.035,color: darkT
//         // )),
//       ),
//
//       body: Padding(
//         padding:  EdgeInsets.all(w*0.075),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             Container(
//               decoration: BoxDecoration(
//                   border: Border(
//                     top: BorderSide(),
//                     left: BorderSide(),
//                     right: BorderSide(),
//                   )
//               ),
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: Text(widget.notificationDetail.title,style: GoogleFonts.lexend(
//                     fontWeight: FontWeight.w500,fontSize: w*0.045
//                 ),textAlign: TextAlign.center,),
//               ),
//             ),
//             Container(
//               decoration: BoxDecoration(
//                   border: Border.all()
//               ),
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: Text(widget.notificationDetail.message,style: GoogleFonts.lexend(
//                     fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.grey.shade700
//                 ),textAlign: TextAlign.start,),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
//TODO Change
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/notification_model.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../controller/announceController.dart';

class ViewMsgs extends ConsumerStatefulWidget {
  final NotificationModel data;
  final DateTime notDate;
  final String notTime;
  const ViewMsgs({Key? key,  required this.notDate,  required this.notTime, required this. data}) : super(key: key);

  @override
  ConsumerState<ViewMsgs> createState() => _ViewMsgsState();
}

class _ViewMsgsState extends ConsumerState<ViewMsgs> {

  // updateMsg(){
  //   final student=ref.read(userProvider);
  //
  //   FirebaseFirestore.instance.collection('notifications').doc(widget.data['id']).update({
  //     'view':FieldValue.arrayUnion([student!.uid])
  //   });
  // }
  updateMsg(){

    ref.read(announceControllerProvider).updateMsg(candidatesModel!.studentId, widget.data.id);
  }

  @override
  void initState() {
    updateMsg();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        title: Text(((widget.notDate.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
        'Today':(widget.notDate.toString().substring(0,10)==DateTime.now().add(Duration(days: -1)).toString().substring(0,10))?
        'Yesterday':DateFormat("MMM dd yyyy").format(widget.notDate))+'  '+widget.notTime,style: GoogleFonts.lexend(
            fontWeight: FontWeight.w400,fontSize: w*0.035,color: darkT
        )),
      ),
      body: Padding(
        padding:  EdgeInsets.all(w*0.075),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(),
                    left: BorderSide(),
                    right: BorderSide(),
                  )
              ),
              child: Padding(
                padding:  EdgeInsets.all(w*0.05),
                child: Text(widget.data.title,style: GoogleFonts.lexend(
                    fontWeight: FontWeight.w500,fontSize: w*0.045
                ),textAlign: TextAlign.center,),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border.all()
              ),
              child: Padding(
                padding:  EdgeInsets.all(w*0.05),
                child: Text(widget.data.message,style: GoogleFonts.lexend(
                    fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.grey.shade700
                ),textAlign: TextAlign.start,),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
