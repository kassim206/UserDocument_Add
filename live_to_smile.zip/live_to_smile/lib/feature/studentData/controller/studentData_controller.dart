import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/feature/studentData/repository/studentData_repository.dart';


final studentDataController=Provider((ref) {
  return StudentDataController(studentDataRepository: ref.read(studentDataRepository));
});
class StudentDataController{
  final StudentDataRepository _studentDataRepository;
  StudentDataController({
    required StudentDataRepository studentDataRepository,
}):
      _studentDataRepository=studentDataRepository;

  getCourses(String courseId){
    return _studentDataRepository.getCourses(courseId);
  }
  getUniversity(String university){
    return _studentDataRepository.getUniversity(university);
  }
}