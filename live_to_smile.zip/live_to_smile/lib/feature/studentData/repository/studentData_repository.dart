import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';
import '../../../core/routing/routing.dart';

final studentDataRepository = Provider((ref) {
  return StudentDataRepository(
      storage: ref.read(storageProvider),
      firestore: ref.read(firestoreProvider));
});

class StudentDataRepository {
  final FirebaseFirestore _firestore;
  final FirebaseStorage _storage;
  StudentDataRepository({
    required FirebaseStorage storage,
    required FirebaseFirestore firestore,
  })  : _storage = storage,
        _firestore = firestore;

  String course = '';
  String university = '';
  getCourses(String courseId) async {
    DocumentSnapshot data = await _firestore
        .collection('course')
        .doc(courseId)
        .get();
    course = data.get('name');
  }

  getUniversity(String university) async {
    DocumentSnapshot data = await _firestore
        .collection('university')
        .doc(university)
        .get();
    university = data.get('name');
  }
}
