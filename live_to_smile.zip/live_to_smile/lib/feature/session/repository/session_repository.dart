import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/core/constants/firebaseconstants/firebase_constants.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';

final classRepositoryProvider = StateProvider(
        (ref) => sessionRepository(firestore: ref.watch(firestoreProvider)));

class sessionRepository {
  final FirebaseFirestore _firestore;
  sessionRepository({required FirebaseFirestore firestore})
      : _firestore = firestore;
  CollectionReference get session =>
      _firestore.collection(FirebaseConstants.sessionsCollection);
  // late StreamSubscription zoom;
  // String currentToken='';
  // getToken(String email){
  //   zoom=_firestore.collection('zoomAccount')
  //       .where('email',isEqualTo: email)
  //       .snapshots()
  //       .listen((event) {
  //     currentToken=event.docs.first['token'];
  //     // if(mounted){
  //     //   setState(() {
  //     //
  //     //   }
  //     //   );
  //   }
  //   );
  // }
  Stream<String> getToken(String email){
    return _firestore.collection('zoomAccount').where('email',isEqualTo:email).snapshots().map((event) {
      print("email $email");
      String currentToken =event.docs.first['token'];
      return currentToken;
    });
  }
getMeetings1(String classId,String uid){
  FirebaseFirestore.instance.collection('zoomClass').doc(classId).update({
    'played':FieldValue.arrayUnion([uid]),
  });
}
}