import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/feature/session/repository/session_repository.dart';

final sessionControllerProvider = Provider(
    (ref) => sessionController(repository: ref.read(classRepositoryProvider)));
final getTokenSessionStreamProvider = StreamProvider.family(
    (ref, String email) =>
        ref.watch(sessionControllerProvider).getToken(email));

class sessionController {
  final sessionRepository _repository;
  sessionController({required sessionRepository repository})
      : _repository = repository;
  Stream<String> getToken(String email) {
    return _repository.getToken(email);
  }

  getMeetings1(String classId, String uid) {
    _repository.getMeetings1(classId, uid);
  }
}
