import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/core/common/error.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import '../../../bottom_bar/bottomBar.dart';
import '../../../chat/chat.dart';
import '../../../core/common/loader.dart';
import '../../homepage/screen/home_page.dart';
import '../contoller/session_controller.dart';

class Session extends ConsumerStatefulWidget {
  final dynamic data;
  final String index;
  const Session({Key? key, this.data, required this.index});

  @override
  ConsumerState createState() => _SessionState();
}

class _SessionState extends ConsumerState<Session> {
  UsersModel? user;
  Future<void> _launchInWebViewOrVC(Uri url) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.inAppWebView,
      webViewConfiguration: const WebViewConfiguration(
          headers: <String, String>{'my_header_key': 'my_header_value'}),
    )) {
      throw 'Could not launch $url';
    }
  }
  _launchZoomUrl({ required Uri fileUrl}) async {
    print("hi");
    if (await canLaunchUrl(fileUrl)) {
      await launchUrl(
        fileUrl,
        mode: LaunchMode.externalApplication,
      );
    } else {
      throw 'Could not launch $fileUrl';
    }
  }
  int status=0;
  getMeetingVideo(String id,String classId,String token) async {

    print(accessToken);
    status=1;
    setState(() {

    });
    print(id);
    showDialog(
        context: context,
        builder: (context) =>
            Center(child: Loader())
      //         AlertDialog (title: Column(
      //           crossAxisAlignment: CrossAxisAlignment.start,
      //           children: [
      //             Text ('Do you want to exit from SOOK?',style: GoogleFonts.poppins(
      //               fontSize: 12,fontWeight: FontWeight.w500
      //             ),),
      //             Text ('if you exit now, the items in your cart will erase',style: GoogleFonts.poppins(
      //                 fontSize: 10
      //             ),),
      //           ],
      //         ), actions: <Widget>[
      //     ElevatedButton(
      //     child: Text ('exit '),
      //     onPressed: (){
      //       Navigator.of(context).pop(true);
      //
      //     }
      //
      //     ),
      //           ElevatedButton(
      //     child: const Text ('cancel '),
      //     onPressed: () {
      // Navigator.of(context).pop(false);
      //       },
      //     )])
    );
    var headers={
      'Authorization': 'Bearer $token'
      // 'Authorization': 'Bearer $accessToken'
      //'access_token': accessToken
    };

    var response =
    await http.get(
        Uri.parse('https://api.zoom.us/v2/meetings/$id/recordings'),
        headers: headers);
    Navigator.pop(context);
    status=0;
    Map<String, dynamic> body = json.decode(response.body);

    print(response.statusCode);
    print(body);
    //print(body['recording_files'][0]['play_url']);
    // List list = body['getCustomerList'];

    if (response.statusCode == 200) {
      await _launchInWebViewOrVC(Uri.tryParse(body['recording_files'][0]['play_url'])!);
      print(classId);
      ref.read(sessionControllerProvider).getMeetings1(classId,user!.uid);

    } else {
      print('Error!!');
      throw Exception('Failed to Load Post');
    }
    if (mounted) {
      setState(() {

      });
    }

  }
  getMeetingVideos(){
    getMeetingVideo(widget.data['meetingId'].toString(),widget.data['zoomClsId'],widget.data['token']);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // getToken();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    // zoom.cancel();
  }
  @override
  Widget build(BuildContext context) {
    final user =ref.watch(userProvider);
    DateTime date=widget.data['scheduled'].toDate();
    String time=formattedTime(date).toString();
    return ref.watch(getTokenSessionStreamProvider(user!.email)).when(
        data: (data) {
          return Scaffold(
            backgroundColor: back,
            appBar: AppBar(
              backgroundColor: back,
              foregroundColor: darkT,
              elevation: 0,
              title: Container(
                decoration: BoxDecoration(
                  color: Color(0xff343434),
                  borderRadius: BorderRadius.circular(w*0.02),
                  boxShadow: [
                    BoxShadow(
                      color:Colors.grey.shade300,
                      offset: const Offset(
                        5.0,
                        2.0,
                      ),
                      blurRadius: 10.0,
                      spreadRadius: -2.0,
                    ), //BoxShadow
                    //BoxShadow
                  ],
                ),
                child: Padding(
                  padding:  EdgeInsets.fromLTRB(
                    w*0.03,
                    w*0.01,
                    w*0.03,
                    w*0.01,
                  ),
                  child: Text('${widget.data['name']}',style: GoogleFonts.lexend(
                      fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.white
                  ),),
                ),
              ),
              actions: [
              ],
            ),
            body: SingleChildScrollView(
              physics: BouncingScrollPhysics(),
              child: Column(
                children: [
                  Bounce(
                    onPressed: (){

                      getMeetingVideo(widget.data['meetingId'].toString(),widget.data['zoomClsId'],widget.data['token']);

                      // if(nextClass['start']==true&&nextClass['status']==0){
                      //
                      //   launchURL(nextClass['join_url']);
                      //   FirebaseFirestore.instance.collection('zoomClass').doc(nextClass['zoomClsId']).update({
                      //     'attendance':FieldValue.arrayUnion([studentId])
                      //   });
                      // }else{
                      //   getMeetingVideo(nextClass['meetingId'].toString());
                      // }

                      // if(onGoing.length!=0){
                      //   // joinMeeting(context);
                      // }
                    },
                    duration: Duration(milliseconds: 100),
                    child: SizedBox(
                      height: w*0.53,
                      width: w*0.9,

                      child: Stack(
                        children: [
                          Center(child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Image.asset('assets/icons/logo.png'),
                          )),
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.black.withOpacity(0.8)
                            ),
                            child: Center(
                              child: CircleAvatar(
                                backgroundColor: primary.withOpacity(0.5),
                                radius: w*0.08,
                                child: Icon(Icons.play_arrow,color: Colors.white,size: 30,),
                              ),

                            ),
                          ),
                        ],
                      ),

                    ),
                  ),
                  Padding(
                    padding:  EdgeInsets.only(
                        left: w*0.05,
                        right: w*0.05,
                        top: w*0.025
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.data['name'],style: GoogleFonts.lexend(
                            fontWeight: FontWeight.w500,
                            fontSize: w*0.045,color: Colors.black
                        ),),
                        SizedBox(
                          height: w*0.04,
                        ),
                        // ClipRRect(
                        //   borderRadius: BorderRadius.circular(10),
                        //   child: FlickVideoPlayer(
                        //       flickManager: FlickManager(
                        //
                        //           videoPlayerController:
                        //           VideoPlayerController.network("https://firebasestorage.googleapis.com/v0/b/movieflix-baeb9.appspot.com/o/users%2FiF0TtLy7QuaZFuDOGVyb1MD4Vez2%2Fuploads%2F1656669364993000.mp4?alt=media&token=325fb835-6b36-433b-af64-d5eea24ca50d",
                        //               videoPlayerOptions: VideoPlayerOptions(
                        //
                        //               )
                        //           ))
                        //   ),
                        // ),
                        SizedBox(
                          height: w*0.03,
                        ),
                        Padding(
                          padding:  EdgeInsets.only(
                            left: w*0.025,
                            right: w*0.025,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(child: Row(
                                    children: [
                                      CircleAvatar(
                                        radius: w*0.04,
                                        backgroundImage:NetworkImage(tutorMap[widget.data['tutor']]['photo_url']) ,
                                        backgroundColor: Colors.white,
                                      ),
                                      SizedBox(width: w*0.025,),

                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text('Session by',style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.black
                                            ),),
                                            Text(tutorMap[widget.data['tutor']]['display_name'],style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w500,fontSize: w*0.028,color: Color(0xffFA2B3A)
                                            ),)
                                          ],
                                        ),
                                      )
                                    ],
                                  )),
                                  Expanded(
                                    child: Padding(
                                      padding:  EdgeInsets.only(
                                        left: w*0.003,
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('${widget.data['subject']}',style: GoogleFonts.lexend(
                                              fontWeight: FontWeight.w400,fontSize: w*0.035,color: Colors.black
                                          ),),
                                          Text(((date.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
                                          'Today':(date.toString().substring(0,10)==DateTime.now().add(Duration(days: -1)).toString().substring(0,10))?
                                          'Yesterday':DateFormat("MMM dd yyyy").format(date))+'  '+time,style: GoogleFonts.lexend(
                                              fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
                                          ),),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: w*0.05,
                              ),
                              Text("Description",style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w500,
                                  fontSize: w*0.04,color: Colors.black
                              ),),
                              SizedBox(
                                height: w*0.03,
                              ),
                              Text(widget.data['description'],style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w400,
                                  fontSize: w*0.03,color: Colors.black.withOpacity(0.7)
                              ),),
                              SizedBox(
                                height: w*0.02,
                              ),
                              Divider(color: darkT,),
                              SizedBox(
                                height: w*0.04,
                              ),
                              widget.data['notes'].length==0?Container(): Text("Notes",style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w500,
                                  fontSize: w*0.04,color: Colors.black
                              ),),
                              SizedBox(
                                height: w*0.03,
                              ),
                              Padding(
                                padding:  EdgeInsets.only(
                                  left: w*0.02,
                                  right: w*0.02,
                                ),
                                child: ListView.builder(
                                  itemCount: widget.data['notes'].length,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context,index){
                                    return Padding(
                                      padding:  EdgeInsets.only(
                                          bottom: w*0.02
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding:  EdgeInsets.only(top: w*0.01),
                                            child: Icon(Icons.circle,color: Colors.black.withOpacity(0.7),size:w*0.02 ,),
                                          ),
                                          SizedBox(width: w*0.03,),
                                          Expanded(
                                            child: Text(widget.data['notes'][index],style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w400,
                                                fontSize: w*0.03,color:Colors.black.withOpacity(0.7)
                                            ),),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),

                              SizedBox(
                                height: w*0.02,
                              ),
                              Divider(color: darkT,),
                              widget.data['documents'].length==0?Container():   Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("Documents",style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w500,
                                      fontSize: w*0.04,color: Colors.black
                                  ),),
                                  Container(
                                    decoration: BoxDecoration(
                                      color: Color(0xff343434),
                                      borderRadius: BorderRadius.circular(w*0.02),
                                      boxShadow: [
                                        BoxShadow(
                                          color:Colors.grey.shade400,
                                          offset: const Offset(
                                            5.0,
                                            2.0,
                                          ),
                                          blurRadius: 10.0,
                                          spreadRadius: -2.0,
                                        ), //BoxShadow
                                        //BoxShadow
                                      ],
                                    ),
                                    child: Padding(
                                      padding:  EdgeInsets.fromLTRB(
                                        w*0.03,
                                        w*0.01,
                                        w*0.03,
                                        w*0.01,
                                      ),
                                      child: Text(widget.data['documents'].length.toString(),style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.w400,fontSize: w*0.035,color: Colors.white
                                      ),),
                                    ),
                                  ),
                                ],
                              ),
                              widget.data['documents'].length==0?Container():SizedBox(
                                height: w*0.03,
                              ),
                              widget.data['documents'].length==0?Container():Container(
                                height: w*0.3,
                                child: ListView.builder(
                                  padding:  EdgeInsets.zero,
                                  itemCount:widget.data['documents'].length ,
                                  scrollDirection: Axis.horizontal,
                                  itemBuilder: (context,index){
                                    return Padding(
                                      padding:  EdgeInsets.only(right: w*0.03,),
                                      child: Bounce(
                                        onPressed: () async {
                                          //downLoadFile(widget.data['documents'][index]['name'], widget.data['documents'][index]['file']);
                                          //launchUrl(Uri.parse(nextClass['documents'][index]['url']));
                                          print('13456789');
                                          print( widget.data['documents'][index]['url']);
                                          print('here');
                                          _launchZoomUrl(
                                              fileUrl: Uri.parse(
                                                  widget.data['documents']
                                                  [index]['url']));
                                        },
                                        duration: Duration(milliseconds: 100),
                                        child: Container(
                                          width: w*0.26,
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(10),
                                              border: Border.all(color: Color(0xffD8D8D8))
                                          ),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              SvgPicture.asset('assets/icons/dcmnt.svg',color: Color(0xffD8D8D8),),
                                              SizedBox(height: w*0.02,),
                                              Text(widget.data['documents'][index]['name'],textAlign: TextAlign.center,style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: w*0.03,color: Color(0xffD8D8D8)
                                              ),),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                              // SizedBox(
                              //   height: w*0.04,
                              // ),
                              // Text("Suggested Sessions",style: GoogleFonts.lexend(
                              //     fontWeight: FontWeight.w500,
                              //     fontSize: w*0.04,color: Colors.black
                              // ),),
                              // SizedBox(
                              //   height: w*0.03,
                              // ),
                              // Container(
                              //   child: ListView.builder(
                              //     itemCount: sessions.length,
                              //     padding: EdgeInsets.only(
                              //         top: w*0.03
                              //     ),
                              //     shrinkWrap: true,
                              //     physics: NeverScrollableScrollPhysics(),
                              //     itemBuilder: (context,index){
                              //       return Padding(
                              //         padding:  EdgeInsets.only(bottom: w*0.03),
                              //         child: Bounce(
                              //           duration: Duration(milliseconds: 110),
                              //           onPressed: (){
                              //
                              //           },
                              //           child: Container(
                              //             decoration: BoxDecoration(
                              //                 color: Colors.white,
                              //                 borderRadius: BorderRadius.circular(15)
                              //             ),
                              //             child: Row(
                              //               crossAxisAlignment: CrossAxisAlignment.start,
                              //               children: [
                              //                 Expanded(
                              //                   child: Padding(
                              //                     padding:  EdgeInsets.all(w*0.05),
                              //                     child: Row(
                              //                       children: [
                              //                         CircleAvatar(
                              //                           backgroundColor: back,
                              //                           radius: w*0.08,
                              //                           backgroundImage: AssetImage('assets/icons/vplay.png'),
                              //                         ),
                              //                         SizedBox(width: w*0.04,),
                              //                         Column(
                              //                           crossAxisAlignment: CrossAxisAlignment.start,
                              //                           children: [
                              //                             Text(sessions[index]['name'],style: GoogleFonts.lexend(
                              //                                 fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.black
                              //                             ),),
                              //                             SizedBox(height: w*0.005,),
                              //                             Text(sessions[index]['duration'],style: GoogleFonts.lexend(
                              //                                 fontWeight: FontWeight.w500,fontSize: w*0.025,color: Color(0xffFA2B3A)
                              //                             ),),
                              //                             SizedBox(height: w*0.01,),
                              //                             Padding(
                              //                               padding:  EdgeInsets.only(
                              //                                 left: w*0.003,
                              //                               ),
                              //                               child: Text(sessions[index]['teacher'],style: GoogleFonts.lexend(
                              //                                   fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
                              //                               ),),
                              //                             ),
                              //                           ],
                              //                         )
                              //                       ],
                              //                     ),
                              //                   ),
                              //                 ),
                              //                 Container(
                              //                   height: w*0.08,
                              //                   width: w*0.1,
                              //                   decoration: BoxDecoration(
                              //                       color: Color(0xffFEDE00),
                              //                       borderRadius: BorderRadius.only(
                              //                           topRight: Radius.circular(15)
                              //                       )
                              //                   ),
                              //                   child: Center(child: Text(index+1<10?'#0${index+1}':'#${index+1}',style: GoogleFonts.lexend(
                              //                       fontWeight: FontWeight.w500,fontSize: w*0.025
                              //                   ),)),
                              //                 )
                              //               ],
                              //             ),
                              //           ),
                              //         ),
                              //       );
                              //     },
                              //   ),
                              // ),
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
        error: (error, stackTrace) {
          print(stackTrace);
         return Scaffold(
          body: CircularProgressIndicator(),
        );
         },
        loading: () => Loader(),);

  }
}