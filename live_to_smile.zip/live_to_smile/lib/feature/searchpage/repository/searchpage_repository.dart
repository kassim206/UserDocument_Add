import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';

import '../../../Models/zoom_class_model.dart';
import '../../../core/routing/routing.dart';
final searchpageRepositoryProvider=Provider((ref) {
  return SearchpageRepository(firestore: ref.read(firestoreProvider));
});
class SearchpageRepository{
  final FirebaseFirestore _firestore;
  SearchpageRepository({
    required FirebaseFirestore firestore,
}):
        _firestore=firestore;



  Stream<List<Map<String, dynamic>>>getSearch(String search){
    return FirebaseFirestore.instance
        .collection('zoomClass')
        .where('batch', isEqualTo: candidatesModel!.classId)
        .where('status', isEqualTo: 1)
        .where('search',
        arrayContains:
        search.toUpperCase())
        .orderBy('scheduled', descending: true)
        .snapshots().map((event){
          List<Map<String,dynamic>> a=[];
          for(var i in event.docs ){
            a.add(i.data());
          }
            return a;
    } );
}
}