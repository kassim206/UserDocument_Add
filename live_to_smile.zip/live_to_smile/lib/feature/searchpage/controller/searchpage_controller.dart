import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repository/searchpage_repository.dart';


final searchpagecontrollerProvider=Provider((ref) {
  return SearchpageController(searchPageRepository: ref.read(searchpageRepositoryProvider));
});
final getsearchProvider=StreamProvider.family((ref,String search) {
  return ref.read(searchpagecontrollerProvider).getSearch(search);
} );
class SearchpageController {
  final SearchpageRepository _searchpageRepository;

  SearchpageController({
    required SearchpageRepository searchPageRepository,
  }) :
        _searchpageRepository=searchPageRepository;

  Stream<List<Map<String, dynamic>>>getSearch(String search){
   return  _searchpageRepository.getSearch(search);
  }
}