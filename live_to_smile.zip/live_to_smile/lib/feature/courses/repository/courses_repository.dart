import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';


final courseRepositoryProvider = Provider((ref) {
  return CourseRepository(firestore: ref.read(firestoreProvider));
});

class CourseRepository {
  final FirebaseFirestore _firestore;
  CourseRepository({
    required FirebaseFirestore firestore,
  }) : _firestore = firestore;

  //
  // Map<String, dynamic> courseName = {};

  Stream<List> getCourses() {
    return _firestore
        .collection('university')
        .where('available', isEqualTo: true)
        .snapshots()
        .map((event) {
      List a = [];
      for (var data in event.docs) {
        if (data.data()['courseList'].length != 0) {
          for (var doc in data.data()['courseList']) {
            a.add({
              'university': data['name'],
              'available': doc['available'],
              'courseId': doc['courseId'],
              'duration': doc['feeList'].length,
              'totalFee': doc['totalFee'],
              'feeList': doc['feeList'],
              'eligibility': doc['eligibility'],
              'monthOrYear': doc['monthOrYear'],
              'classDuration': doc['duration']
            });
          }
        }
      }
      return a;
    });
  }

  Stream<Map<String, dynamic>> getCourseName() {
    return _firestore.collection('course').snapshots().map((event) {
      Map<String, dynamic> courseName = {};
      for (DocumentSnapshot doc in event.docs) {
        courseName[doc.id] = doc.get('name');
      }
      return courseName;
    });
  }
}
