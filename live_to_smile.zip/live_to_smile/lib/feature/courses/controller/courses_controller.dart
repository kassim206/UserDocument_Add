import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/feature/courses/repository/courses_repository.dart';

final getCourseProvider=StreamProvider((ref) => ref.read(courseControllerProvider).getCourses());
final getCourseNameProvider=StreamProvider((ref) => ref.read(courseControllerProvider).getCourseName());


final courseControllerProvider=Provider((ref) {
  return CourseController(courseRepository: ref.read(courseRepositoryProvider));
});
class CourseController{
  final CourseRepository _courseRepository;
  CourseController({
    required CourseRepository courseRepository,
}):
      _courseRepository=courseRepository;


  Stream<List>getCourses(){
    return _courseRepository.getCourses();
  }
  Stream<Map<String,dynamic>>getCourseName(){
    return _courseRepository.getCourseName();
  }
}