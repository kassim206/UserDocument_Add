
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/core/common/loader.dart';
import 'package:live_to_smile/feature/courses/controller/courses_controller.dart';

import '../../../bottom_bar/bottomBar.dart';
import '../../UniCourse/screen/courseView.dart';


final lengthProvider = StateProvider<int>((ref) {
  return 4;
});
class Courses extends ConsumerStatefulWidget {
  const Courses({Key? key}) : super(key: key);

  @override
  ConsumerState<Courses> createState() => _CoursesState();
}

class _CoursesState extends ConsumerState<Courses> {
  final ScrollController scrollController=ScrollController();
  double previousScroll=0;
  bool isLoading=false;
  paginationFunction() {
    scrollController.addListener(() {
      double maxScroll = scrollController.position.maxScrollExtent;
      double currentScroll = previousScroll + scrollController.position.pixels;
      double delta = MediaQuery.of(context).size.height * 0.20;
      if (!isLoading) {
        if (maxScroll - currentScroll <= delta &&
            currentScroll > previousScroll) {
          isLoading = true;
          Future.delayed(const Duration(seconds: 1, microseconds: 500))
              .then((value) {
            // setState(() {
            //   len += 5;
            // });
            ref.read(lengthProvider.notifier).update((state) => state + 4);
            isLoading = false;
          });
        }
      }
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    paginationFunction();
  }
  @override
  Widget build(BuildContext context) {
    h=MediaQuery.of(context).size.height;
    final leng=ref.watch(lengthProvider);
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.grey.shade200,
        foregroundColor: Colors.black,
        title: Text(
          "Available Courses",
          style: GoogleFonts.lexend(
              fontWeight: FontWeight.w500,
              fontSize: w * 0.045,
              color: Colors.black),
        ),
        centerTitle: false,
      ),
      body: ref.watch(getCourseProvider).when(data: (data) {
        return SizedBox(height: h*0.9,
          child: ListView.builder(
              // shrinkWrap: true,
              padding: EdgeInsets.all(w * 0.05),
              controller:leng< data.length? scrollController:null,
              itemCount:leng< data.length?leng:data.length,
              itemBuilder: (context, index) {
                final course = data[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child:
                    ref.watch(getCourseNameProvider).when(data: (courseName) {
                      return Padding(
                        padding: EdgeInsets.all(w * 0.05),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              '${courseName[course['courseId']]}',
                              style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.bold, fontSize: w * 0.045),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Container(
                              child: Row(
                                children: [
                                  SvgPicture.asset(
                                    'assets/icons/duration.svg',
                                    height: w * 0.03,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    '${course['classDuration']} ${course['monthOrYear']}',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w500,
                                        fontSize: w * 0.03,
                                        color: Colors.grey.shade700),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Container(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SvgPicture.asset(
                                    'assets/icons/univer.svg',
                                    height: w * 0.03,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Expanded(
                                    child: Text(
                                      'Eligibility : ${course['eligibility']}',
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.w500,
                                          fontSize: w * 0.03,
                                          color: Colors.grey.shade700),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/icons/univercity.svg',
                                  height: w * 0.03,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  course['university'],
                                  style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w500,
                                      fontSize: w * 0.03,
                                      color: Colors.grey.shade700),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  '₹ ${course['totalFee'].toStringAsFixed(1)}',
                                  style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w700,
                                      fontSize: w * 0.045,
                                      color: Colors.red),
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => coursesView(
                                              data: course,
                                              course:
                                              courseName[course['courseId']],
                                              courseId: course['courseId'],
                                            )));
                                  },
                                  child: Container(
                                    height: w * .1,
                                    width: w * .3,
                                    decoration: BoxDecoration(
                                      color: primary,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Center(
                                        child: Text(
                                          'View',
                                          style: GoogleFonts.lexend(
                                              fontWeight: FontWeight.bold,
                                              fontSize: w * 0.05,
                                              color: Colors.black),
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                      error: (error, stackTrace) => Text(error.toString()), loading: () => Loader(),)

                  ),
                );
              }),
        );
      },
        error:(error, stackTrace) => Text(error.toString()) , loading: () => Loader(),)

    );
  }
}
