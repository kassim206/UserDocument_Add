import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fpdart/fpdart.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:live_to_smile/Models/enquiry_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/core/constants/firebaseconstants/firebase_constants.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../../core/common/setSearchParameter.dart';
import '../../../core/common/showSnackBar.dart';
import '../../../core/common/showuploadmessage.dart';
import '../../../core/failure.dart';
import '../../../core/routing/routing.dart';
import '../../../core/type_def.dart';
import '../../homepage/screen/home_page.dart';
import '../screen/signup_screen.dart';

final authRepositoryProvider = Provider((ref) {
  return AuthRepository(
    firestore: ref.watch(firestoreProvider),
    auth: ref.watch(authProvider),
    googleSignIn: ref.watch(googleSignInProvider),
  );
});

class AuthRepository {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;
  final GoogleSignIn _googleSignIn;

  AuthRepository(
      {
        required FirebaseFirestore firestore,
        required FirebaseAuth auth,
        required GoogleSignIn googleSignIn})
      : _firestore = firestore,
        _auth = auth,
        _googleSignIn = googleSignIn;

  CollectionReference get _users =>
      _firestore.collection(FirebaseConstants.userCollection);

  CollectionReference get _settings =>
      _firestore.collection(FirebaseConstants.settingsCollection);

  CollectionReference get _enquiry =>
      _firestore.collection(FirebaseConstants.enquiryCollection);

  Stream<User?> get authStateChange => _auth.authStateChanges();

  showError(FirebaseAuthException err, BuildContext context) {
    switch (err.code) {
      case "ERROR_EMAIL_ALREADY_IN_USE":
      case "account-exists-with-different-credential":
      case "email-already-in-use":
        return showSnackbar("Email already used. Go to login page.", context);
      case "ERROR_WRONG_PASSWORD":
      case "wrong-password":
        return showSnackbar("Wrong password .", context);
      case "ERROR_USER_NOT_FOUND":
      case "user-not-found":
        return showSnackbar('No user found with this email', context);
      case "ERROR_USER_DISABLED":
      case "user-disabled":
        return showSnackbar("User disabled.", context);
      case "ERROR_TOO_MANY_REQUESTS":
      case "operation-not-allowed":
        return showSnackbar(
            "Too many requests to log into this account.", context);
      case "ERROR_OPERATION_NOT_ALLOWED":
      case "operation-not-allowed":
        return showSnackbar("Server error, please try again later.", context);
      case "ERROR_INVALID_EMAIL":
      case "invalid-email":
        return showSnackbar("Email address is invalid.", context);
      default:
        return showSnackbar("Login failed. Please try again.", context);
    }
  }

  signInWithEmailAndPass(String email, String pass, BuildContext context) {
    _auth.signInWithEmailAndPassword(email: email, password: pass)
        .then((value) => _users.doc(value.user!.uid).get().then((value) {

          Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => HomePage()));

    })).catchError((e) {
      print("Error Code is ${e.code}");
      showError(e, context);
    });
  }

  getUser(
      String email,
      String password,
      RoundedLoadingButtonController _btnController1,
      BuildContext context) async {
    QuerySnapshot snap = await _users
        .where('email', isEqualTo: email)
        .where('password', isEqualTo: password)
        .get();

    if (snap.docs.isNotEmpty) {
      final SharedPreferences local = await SharedPreferences.getInstance();
      local.setString('id', snap.docs[0].id);
      local.setString('email', email);
      currentUserId = snap.docs[0].id;

      _btnController1.success();

      await Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => BottomBar()), (route) => false);


    } else {
      _btnController1.reset();
      showUploadMessage(context, 'No Users Found...');
    }
  }

  // FutureEither<UsersModel> signInWithGoogle(BuildContext context) async {
  //   try {
  //
  //     GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
  //     GoogleSignInAuthentication? googleAuth = await googleUser
  //         ?.authentication;
  //     AuthCredential credential = GoogleAuthProvider.credential(
  //       accessToken: googleAuth?.accessToken,
  //       idToken: googleAuth?.idToken,
  //     );
  //     UserCredential userCredential =
  //     await FirebaseAuth.instance.signInWithCredential(credential);
  //     UsersModel usersModel;
  //     if (userCredential.additionalUserInfo!.isNewUser) {
  //
  //       Navigator.pushAndRemoveUntil(context, CupertinoPageRoute(builder: (context) =>signupScreen(true,userCredential.user!.email!) ,), (route) => false);
  //
  //       usersModel = UsersModel(
  //         age: 0,
  //           dob: Timestamp.now(),
  //
  //           created_time: Timestamp.now(),
  //           display_name: googleUser!.displayName!,
  //           email: googleUser.email,
  //           password: "",
  //           phoneNo: "",
  //           photo_url: googleUser.photoUrl!,
  //           uid: userCredential.user!.uid,
  //           userName: googleUser.displayName!);
  //     }
  //     else {
  //       usersModel = await getUserData(userCredential.user!.uid).first;
  //     }
  //     var user = await FirebaseFirestore.instance.collection(FirebaseConstants.userCollection)
  //         .where('email',isEqualTo: userCredential.user?.email)
  //         .get();
  //
  //
  //     if(user.docs.isNotEmpty){
  //       Navigator.pushAndRemoveUntil(context, CupertinoPageRoute(builder: (context) =>Splash() ,), (route) => false);
  //
  //     }
  //     else{
  //       Navigator.pushAndRemoveUntil(context, CupertinoPageRoute(builder: (context) =>signupScreen(true,userCredential.user!.email!) ,), (route) => false);
  //
  //     }
  //
  //     return right(usersModel);
  //   } on FirebaseException catch (ex) {
  //     throw ex.message!;
  //   } catch (e) {
  //     return left(Failure(e.toString()));
  //   }
  // }
  FutureEither<UsersModel> signInWithGoogle() async {
    try {
      UserCredential userCredential;

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

      final googleAuth = await googleUser?.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      userCredential =
      await _auth.signInWithCredential(credential);


      UsersModel userModel;

      if (userCredential.additionalUserInfo!.isNewUser) {
        userModel = UsersModel(
            created_time: Timestamp.now(),
            display_name: googleUser!.displayName.toString(),
            email: googleUser.email,
            password: "",
            phoneNo: "",
            photo_url: googleUser.photoUrl.toString(),
            uid: userCredential.user!.uid,
            userName: googleUser.displayName.toString(),
            age: 0,
            dob: Timestamp.now());
        await _users.doc(userCredential.user!.uid).set(userModel.toMap());
      } else {
        userModel = await getUserData(userCredential.user!.uid).first;
      }
      return right(userModel);
    } on FirebaseException catch (e) {
      throw e.message!;
    } catch (e) {
      return left(Failure(e.toString()));
    }
  }

  signOut() async {
    final SharedPreferences local = await SharedPreferences.getInstance();
    local.remove('id');
    local.remove('email');
    // FirebaseAuth.instance.signOut();
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  FutureEither<UsersModel> signUp(String nameRep, Timestamp DOBRep, String EmailRep, String PassRep,
      String PhoneRep, int age) async {
    try {
      final SharedPreferences local = await SharedPreferences.getInstance();

      UsersModel signupModel = await UsersModel(
          created_time: Timestamp.now(),
          display_name: nameRep,
          dob: DOBRep,
          email: EmailRep,
          password: PassRep,
          phoneNo: PhoneRep,
          photo_url: "",
          uid: "",
          userName: nameRep,
          age: age);
      await _users.add(signupModel.toMap()).then((value) async {
        var updateUid = signupModel.copyWith(uid: value.id);
        value.update(updateUid.toMap());

        DocumentSnapshot doc = await _settings.doc('O0juQP9oPBfxZveBeWzn')
            .get();

        doc.reference.update({
          'enquiryId': FieldValue.increment(1),
        });

        int enquiryId = doc['enquiryId'];
        print(doc['enquiryId']);
        enquiryId++;

        EnquiryModel enquiryDetails = EnquiryModel(
            additionalInfo: "",
            branchId: "O0juQP9oPBfxZveBeWzn",
            check: false,
            countryCode: countryCode,
            courses: "",
            date: DateTime.now(),
            dob: DOBRep.toDate(),
            educationalDetails: [],
            email: EmailRep,
            enquiryId: 'E' + 'LTS' + enquiryId.toString(),
            mobile: PhoneRep,
            name: nameRep,
            phoneCode: phoneCode,
            place: "",
            search: setSearchParam(nameRep + " " + PhoneRep),
            status: 0,
            university: "",
            userEmail: EmailRep,
            userId: value.id);

        _enquiry
            .doc('E' + 'LTS' + enquiryId.toString())
            .set(enquiryDetails.toMap());
      });

      return right(signupModel);

    }on FirebaseException catch(e){
      throw  e.message!;

    }catch(e){
      return left(Failure(e.toString()));
    }
  }

  Stream<UsersModel> getUserData(String uid) {
    return _users.doc(uid).snapshots().map((event) => UsersModel.fromMap(event.data() as Map<String, dynamic>));
  }
}
