import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../../core/common/selectDate.dart';
import '../../../core/common/showuploadmessage.dart';
import '../../firstPage/FirstPage.dart';
import '../controller/auth_controller.dart';

String phoneCode = '+91';
String countryCode = 'IN';


class signupScreen extends ConsumerStatefulWidget {
  final bool gSignIn;
  final String email;

   signupScreen( this.gSignIn, this.email, {Key? key}) : super(key: key);

  @override
  ConsumerState<signupScreen> createState() => _signupScreenState();
}

class _signupScreenState extends ConsumerState<signupScreen> {

  TextEditingController firstName=TextEditingController();
  TextEditingController password=TextEditingController();
  TextEditingController password1=TextEditingController();
  TextEditingController email=TextEditingController();
  TextEditingController phoneNo=TextEditingController();
  TextEditingController age=TextEditingController();
  TextEditingController date=TextEditingController();

  int? length;
  DateTime currentDate = DateTime.now();
  bool passwordVisibility = false;
  bool passwordVisibility1 = false;
  DateTime selectedDate = DateTime.now();
  String Countrycode = 'IN';



  List emails = [];

  // Future getEmails() async {
  //   QuerySnapshot data = await FirebaseFirestore.instance
  //       .collection('workShopUser')
  //       .get();
  //   for (DocumentSnapshot doc in data.docs) {
  //     emails.add(doc.get('email'));
  //     if (mounted) {
  //       setState(() {
  //
  //       });
  //     }
  //   }
  //
  // }
signUp(){
  if (password?.text == password1?.text&&password.text!=""&&password1.text!=""&&email?.text!=''&&firstName?.text!=''&&age?.text!=''
      &&phoneNo?.text!=''&&student.docs.isEmpty&&selectedDate!=null) {

    ref.read(authControllerProvider.notifier).signUp(
        firstName.text, Timestamp.fromDate(selectedDate), email.text, password.text, password1.text, int.parse(age.text),context);
}
  else{
    firstName?.text==''?showUploadMessage(context,'Please Enter Your Name')
        :email?.text==''?showUploadMessage(context,'Please Enter Your Email')
        :age?.text==''?showUploadMessage(context,'Please Enter Your Age')
        :selectedDate==null?showUploadMessage(context,'Please Select Birth Date')
        :phoneNo?.text==''?showUploadMessage(context,'Please Enter Mobile Number')
        :password?.text==''?showUploadMessage(context,'Please Enter Password')
        :showUploadMessage(context,'Please Confirm Your Password');

  }
}



  late QuerySnapshot student;
  checkEmail(String email) async {
    student = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: email)
        .get();
    setState(() {});
    if (student.docs.isNotEmpty) {
      print('Contain');
    } else {
      print('noooo');
    }
  }
  @override
  void initState() {
    email.text = widget.email;

    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: h,
              width: w,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [c, c1],
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter),
                  image: DecorationImage(
                      image: AssetImage('assets/icons/splash_back.png'),
                      fit: BoxFit.fill)),
              child: Padding(
                padding: EdgeInsets.only(left: w * .078, right: w * .078),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: h * .1,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: w * .042,
                              child: Center(
                                  child: Icon(
                                    Icons.arrow_circle_left_rounded,
                                    color: c,
                                  )),
                            ),
                          ),
                          SizedBox(
                            width: w * .03,
                          ),
                          Padding(
                            padding: EdgeInsets.only(bottom: h * .007),
                            child: Text(
                              'Back',
                              style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: h * .82,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello there!\nLet’s get introduced.',
                            style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,
                                fontSize: w * .06,
                                color: Colors.black),
                          ),
                          SizedBox(
                            height: h * .034375,
                          ),
                          Text(
                            'What’s your name?',
                            style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,
                                fontSize: w * .034,
                                color: Colors.black),
                          ),
                          SizedBox(
                            height: h * .006875,
                          ),
                          Container(
                            height: h * .06,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(13),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: firstName,
                                style: GoogleFonts.poppins(
                                    color: Color(0xffBBC5CD),
                                    fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Full name",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Color(0xffBBC5CD),
                                      fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .032,
                          ),
                          Text(
                            'What’s your email?',
                            style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,
                                fontSize: w * .034,
                                color: Colors.black),
                          ),
                          SizedBox(
                            height: h * .006875,
                          ),
                          Container(
                            // height: h*.06,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(13),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                readOnly: widget.gSignIn,
                                autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                                validator: (email) {
                                  log('hhhhh');
                                  if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w]{2,4}')
                                      .hasMatch(email!)) {
                                    return "Email not valid";
                                  } else if (student != null &&
                                      student.docs.isNotEmpty) {
                                    return "Email already registered with us";
                                  } else {
                                    return null;
                                  }
                                },
                                onChanged: (text) {
                                  checkEmail(text);
                                },
                                controller: email,
                                style: GoogleFonts.poppins(
                                    color: Color(0xffBBC5CD),
                                    fontSize: w * .039),
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Email",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Color(0xffBBC5CD),
                                      fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .032,
                          ),
                          Text(
                            'Your age and birth date',
                            style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,
                                fontSize: w * .034,
                                color: Colors.black),
                          ),
                          SizedBox(
                            height: h * .006875,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: h * .06,
                                width: w * .2,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(13),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.only(left: w * .028),
                                  child: TextFormField(
                                    maxLines: 1,
                                    //maxLength: 2,
                                    controller: age,
                                    autovalidateMode: AutovalidateMode.onUserInteraction,
                                    style: GoogleFonts.poppins(
                                      color: Color(0xffBBC5CD),
                                      fontSize: w * .039,
                                    ),
                                    keyboardType: TextInputType.number,
                                    validator: (value) {
                                      if (value == null) {
                                        return 'Please enter your age.';
                                      }
                                      final ageValue = int.tryParse(value)??15;
                                      if (ageValue < 15 || ageValue > 99) {
                                        return 'Please enter a valid age between 15 and 99.';
                                      }
                                      return null; // Return null if the input is valid
                                    },
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      focusedBorder: InputBorder.none,
                                      hintText: "Age",
                                      hintStyle: GoogleFonts.poppins(
                                        color: Color(0xffBBC5CD),
                                        fontSize: w * .039,
                                      ),

                                    ),
                                  ),

                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                 selectedDate=await selectDate(context, selectedDate);
                                 setState(() {

                                 });
                                },
                                child: Container(
                                  height: h * .06,
                                  width: w * .55,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(13),
                                  ),
                                  child: Row(
                                    children: [

                                      Container(
                                        width: w * .47,
                                        child: Padding(
                                          padding:
                                          EdgeInsets.only(left: w * .028),
                                          child: Text(
                                            selectedDate.millisecond !=
                                                currentDate.millisecond
                                                ? '${selectedDate.day} | ${selectedDate.month} | ${selectedDate.year}'
                                                : 'Date | Month | Year',
                                            style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w500,
                                                fontSize: w * .034,
                                                color: Color(0xffBBC5CD)),
                                          ),
                                        ),
                                      ),


                                      // Container(
                                      //     height: h*.03,
                                      //     width:  w*.055,
                                      //     child: SvgPicture.asset('assets/images/dateTime.svg'))
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: h * .034375,
                          ),
                          Text(
                            'Phone Number',
                            style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,
                                fontSize: w * .034,
                                color: Colors.black),
                          ),
                          SizedBox(
                            height: h * .006875,
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(13),
                            ),
                            child: Center(
                              child: Padding(
                                padding: EdgeInsets.only(left: w * .028),
                                child: IntlPhoneField(
                                  controller: phoneNo,
                                  inputFormatters: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    hintText: "Phone number",
                                    hintStyle: GoogleFonts.poppins(
                                        color: Color(0xffBBC5CD),
                                        fontSize: w * .039),
                                  ),
                                  initialCountryCode: countryCode,
                                  onCountryChanged: (value) {
                                    length = value.minLength;
                                    Countrycode = value.code;
                                  },


                                  // onChanged: (phone) {
                                  //   phoneCode = phone.countryCode;
                                  //   countryCode = phone.countryISOCode;
                                  //   print(countryCode + '****');
                                  //   setState(() {});
                                  // },
                                ),
                                // TextFormField(
                                //   controller: phoneNo,
                                //   style: GoogleFonts.poppins(
                                //       color: Color(0xffBBC5CD),
                                //       fontSize: w*.039),
                                //   keyboardType: TextInputType.number,
                                //   decoration:   InputDecoration(
                                //     border: InputBorder.none,
                                //     focusedBorder: InputBorder.none,
                                //     hintText: "Phone number",
                                //     hintStyle: GoogleFonts.poppins(
                                //         color: Color(0xffBBC5CD),
                                //         fontSize: w*.039),
                                //
                                //
                                //   ),
                                // ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .0205,
                          ),
                          Container(
                            height: h * .06,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(13),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: password,

                                obscureText: !passwordVisibility,
                                style: GoogleFonts.poppins(
                                    color: Color(0xffBBC5CD),
                                    fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Password",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Color(0xffBBC5CD),
                                      fontSize: w * .039),
                                  filled: true,
                                  fillColor: Colors.white,
                                  suffixIcon: InkWell(
                                    onTap: () => setState(
                                          () => passwordVisibility =
                                      !passwordVisibility,
                                    ),
                                    child: Icon(
                                      passwordVisibility
                                          ? Icons.visibility_outlined
                                          : Icons.visibility_off_outlined,
                                      color: Color(0xffBBC5CD),
                                      size: 22,
                                    ),
                                  ),
                                ),
                                validator: (PassCurrentValue) {
                                  RegExp regex = RegExp(
                                      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                  var passNonNullValue = PassCurrentValue ?? "";
                                  if (passNonNullValue.isEmpty) {
                                    return ("Password is required");
                                  }
                                  else if (passNonNullValue.length < 6) {
                                    return ("Password Must be more than 5 characters");
                                  }
                                  // else if(!regex.hasMatch(passNonNullValue)){
                                  //   return ("Password should contain upper,lower,digit and Special character ");
                                  // }
                                  return null;
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .0205,
                          ),
                          Container(
                            height: h * .06,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(13),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: password1,
                                obscureText: !passwordVisibility1,
                                style: GoogleFonts.poppins(
                                    color: Color(0xffBBC5CD),
                                    fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                validator: (value) {
                                  if (password?.text != password1?.text) {
                                    return "invalid password";
                                  }
                                },
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Confirm Password",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Color(0xffBBC5CD),
                                      fontSize: w * .039),
                                  filled: true,
                                  fillColor: Colors.white,
                                  suffixIcon: InkWell(
                                    onTap: () => setState(
                                          () => passwordVisibility1 =
                                      !passwordVisibility1,
                                    ),
                                    child: Icon(
                                      passwordVisibility1
                                          ? Icons.visibility_outlined
                                          : Icons.visibility_off_outlined,
                                      color: Color(0xffBBC5CD),
                                      size: 22,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: h * .075,
                      child: Center(
                        child: InkWell(
                          onTap: (){
                            signUp();
                          },
                          child: Container(
                            height: h * .06,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(13),
                                color: Color(0xff343434)),
                            child: Center(
                              child: Text(
                                'Sign Up',
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
