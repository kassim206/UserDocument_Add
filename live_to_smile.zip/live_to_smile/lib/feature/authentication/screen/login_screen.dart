import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/core/common/loader.dart';
import 'package:live_to_smile/feature/authentication/screen/signup_screen.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../../core/common/showuploadmessage.dart';
import '../../firstPage/FirstPage.dart';
import '../controller/auth_controller.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  ConsumerState<LoginPage> createState() => _loginPageState();
}

class _loginPageState extends ConsumerState<LoginPage> {
  getUser(String email, String password) async {
    await ref.read(authControllerProvider.notifier)
        .getUser(email, password, _btnController1, context);
  }

  signInWithGoogle(context) {
    ref.read(authControllerProvider.notifier).signInWithGoogle(context,);
  }

  final RoundedLoadingButtonController _btnController1 = RoundedLoadingButtonController();

  final RoundedLoadingButtonController _btnController2 = RoundedLoadingButtonController();

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  void initState() {
    _btnController1.stateStream.listen((value) {
      print(value);
    });
    _btnController2.stateStream.listen((value) {
      print(value);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;
    var w = MediaQuery.of(context).size.width;
    final isLoading=ref.watch(authControllerProvider);

    return Scaffold(
      body:
      // isLoading?
      // const Loader() :
      SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            Container(
              height: h,
              width: w,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [c, c1],
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter),
                  image: DecorationImage(
                      image: AssetImage('assets/icons/splash_back.png'),
                      fit: BoxFit.fill)),
              child: Padding(
                padding: EdgeInsets.only(left: w * .1, right: w * .1),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: h * .01,
                    ),
                    Container(
                      height: h * .8,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Login to the\nworld of\nLivetoSmile',
                            style: GoogleFonts.lexend(
                                fontSize: w * .1,
                                fontWeight: FontWeight.w500,
                                color: Colors.black),
                          ),
                          SizedBox(
                            height: h * .055,
                          ),
                          Container(
                            height: h * .065,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: emailController,
                                style: GoogleFonts.lexend(
                                    color: Color(0xff9E9E9E),
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * .035),
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  contentPadding: EdgeInsets.zero,
                                  hintText: "Email",
                                  hintStyle: GoogleFonts.lexend(
                                      color: Color(0xff9E9E9E),
                                      fontWeight: FontWeight.w500,
                                      fontSize: w * .035),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .0275,
                          ),
                          Container(
                            height: h * .065,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: passwordController,
                                style: GoogleFonts.lexend(
                                    color: Color(0xff9E9E9E),
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * .035),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Password",
                                  hintStyle: GoogleFonts.lexend(
                                      color: Color(0xff9E9E9E),
                                      fontWeight: FontWeight.w500,
                                      fontSize: w * .035),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .0275,
                          ),
                          Container(
                            height: h * .065,
                            child: RoundedLoadingButton(
                              successIcon: Icons.check,
                              failedIcon: Icons.close,
                              color: Color(0xff343434),
                              borderRadius: 7,
                              child: Text(
                                'Continue',
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * .055,
                                    color: Colors.white),
                              ),
                              controller: _btnController1,
                              onPressed: () {
                                if (emailController?.text != '' &&
                                    passwordController?.text != '') {
                                  getUser(emailController.text,
                                      passwordController.text);
                                } else {
                                  _btnController1.reset();
                                  emailController!.text == ''
                                      ? showUploadMessage(
                                          context, 'Please Enter Email')
                                      : showUploadMessage(
                                          context, 'Please Enter Password');
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Center(
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => signupScreen(
                                        false,""
                                      ),
                                    ));
                              },
                              child: Text(
                                'Sign up using Email',
                                style: GoogleFonts.lexend(
                                    fontSize: w * .039,
                                    decoration: TextDecoration.underline,
                                    color: Colors.black),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: h * .03,
                          ),
                          RoundedLoadingButton(
                            successColor: Colors.green,
                            successIcon: Icons.check,
                            failedIcon: Icons.close,
                            color: Colors.white,
                            valueColor: Colors.black,
                            borderRadius: 10,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/icons/google.svg',
                                  height: w * 0.05,
                                ),
                                SizedBox(
                                  width: w * 0.05,
                                ),
                                Text(
                                  'Continue with Google',
                                  style: GoogleFonts.lexend(
                                      fontSize: w * .04, color: Colors.black),
                                ),
                              ],
                            ),
                            controller: _btnController2,
                            onPressed: (){
                              var user;
                              try {
                                signInWithGoogle(context);
                              } catch (e) {
                                _btnController2.reset();
                                setState(() {});
                              }
                              // if(user==null){
                              //
                              //   return;
                              // }
                              //
                              // await Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>  BottomBar()), (route) => false);
                              _btnController2.success();
                            },
                          ),
                          SizedBox(
                            height: h * .01,
                          ),
                          Center(
                            child: Text(
                              'By continuing, you agree to our\nTerms of Service Privacy Policy  Content Policy',
                              style: GoogleFonts.lexend(
                                  fontSize: w * .025, color: Colors.white),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          // SizedBox(
                          //   height: h * .01,
                          // ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
