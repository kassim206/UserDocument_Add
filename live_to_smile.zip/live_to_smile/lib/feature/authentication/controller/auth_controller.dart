import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/core/common/showSnackBar.dart';
import 'package:live_to_smile/feature/authentication/screen/login_screen.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../bottom_bar/bottomBar.dart';
import '../../../core/routing/routing.dart';
import '../repository/auth_repository.dart';

final userProvider = StateProvider<UsersModel?>((ref) {
  return null;
});

final authControllerProvider = StateNotifierProvider<AuthController, bool>(
  (ref) => AuthController(
      authRepository: ref.watch(
        authRepositoryProvider,
      ),
      ref: ref),
);

final authStateChangeProvider = StreamProvider((ref) {
  final authController = ref.watch(authControllerProvider.notifier);
  return authController.authStateChange;
});

final getUserDataProvider = StreamProvider((ref) {
  final authController = ref.watch(authControllerProvider.notifier);
  return authController.getUserData(currentUserId);
});

class AuthController extends StateNotifier<bool> {
  final AuthRepository _authRepository;
  final Ref _ref;
  AuthController({required AuthRepository authRepository, required Ref ref})
      : _authRepository = authRepository,
        _ref = ref,
        super(false);

  Stream<User?> get authStateChange => _authRepository.authStateChange;

  getUser(
      String email,
      String password,
      RoundedLoadingButtonController _btnController1,
      BuildContext context) async {

    final SharedPreferences local = await SharedPreferences.getInstance();
    local.setString("email", email);

    return await _authRepository.getUser(email, password, _btnController1, context);
  }

  void signInWithGoogle(BuildContext context) async {

    state = true;
    final user = await _authRepository.signInWithGoogle();
    state = false;
    user.fold((l) {
      showSnackbar(l.message, context);
      print(l.message);
    }, (userModel) async {
      _ref.read(userProvider.notifier).update((state) => userModel);
      final SharedPreferences local = await SharedPreferences.getInstance();
      local.setString("email", userModel.email);
      local.setString("id", userModel.uid);
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BottomBar(),
          ));
    });
  }

  signOut() {
    return _authRepository.signOut();
  }

  signUp(String nameCon, Timestamp DOBCon, String EmailCon, String PassCon,
      String PhoneCon1, int age, BuildContext context) async {
    final res = await _authRepository.signUp(
        nameCon, DOBCon, EmailCon, PassCon, PhoneCon1, age);
    res.fold((l) => showSnackbar(l.message, context), (r) {

      _ref.read(userProvider.notifier).update((state) => r);

      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => LoginPage(),
          ));
    });
  }

  Stream<UsersModel> getUserData(String userId) {
    return _authRepository.getUserData(userId);
  }
}
