// import 'package:cloud_firestore/cloud_firestore.dart';
//
// import '../../../bottom_bar/bottomBar.dart';
//
// class bottomRepository {
//   final FirebaseFirestore _firestore;
//   bottomRepository({required FirebaseFirestore firestore})
//       : _firestore = firestore;
//   // getUniversity() {
//   //   FirebaseFirestore.instance
//   //       .collection('university')
//   //       .snapshots()
//   //       .listen((event) {
//   //     universityList.clear();
//   //     for (var university in event.docs) {
//   //       universityList.add(university['name']);
//   //       UniversityNameToId[university['name']] = university.id;
//   //       UniversityIdToName[university.id] = university.get('name');
//   //     }
//   //     // if (mounted) {
//   //     //   setState(() {});
//   //     // }
//   //   });
//   // }
//   Stream<List> getUniversity(){
//    return _firestore.collection('university').snapshots().map((event) {
//       universityList.clear();
//       for (var university in event.docs) {
//         universityList.add(university['name']);
//         UniversityNameToId[university['name']] = university.id;
//         UniversityIdToName[university.id] = university.get('name');
//       }
//       return universityList;
//     });
//   }
//   // getCourses() {
//   //   FirebaseFirestore.instance
//   //       .collection('university')
//   //       .snapshots()
//   //       .listen((event) {
//   //     for (DocumentSnapshot data in event.docs) {
//   //       if (data.get('courseList').length != 0) {
//   //         for (var doc in data.get('courseList')) {
//   //           courseList.add({
//   //             'university': data['name'],
//   //             'available': doc['available'],
//   //             'courseId': doc['courseId'],
//   //             'duration': doc['duration'],
//   //             'totalFee': doc['totalFee'],
//   //             'feeList': doc['feeList'],
//   //             'eligibility': doc['eligibility'],
//   //           });
//   //         }
//   //       }
//   //     }
//   //     // if (mounted) {
//   //     //   setState(() {});
//   //     // }
//   //   });
//   // }
//   Stream<List> getCourses(){
//    return _firestore.collection('university').snapshots().map((event) {
//      List courseList = [];
//       for (DocumentSnapshot data in event.docs) {
//         if (data.get('courseList').length != 0) {
//           for (var doc in data.get('courseList')) {
//             courseList.add({
//               'university': data['name'],
//               'available': doc['available'],
//               'courseId': doc['courseId'],
//               'duration': doc['duration'],
//               'totalFee': doc['totalFee'],
//               'feeList': doc['feeList'],
//               'eligibility': doc['eligibility'],
//             });
//           }
//         }
//       };
//      return courseList;
//     });
//   }
//   // getCourseName() {
//   //   FirebaseFirestore.instance.collection('course').snapshots().listen((event) {
//   //     for (DocumentSnapshot doc in event.docs) {
//   //       courseName[doc.id] = doc.get('name');
//   //     }
//   //   });
//   // }
//   Stream <Map> getCourseName(){
//    return _firestore.collection('course').snapshots().map((event) {
//      Map<String,dynamic>courseName={};
//       for (DocumentSnapshot doc in event.docs) {
//         courseName[doc.id] = doc.get('name');
//       };
//       return courseName;
//     });
//   }
//   // getAllCourses() {
//   //   FirebaseFirestore.instance.collection('course').snapshots().listen((event) {
//   //     for (var item in event.docs) {
//   //       CourseNameToId[item.get('name')] = item.id;
//   //       CourseIdToName[item.id] = item.get('name');
//   //       CourseIdToType[item.id] = item.get('courseType');
//   //     }
//   //   });
//   // }
//   Stream<Map> getAllCourses(){
//    return _firestore.collection('course').snapshots().map((event) {
//      Map<String, dynamic> CourseNameToId = {};
//      Map<String, dynamic> CourseIdToName = {};
//      Map<String, dynamic> CourseIdToType = {};
//       for (var item in event.docs) {
//         CourseNameToId[item.get('name')] = item.id;
//         CourseIdToName[item.id] = item.get('name');
//         CourseIdToType[item.id] = item.get('courseType');
//       };
//       return CourseNameToId;
//     });
//   }
//   // getClasses() {
//   //   FirebaseFirestore.instance.collection('class').snapshots().listen((event) {
//   //     classes = [];
//   //     for (var data in event.docs) {
//   //       classMap[data.id] = data.data();
//   //       ClassNameToId[data.get('name')] = data.id;
//   //       ClassIdToName[data.id] = data.get('name');
//   //       if (data.get('available') == true) {
//   //         classes.add(data['name']);
//   //       }
//   //     }
//   //   });
//   // }
//   Stream <List> getClasses(){
//     Map m= {};
//    return _firestore.collection('class').snapshots().map((event) {
//       Map<String, dynamic> ClassNameToId = {};
//       Map<String, dynamic> ClassIdToName = {};
//       Map<String, dynamic> classMap = {};
//       for (var data in event.docs) {
//         classMap[data.id] = data.data();
//         ClassNameToId[data.get('name')] = data.id;
//         ClassIdToName[data.id] = data.get('name');
//         if (data.get('available') == true) {
//           classes.add(data['name']);
//         }
//       };
//       m = {"classNameToId":ClassIdToName,
//           "classMap":classMap,
//         "classIdToName": ClassIdToName,
//       }
//
//       return ;
//     });
//   }
//   // getTutor() {
//   //   FirebaseFirestore.instance
//   //       .collection('admin_users')
//   //       .snapshots()
//   //       .listen((event) {
//   //     classes = [];
//   //     for (var data in event.docs) {
//   //       tutorMap[data.id] = data.data();
//   //       tutor.add(data['display_name']);
//   //     }
//   //   });
//   // }
//   Stream getTutor(){
//    return _firestore.collection('admin_users').snapshots().map((event) {
//        for (var data in event.docs) {
//         tutorMap[data.id] = data.data();
//         tutor.add(data['display_name']);
//       };
//        return tutor;
//     });
//   }
// }
