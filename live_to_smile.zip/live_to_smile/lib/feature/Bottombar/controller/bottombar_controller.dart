// import 'package:live_to_smile/feature/Bottombar/repository/bottombar_repository.dart';
//
// class bottombarController{
//   final bottomRepository _repository;
//   bottombarController({required bottomRepository repository}):
//       _repository = repository;
//
//   Stream<List>getUniversity(){
//     return _repository.getUniversity();
//   }
//   Stream<List> getCourses(){
//     return _repository.getCourses();
//   }
//   Stream <Map> getCourseName(){
//     return _repository.getCourseName();
//   }
//  Stream getTutor(){
//   return  _repository.getTutor();
//   }
// }