import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../bottom_bar/bottomBar.dart';

class SliderPage extends StatelessWidget {
  final String title;
  final String image;
  final String description;
  const SliderPage({Key? key, required this.title,
    required this.image,
    required this.description})
      : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Container(
      height: h,
      width: w,
      decoration: BoxDecoration(

      ),
      child: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,

            children: [
              SizedBox(
                height: h*.1,
              ),
              Container(
                height: h*.55,
                width: w,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/icons/$image'),
                        fit: BoxFit.contain
                    )
                ),
              ),

              // Padding(
              //   padding:  EdgeInsets.only(left: w*.084,right: w*.084),
              //   child:
              //   Container(
              //     height: h*.35,
              //     width: w,
              //     decoration: BoxDecoration(
              //       color: Colors.white,
              //
              //       borderRadius: BorderRadius.circular(40),
              //     ),
              //     child: Column(
              //       mainAxisAlignment: MainAxisAlignment.spaceAround,
              //       children: [
              //         SizedBox(height: h*.007,),
              //         Text(title, style: GoogleFonts.lexend(
              //
              //             fontWeight: FontWeight.w500,
              //             fontSize: w*.069,
              //             color: Colors.black
              //         ),
              //           textAlign: TextAlign.center,
              //
              //         ),
              //
              //         Text(description,
              //           style: GoogleFonts.lexend(
              //               fontSize: w*.039,
              //               color: Colors.black
              //           ),
              //           textAlign: TextAlign.center,
              //
              //         ),
              //         SizedBox(height: h*.007,),
              //         SizedBox(height: h*.007,),
              //
              //       ],
              //     ),
              //   ),
              //
              //
              //
              // ),
            ],
          ),
            //   Positioned(
            //     bottom: 10,
            //     child: Text(title, style: GoogleFonts.lexend(
            //
            //       fontWeight: FontWeight.w500,
            //       fontSize: w*.069,
            //       color: Colors.black
            // ),
            //     textAlign: TextAlign.center,
            //
            // ),
            //   ),
        ],
      ),
    );
  }
}