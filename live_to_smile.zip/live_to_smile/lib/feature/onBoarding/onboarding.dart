import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/feature/authentication/screen/login_screen.dart';
import 'package:live_to_smile/feature/onBoarding/slider.dart';
import '../../bottom_bar/bottomBar.dart';
import '../firstPage/FirstPage.dart';


class OnBoarding extends StatefulWidget {
  const OnBoarding({Key? key}) : super(key: key);

  @override
  State<OnBoarding> createState() => _OnBoardingState();
}

class _OnBoardingState extends State<OnBoarding> {

  int _currentpage=0;
  PageController _controller=PageController();
  List<Widget> pages=[
    SliderPage(
        title: "Grow fast with\nLivetosmile",
        image:"grow.png",
        description: "Inlcuding the ever best classes for our\nstudents. And also highly experienced\nteachers."
    ),
    SliderPage(
        title: "Live online\nClassrooms",
        image: "onlineClass.png",
        description: "A Virtual Classroom is a digital\nreplace of a traditional classroom."
    ),
    SliderPage(
        title: "Previous Classes\navailable",
        image: "prev_Class.png",
        description: "You can save or wishlist the\nprevious live session classes."
    ),
  ];

  Onchange(int index){
    setState(() {
      _currentpage=index;
    });
  }

  @override
  Widget build(BuildContext context) {
    h= MediaQuery.of(context).size.height;
    w=MediaQuery.of(context).size.width;
    return Scaffold(
      body:  Container(
        height: h,width: w,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment(0, 1),
            colors: <Color>[
              Color(0xffFFEC6E),
              Color(0xffFEDE00),
            ], // Gradient from https://learnui.design/tools/gradient-generator.html
            tileMode: TileMode.mirror,
          ),
        ),
        child: Stack(
          children: [
            PageView.builder(
              scrollDirection: Axis.horizontal,
              controller: _controller,
              onPageChanged: (index){
                setState(() {
                  _currentpage=index;
                });
                _controller.animateToPage(
                  index,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeInOutSine,
                );
              },
              itemCount: pages.length,

              itemBuilder: (context,index){
                return pages[index];

              },

            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: w*0.75,width: w*0.95,

                child: Stack(
                  children: [
                    Center(
                      child: Container(
                        width:  w*0.85,
                        height:  w*0.7,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _currentpage==0? Text('Grow fast with\nLivetosmile',style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,color: Colors.black,
                                fontSize: w*0.05
                            ),textAlign: TextAlign.center,):
                            _currentpage==1? Text('Live online\nClassrooms',style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,color: Colors.black,
                                fontSize: w*0.05
                            ),textAlign: TextAlign.center,):
                            Text('Previous Classes\navailable',style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w500,color: Colors.black,
                                fontSize: w*0.05
                            ),textAlign: TextAlign.center,),

                            _currentpage==0?Text('Inlcuding the ever best classes for our\nstudents. And also highly experienced\nteachers.',style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w400,color: Colors.black,
                                fontSize: w*0.03
                            ),textAlign: TextAlign.center,):
                            _currentpage==1?Text('A Virtual Classroom is a digital\nreplace of a traditional classroom.',style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w400,color: Colors.black,
                                fontSize: w*0.03
                            ),textAlign: TextAlign.center,):
                            Text('You can save or wishlist the\nprevious live session classes.',style: GoogleFonts.lexend(
                                fontWeight: FontWeight.w400,color: Colors.black,
                                fontSize: w*0.03
                            ),textAlign: TextAlign.center,),
                            Bounce(
                              duration: Duration(milliseconds: 110),
                              onPressed: () {
                                if(_currentpage==2){
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                                }else{
                                  setState(() {
                                    _currentpage++;
                                  });
                                  _controller.animateToPage(
                                    _currentpage,
                                    duration: const Duration(milliseconds: 250),
                                    curve: Curves.easeInOutSine,
                                  );
                                }
                              },
                              child: Container(
                                decoration: _currentpage==2?BoxDecoration(
                                  color:_currentpage==2?Color(0xff343434): Color(0xff343434).withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(15),
                                  boxShadow: [
                                    BoxShadow(
                                      color:Colors.grey.shade400,
                                      offset: const Offset(
                                        5.0,
                                        3.0,
                                      ),
                                      blurRadius: 15.0,
                                      spreadRadius: 0.0,
                                    ), //BoxShadow
                                    //BoxShadow
                                  ],
                                ):BoxDecoration(
                                  color: Color(0xff343434).withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(15),

                                ),
                                child: Padding(
                                  padding:  EdgeInsets.fromLTRB(
                                    w*0.075,
                                    w*0.025,
                                    w*0.075,
                                    w*0.025,
                                  ),
                                  child: Text('Get Started',style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w500,color: Colors.white,
                                      fontSize: w*0.05
                                  ),textAlign: TextAlign.center,),
                                ),
                              ),
                            ),

                          ],
                        ),
                      ),
                    ),
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _currentpage==2||_currentpage==1? Bounce(
                            duration: Duration(milliseconds: 110),
                            onPressed: (){
                              setState(() {
                                _currentpage--;
                              });
                              _controller.animateToPage(
                                _currentpage,
                                duration: const Duration(milliseconds: 250),
                                curve: Curves.easeInOutSine,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(blurRadius: 2, color: Color(0xff343434).withOpacity(.10), spreadRadius: 2)],
                              ),
                              child: CircleAvatar(
                                backgroundColor: Colors.white,
                                radius: w*.045,
                                child:Center(child: Icon(Icons.arrow_circle_left_rounded,color: c,)) ,
                              ),
                            ),
                          ):Container(),
                          _currentpage==0||_currentpage==1?Bounce(
                            duration: Duration(milliseconds: 110),
                            onPressed: () {
                              setState(() {
                                _currentpage++;
                              });
                              _controller.animateToPage(
                                _currentpage,
                                duration: const Duration(milliseconds: 250),
                                curve: Curves.easeInOutSine,
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(blurRadius: 2, color: Color(0xff343434).withOpacity(.10), spreadRadius: 2)],
                              ),
                              child: CircleAvatar(
                                backgroundColor: Colors.white,
                                radius: w*.045,
                                child:Center(child: Icon(Icons.arrow_circle_right_rounded,color: c,)) ,
                              ),
                            ),
                          ):Container(),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )



          ],
        ),
      ),


    );
  }
}