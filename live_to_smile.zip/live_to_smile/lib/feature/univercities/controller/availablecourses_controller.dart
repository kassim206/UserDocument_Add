import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/university_model.dart';
import '../repository/availablecourses_repository.dart';

final getUniversityProvider=StreamProvider((ref) => ref.read(courseControllerProvider).getUniversity());
 final courseControllerProvider=Provider((ref) {
  return CourseController(courseRepository: ref.read(courseRepositoryProvider));
 });
class CourseController{
final CourseRepository _courseRepository;
CourseController({
    required CourseRepository courseRepository,
}):
      _courseRepository=courseRepository;

Stream<List<UniversityModel>>getUniversity(){
  return _courseRepository.getUniversity();
}
}