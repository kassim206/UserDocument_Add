import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/university_model.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';

final courseRepositoryProvider = StateProvider((ref) {
  return CourseRepository(
    firestore: ref.read(firestoreProvider),
  );
});

class CourseRepository {
  final FirebaseFirestore _firestore;

  CourseRepository({
    required FirebaseFirestore firestore,
  }) : _firestore = firestore;

  Stream<List<UniversityModel>> getUniversity() {
    return _firestore
        .collection('university')
        .where('available', isEqualTo: true)
        .snapshots()
        .map((event) {
      List<UniversityModel> university = [];
      for (var i in event.docs) {
        university.add(UniversityModel.fromMap(i.data()));
      }
      return university;
    });
  }
}
