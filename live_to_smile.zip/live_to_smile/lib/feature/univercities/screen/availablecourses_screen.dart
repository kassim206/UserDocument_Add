import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/core/common/loader.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../UniCourse/screen/uni_screen.dart';
import '../controller/availablecourses_controller.dart';

final lengthAvailProvider = StateProvider<int>((ref) {
  return 5;
});

class Universities extends ConsumerStatefulWidget {
  const Universities({Key? key}) : super(key: key);

  @override
  ConsumerState<Universities> createState() => _UniversitiesState();
}

class _UniversitiesState extends ConsumerState<Universities> {
  final ScrollController scrollController = ScrollController();
  double previousScroll = 0;
  bool isLoading = false;

  paginationFunction() {
    scrollController.addListener(() {
      double maxScroll = scrollController.position.maxScrollExtent;
      double currentScroll = previousScroll + scrollController.position.pixels;
      double delta = MediaQuery.of(context).size.height * 0.20;
      if (!isLoading) {
        if (maxScroll - currentScroll <= delta &&
            currentScroll > previousScroll) {
          isLoading = true;
          Future.delayed(const Duration(seconds: 1, microseconds: 500))
              .then((value) {
            ref.read(lengthAvailProvider.notifier).update((state) => state + 1);
            isLoading = false;
          });
        }
      }
      previousScroll = currentScroll;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    paginationFunction();
  }

  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    final len = ref.watch(lengthAvailProvider);

    return Scaffold(
        backgroundColor: Colors.grey.shade200,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.grey.shade200,
          foregroundColor: Colors.black,
          title: Text(
            "Available Universities",
            style: GoogleFonts.lexend(
                fontWeight: FontWeight.w500,
                fontSize: w * 0.045,
                color: Colors.black),
          ),
          centerTitle: false,
        ),
        body: ref.watch(getUniversityProvider).when(
              data: (data) {
                return Column(
                  children: [
                    Expanded(
                      // height: h * 0.9,
                      child: ListView.builder(
                        physics: BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics()),
                        controller: len < data.length ? scrollController : null,
                        itemCount: len < data.length ? len : data.length,
                        padding: EdgeInsets.all(w * 0.05),
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Bounce(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => UniCourses(
                                              data: data[index],
                                            )));
                              },
                              duration: Duration(milliseconds: 100),
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding: EdgeInsets.all(w * 0.05),
                                  child: Row(
                                    children: [
                                      SvgPicture.asset(
                                        'assets/icons/univer.svg',
                                        height: w * 0.1,
                                        color: Colors.red,
                                      ),
                                      SizedBox(
                                        width: w * 0.05,
                                      ),
                                      Expanded(
                                          child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.stretch,
                                        children: [
                                          Text(
                                            data[index].name,
                                            style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w600,
                                                fontSize: w * 0.035),
                                          ),
                                          SizedBox(
                                            height: w * 0.02,
                                          ),
                                          Text(
                                            data[index]
                                                    .courseList
                                                    .length
                                                    .toString() +
                                                ' Courses',
                                            style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w600,
                                                fontSize: w * 0.03,
                                                color: Colors.grey.shade600),
                                          )
                                        ],
                                      ))
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    if (isLoading) const Loader()
                  ],
                );
              },
              error: (error, stackTrace) {
                print(stackTrace);
                return Text(error.toString());
              },
              loading: () => Loader(),
            ));
  }
}
