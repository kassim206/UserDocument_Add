import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../bottom_bar/bottomBar.dart';

Color c = Color(0xffFEDE00);
Color c1 = Color(0xffFFEC6E);

class FirstPage extends ConsumerStatefulWidget {
  const FirstPage({Key? key}) : super(key: key);

  @override
 ConsumerState<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends ConsumerState<FirstPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: h,
        width: w,
        decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [c, c1],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: h * .55,
              width: w,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/grow.png'),
                      fit: BoxFit.contain)),
            ),
            Stack(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: w * .084, right: w * .084),
                  child: Container(
                    height: h * .35,
                    width: w,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        SizedBox(
                          height: h * .007,
                        ),
                        Text(
                          'Grow fast with\nLivetosmile',
                          style: GoogleFonts.lexend(
                              fontWeight: FontWeight.w500,
                              fontSize: w * .069,
                              color: Colors.black),
                          textAlign: TextAlign.center,
                        ),
                        Text(
                          'Inlcuding the ever best classes for our\nstudents. And also highly experienced\nteachers.',
                          style: GoogleFonts.lexend(
                              fontSize: w * .039, color: Colors.black),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(
                          height: h * .007,
                        ),
                        Container(
                          height: h * .07,
                          width: w * .695,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(18),
                            color: Color(0xff343434).withOpacity(.35),
                            shape: BoxShape.rectangle,
                            boxShadow: [
                              BoxShadow(
                                  blurRadius: 2,
                                  color: Color(0xff343434).withOpacity(.10),
                                  spreadRadius: 2)
                            ],
                          ),
                          child: Center(
                            child: Text(
                              'Get Started',
                              style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w500,
                                  fontSize: w * .069,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: h * .007,
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  right: w * .045,
                  top: h * .17,
                  child: InkWell(
                    onTap: () {
                      // Navigator.push(context, MaterialPageRoute(builder: (c)=>SecondPage()));
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                              blurRadius: 2,
                              color: Color(0xff343434).withOpacity(.10),
                              spreadRadius: 2)
                        ],
                      ),
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: w * .042,
                        child: Center(
                            child: Icon(
                          Icons.arrow_circle_right_rounded,
                          color: c,
                        )),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
