import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/deactivate_request_model.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';

final deleteAccountRepositoryProvider=Provider((ref) {
  return DeleteAccountRepository(firestore: ref.read(firestoreProvider));
});


class DeleteAccountRepository {
  final FirebaseFirestore _firestore;

  DeleteAccountRepository({
    required FirebaseFirestore firestore,
  }) :
        _firestore=firestore;


  get(DeactivateRequest a) {
    FirebaseFirestore.instance
        .collection('deactivateRequest')
        .add(a.toMap());
  }
}


