import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/feature/deleteAccount/repository/deleteAccount_controller.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../../core/routing/routing.dart';
import '../../authentication/controller/auth_controller.dart';

class DeleteAccount extends ConsumerStatefulWidget {
  const DeleteAccount({Key? key}) : super(key: key);

  @override
  ConsumerState<DeleteAccount> createState() => _DeleteAccountState();
}

class _DeleteAccountState extends ConsumerState<DeleteAccount> {
  UsersModel? user;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController email = TextEditingController();
  TextEditingController phone = TextEditingController();

  void showUploadMessage(BuildContext context, String message,
      {bool showLoading = false}) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          duration: showLoading ? Duration(minutes: 30) : Duration(seconds: 4),
          content: Row(
            children: [
              if (showLoading)
                Padding(
                  padding: EdgeInsets.only(right: 10.0),
                  child: CircularProgressIndicator(),
                ),
              Text(message),
            ],
          ),
        ),
      );
  }

  @override
  void initState() {
    super.initState();
    user = ref.read(userProvider);
    email = TextEditingController();
    phone = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    // final currentUserPhone=ref.read(currentUserPhoneProvider);

    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: true,
        backgroundColor: back,
        title: Text(
          'Deactivate Account',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Disclaimer :',
                  style: TextStyle(fontSize: 13),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'We will delete the following data stored in LTS APP/WEBSITE\n\n* Remove your Account from LTS App/website\n* Remove Your Profile Data\n* Remove all your privileges related to this account, if any\n\nNote: You will no longer be able to continue on our LTS APP/WEBSITE, If you would like to use our service again, Please register again from our APP/WEBSITE.',
                  style: TextStyle(fontSize: 13),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Please fill the forms',
                  style: TextStyle(fontSize: 13),
                ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: TextFormField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Email',
                      labelStyle: TextStyle(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFF57636C),
                        fontSize: 13,
                        fontWeight: FontWeight.normal,
                      ),
                      hintText: 'Please Enter Email Address',
                      hintStyle: TextStyle(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFF57636C),
                        fontSize: 13,
                        fontWeight: FontWeight.normal,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xFFDBE2E7),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xFFDBE2E7),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(24, 24, 20, 24),
                    ),
                    style: TextStyle(
                      fontFamily: 'Lexend Deca',
                      color: Color(0xFF1D2429),
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: TextFormField(
                    controller: phone,
                    keyboardType: TextInputType.number,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Mobile No',
                      labelStyle: TextStyle(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFF57636C),
                        fontSize: 13,
                        fontWeight: FontWeight.normal,
                      ),
                      hintText: 'Please Enter Mobile Number',
                      hintStyle: TextStyle(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFF57636C),
                        fontSize: 13,
                        fontWeight: FontWeight.normal,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xFFDBE2E7),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xFFDBE2E7),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(24, 24, 20, 24),
                    ),
                    style: TextStyle(
                      fontFamily: 'Lexend Deca',
                      color: Color(0xFF1D2429),
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        print(user!.phoneNo);
                        print(user!.email);
                        if (email.text != '' && phone.text != '') {
                          if (email.text == user!.email &&
                              phone.text == user!.phoneNo) {
                            showDialog(
                                context: context,
                                builder: (buildContext) {
                                  return AlertDialog(
                                    title: Text('Send Request'),
                                    content: Text('Do you want to Confirm'),
                                    actions: [
                                      TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          child: Text('cancel')),
                                      Consumer(
                                        builder: (context, ref, child) {
                                          return TextButton(
                                              onPressed: () {
                                                ref
                                                    .watch(
                                                        DeleteAccountControllerProvider)
                                                    .get(
                                                        date: DateTime.now(),
                                                        uid: currentUserId,
                                                        email: user!.email,
                                                        pno: phone.text,
                                                        status: 0);

                                                Navigator.pop(context);
                                                Navigator.pop(context);
                                                showUploadMessage(
                                                    context, 'Request Send');

                                                //
                                                // FirebaseFirestore.instance
                                                //     .collection('deactivateRequest')
                                                //     .add({
                                                //   'date':DateTime.now(),
                                                //   'userId':currentUserId,
                                                //   'email':user!.email,
                                                //   'phone':phone.text,
                                                //   'status':0,
                                                // });
                                              },
                                              child: Text('Confirm'));
                                        },
                                      ),
                                    ],
                                  );
                                });
                          }
                          else {
                            showUploadMessage(
                                context, 'Wrong Email Address or Mobile No');
                          }
                        } else {
                          email.text == ''
                              ? showUploadMessage(context, 'Please Enter Email')
                              : showUploadMessage(
                                  context, 'Please Enter Mobile No');
                        }
                      },
                      child: Container(
                        child: Center(
                          child: Text(
                            'Request',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                        // color: Colors.red,
                        height: 50,
                        width: 250,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(12)),
                            color: Colors.red),
                      ),
                    )
                    // FFButtonWidget(
                    //   onPressed: ()  {
                    //     print(currentUserUid);
                    //     print(currentUserEmail);
                    //     print(currentPhoneNumber);
                    //
                    //     if(email.text!=''&&phone.text!=''){
                    //
                    //       if(email.text==currentUserEmail&&phone.text==currentPhoneNumber){
                    //
                    //         showDialog(context: context,
                    //             builder: (buildContext){
                    //               return AlertDialog(
                    //                 title: Text('Deactivate Account'),
                    //                 content: Text('Do you Want to Confirm?'),
                    //                 actions: [
                    //                   TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Cancel')),
                    //                   TextButton(onPressed: () async {
                    //
                    //                     DocumentSnapshot doc =await FirebaseFirestore.instance.collection('users').doc(currentUserUid).get();
                    //
                    //
                    //
                    //
                    //
                    //
                    //                     FirebaseFirestore.instance.collection('deletedUsers').doc(currentUserUid).set(doc.data());
                    //
                    //
                    //
                    //                     b2b=false;
                    //                     otpSession="";
                    //                     otpNo="";
                    //                     status="";
                    //                     // UserService _userService = UserService();
                    //                     // await _userService.logOut(context);
                    //
                    //                     if(b2b==true){
                    //
                    //                       await  FirebaseFirestore.instance.collection('b2bRequests').doc(currentUserUid).update({
                    //                         'status':5,
                    //                       });
                    //
                    //                     }
                    //
                    //                     await  doc.reference.delete();
                    //                     FirebaseAuth.instance.currentUser.delete();
                    //
                    //                     currentUserModel=null;
                    //                     await Navigator.pushReplacement(
                    //                       context,
                    //                       MaterialPageRoute(
                    //                           builder: (context) => LoginPage()
                    //                       ),
                    //
                    //                     );
                    //
                    //
                    //                   }, child: Text('Confirm'))
                    //                 ],
                    //               );
                    //             });
                    //
                    //
                    //       }else{
                    //         email.text!=currentUserEmail?
                    //         showUploadMessage(context, 'Please Enter Valid Email'):
                    //         showUploadMessage(context, 'Please Enter Valid Mobile no');
                    //       }
                    //
                    //     }else{
                    //       email.text==''?showUploadMessage(context, 'Please Enter Email Address'):
                    //       showUploadMessage(context, 'Please Enter Mobile Number');
                    //     }
                    //
                    //
                    //
                    //
                    //
                    //   },
                    //   text: 'Deactivate',
                    //   options: Container(
                    //     width: 130,
                    //     height: 40,
                    //     color: Colors.red,
                    //
                    //   ),
                    // ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
