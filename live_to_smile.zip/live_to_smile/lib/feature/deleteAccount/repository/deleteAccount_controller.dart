import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/deactivate_request_model.dart';
import 'package:live_to_smile/feature/deleteAccount/controller/deletAccount_repository.dart';

final DeleteAccountControllerProvider=Provider((ref) {
  return DeleteAccountController(deleteAccountRepository: ref.read(deleteAccountRepositoryProvider));
});

class DeleteAccountController {
  DeleteAccountRepository _deleteAccountRepository;

  DeleteAccountController({
    required DeleteAccountRepository deleteAccountRepository,
  }) :_deleteAccountRepository=deleteAccountRepository;


  get(
      {required DateTime date, required String uid, required String email, required String pno, required int status}) {
    DeactivateRequest data = DeactivateRequest(
      userId: uid, email: email, phone: pno, status: status,);
  }

}





