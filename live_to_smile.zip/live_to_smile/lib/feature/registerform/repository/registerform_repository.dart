// import 'dart:typed_data';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:live_to_smile/core/providers/firebase_providers.dart';
// import 'package:mime_type/mime_type.dart';
//
//
// final registerFormRepositoryProvider=Provider((ref) {
// return  RegisterFormRepository(firestore: ref.read(firestoreProvider), storage: ref.read(storageProvider));
// });
// class RegisterFormRepository{
//    final FirebaseFirestore _firestore;
//    final FirebaseStorage _storage;
//    RegisterFormRepository({
//      required FirebaseFirestore firestore,
//      required FirebaseStorage storage,
// }):
//        _firestore=firestore,
//    _storage=storage;
//
//    List<String> intakes = ['Select Intake'];
//    Map<String, dynamic> intakesId = {};
//    String inTakeId = '';
//
//    getIntakes() {
//      FirebaseFirestore.instance
//          .collection('intakes').where('available',isEqualTo: true)
//          .snapshots()
//          .listen((event) {
//        intakes = [];
//        for (DocumentSnapshot doc in event.docs) {
//          intakes.add(doc.get('intakeName'));
//          intakesId[doc.get('intakeName')] = doc.id;
//        }
//
//
//      });
//    }
//    Map<String, dynamic> universityId = {};
//
//    getUniversity() {
//      FirebaseFirestore.instance
//          .collection('university')
//          .snapshots()
//          .listen((event) {
//        for (DocumentSnapshot doc in event.docs) {
//          universityId[doc.get('name')] = doc.id;
//        }
//      });
//    }
//
//    late QuerySnapshot student;
//    checkEmail(String email) async {
//      student = await FirebaseFirestore.instance
//          .collection('candidates')
//          .where('email', isEqualTo: email)
//          .where('active', isEqualTo: true)
//          .get();
//
//    }
//    Future uploadData(String path, Uint8List data) async {
//      final storageRef = FirebaseStorage.instance.ref().child(path);
//      final metadata = SettableMetadata(contentType: mime(path));
//      final result = await storageRef.putData(data, metadata);
//      return result.state == TaskState.success ? result.ref.getDownloadURL() : null;
//    }
//
// }