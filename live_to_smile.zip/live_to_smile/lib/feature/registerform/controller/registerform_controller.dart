// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:live_to_smile/feature/registerform/repository/registerform_repository.dart';
//
// final registerFormControllerProvider = Provider((ref) => RegisterFormController(
//     registerFormRepository: ref.read(registerFormRepositoryProvider)));
//
// class RegisterFormController {
//   final RegisterFormRepository _registerFormRepository;
//   RegisterFormController({
//     required RegisterFormRepository registerFormRepository,
//   }) : _registerFormRepository = registerFormRepository;
//
//   getIntakes() {
//     return _registerFormRepository.getIntakes();
//   }
//
//   getUniversity() {
//     return _registerFormRepository.getUniversity();
//   }
//
//   checkEmail(String email) {
//     return _registerFormRepository.checkEmail(email);
//   }
//   pickgallery(){
//
//   }
//
// }
