// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:live_to_smile/feature/registerform/controller/registerform_controller.dart';
// import 'package:razorpay_flutter/razorpay_flutter.dart';
// import 'package:rounded_loading_button/rounded_loading_button.dart';
// import '../../../Models/user_model.dart';
// import '../../../bottom_bar/bottomBar.dart';
// import '../../../core/common/showuploadmessage.dart';
//
// class RegisterFormScreen extends ConsumerStatefulWidget {
//
//   final dynamic data;
//   final String? course;
//   final String? courseId;
//   const RegisterFormScreen(this.data, this.course, this.courseId, {super.key});
//
//
//   @override
//   ConsumerState<RegisterFormScreen> createState() => _RegisterFormScreenState();
// }
//
// class _RegisterFormScreenState extends ConsumerState<RegisterFormScreen> {
//   UsersModel? user;
//   TextEditingController firstName = TextEditingController();
//   TextEditingController lastName = TextEditingController();
//   TextEditingController email = TextEditingController();
//   TextEditingController mobile = TextEditingController();
//   TextEditingController place = TextEditingController();
//   TextEditingController classController = TextEditingController();
//   TextEditingController address = TextEditingController();
//   TextEditingController university = TextEditingController();
//   TextEditingController course = TextEditingController();
//   TextEditingController classControlller = TextEditingController();
//   TextEditingController intakeCtlr = TextEditingController();
//   TextEditingController admissionFee = TextEditingController();
//   TextEditingController universityFee = TextEditingController();
//   TextEditingController tuitionFee = TextEditingController();
//   TextEditingController convacationFee = TextEditingController();
//   TextEditingController amount = TextEditingController();
//   TextEditingController totalFee = TextEditingController();
//   DateTime selectedDate = DateTime.now();
//   DateTime currentDate = DateTime.now();
//
//   String phoneCode = '+91';
//   String countryCode = 'IN';
//
//
//   selectDate(BuildContext context) async {
//     final DateTime? selected = await showDatePicker(
//       context: context,
//       initialDate: selectedDate,
//       firstDate: DateTime(1950),
//       lastDate: DateTime(2050),
//     );
//     if (selected != null && selected != selectedDate) {
//       setState(() {
//         selectedDate = selected;
//       });
//     }
//   }
//   List Ug = ['Signature', 'SSLC', 'Plus two', 'Aadhaar/Passport'];
//   List Pg = [
//     'Signature',
//     'SSLC',
//     'Plus two',
//     'Aadhaar/Passport',
//     'Degree certificate',
//     'Degree marksheet'
//   ];
//   List SSLC = [
//     'Signature',
//     '8 th marksheet/self attested certificate',
//     'Aadhaar/Passport'
//   ];
//   List plusTwo = ['Signature', 'SSLC', 'Aadhaar/Passport'];
//
//   List<String> classList = ['Select Batch'];
//
//
//   DateTime? dob;
//
//   Map documents = {};
//   String uploadedFileUrl = '';
//
//   bool document = true;
//   bool showUniversity = true;
//   bool feeDetails = true;
//   bool radioSelected1 = true;
//   bool cash = false;
//   bool bank = true;
//   String radioval = 'Bank';
//   bool radioSelected2 = true;
//   bool male = false;
//   bool female = false;
//   bool other = false;
//   String radioval2 = '';
//   double convectionFee = 0;
//   double addmissionFees = 0;
//   double univFee = 0;
//   double tuision = 0;
//   double total = 0;
//   final RoundedLoadingButtonController _btnController1 =
//   RoundedLoadingButtonController();
//   final RoundedLoadingButtonController _btnController2 =
//   RoundedLoadingButtonController();
//   setSearchParam(String caseNumber) {
//     List<String> caseSearchList = <String>[];
//     String temp = "";
//
//     List<String> nameSplits = caseNumber.split(" ");
//     for (int i = 0; i < nameSplits.length; i++) {
//       String name = "";
//
//       for (int k = i; k < nameSplits.length; k++) {
//         name = name + nameSplits[k] + " ";
//       }
//       temp = "";
//
//       for (int j = 0; j < name.length; j++) {
//         temp = temp + name[j];
//         caseSearchList.add(temp.toUpperCase());
//       }
//     }
//     return caseSearchList;
//   }
// getUniversity(){
//     ref.read(registerFormControllerProvider).getUniversity();
// }
// getIntakes(){
//     ref.read(registerFormControllerProvider).getIntakes();
// }
// checkEmail(){
//     ref.read(registerFormControllerProvider).checkEmail(email.text);
// }
//
//   getFees() {
//     convectionFee =
//         double.parse(widget.data['feeList'][0]['convactionFee'].toString());
//     addmissionFees =
//         double.parse(widget.data['feeList'][0]['admissionFee'].toString());
//     univFee =
//         double.parse(widget.data['feeList'][0]['universityFee'].toString());
//     tuision = double.parse(widget.data['feeList'][0]['tuitionFee'].toString());
//     total = double.parse(widget.data['feeList'][0]['totalFee'].toString());
//     setState(() {});
//   }
//
//
//
//   String imageUrl = "";
//   TextEditingController subject = TextEditingController();
//   TextEditingController discription = TextEditingController();
//
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     _btnController1.stateStream.listen((value) {
//       print(value);
//     });
//     _btnController2.stateStream.listen((value) {
//       print(value);
//     });
//
//     _razorpay = Razorpay();
//     _razorpay?.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
//     _razorpay?.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
//     _razorpay?.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
//     getIntakes();
//     getFees();
//     getEnguiry();
//     getUniversity();
//     getClass(widget.data['university'], widget.courseId!);
//     firstName = TextEditingController(text: '');
//     lastName = TextEditingController(text: '');
//     email = TextEditingController(text:user!.email);
//     mobile = TextEditingController(text: '');
//     place = TextEditingController(text: '');
//     classController = TextEditingController();
//     address = TextEditingController();
//     university = TextEditingController(text: widget.data['university']);
//     course = TextEditingController(text: widget.course);
//     classControlller = TextEditingController();
//     intakeCtlr = TextEditingController();
//     admissionFee =
//         TextEditingController(text: addmissionFees.toStringAsFixed(1));
//     universityFee = TextEditingController(text: univFee.toStringAsFixed(1));
//     tuitionFee = TextEditingController(text: tuision.toStringAsFixed(2));
//     convacationFee =
//         TextEditingController(text: convectionFee.toStringAsFixed(1));
//     totalFee = TextEditingController(text: total.toStringAsFixed(1));
//     amount = TextEditingController(text: total.toStringAsFixed(1));
//   }
//   Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
//     //  DocumentSnapshot doc = await FirebaseFirestore.instance
//     //      .collection('settings')
//     //      .doc('O0juQP9oPBfxZveBeWzn')
//     //      .get();
//     //  FirebaseFirestore.instance
//     //      .collection('settings')
//     //      .doc('O0juQP9oPBfxZveBeWzn')
//     //      .update({
//     //    'studentId': FieldValue.increment(1),
//     //  });
//     //  int studentId = doc.get('studentId');
//     //  studentId++;
//     //
//     //  List tuitionFeeList = [];
//     //  if (tuitionFee?.text != '') {
//     //    tuitionFeeList.add({
//     //      'date': Timestamp.now(),
//     //      'amount': double.tryParse(amount.text),
//     //      'modeOfPayment': radioval,
//     //      'paymentId': response.paymentId,
//     //      'userId': currentUserId
//     //    });
//     //  }
//     //
//     //  List paymentList = [];
//     //  paymentList.add({
//     //    'admissionFee': double.tryParse(admissionFee.text),
//     //    'universityFee': double.tryParse(universityFee.text),
//     //    'currentYearTotalFee': double.tryParse(totalFee.text),
//     //    'scholarship': 0,
//     //    'paymentId': response.paymentId,
//     //    'date': Timestamp.now(),
//     //    'tuitionFee': tuitionFeeList,
//     //    'convocationFee': double.tryParse(convacationFee.text) ?? 0,
//     //  });
//     //
//     //  List list = [
//     //    {
//     //      'name': 'Personal Details',
//     //      'completed': false,
//     //    },
//     //    {
//     //      'name': 'Fee Details',
//     //      'completed': false,
//     //    },
//     //    {
//     //      'name': 'Classes',
//     //      'completed': false,
//     //    },
//     //    {
//     //      'name': 'Documents',
//     //      'completed': false,
//     //    },
//     //  ];
//     //
//     // await FirebaseFirestore.instance
//     //      .collection('candidates')
//     //      .doc('LTS' + studentId.toString())
//     //      .set({
//     //    'enquiryId': enquiryId[currentUserEmail],
//     //    'form': list,
//     //    'date': DateTime.now(),
//     //    'status': 0,
//     //    'name': firstName.text,
//     //    'lastName': lastName.text,
//     //    'mobile': mobile.text,
//     //    'countryCode': countryCode,
//     //    'phoneCode': phoneCode,
//     //    'email': email.text,
//     //    'dob': selectedDate,
//     //    'place': place.text,
//     //    'educationalDetails': [],
//     //    'address': address.text,
//     //    'gender': radioval2,
//     //    'branchId': 'O0juQP9oPBfxZveBeWzn',
//     //    'userId': currentUserId,
//     //    'currentStatus': 'Registered',
//     //    'scholarship': '',
//     //    'search': setSearchParam(firstName.text + ' ' + mobile.text),
//     //    'photo': imageUrl,
//     //    'studentId': 'LTS' + studentId.toString(),
//     //    'discount': 0.0,
//     //    'dueDate': DateTime.now(),
//     //    'classId': ClassNameToId[classController?.text],
//     //    'inTake': inTakeId,
//     //    'course': widget.courseId,
//     //    'university': universityId[widget.data['university']],
//     //    'documents': data,
//     //    'currentYear': 1,
//     //    'courseDuration': widget.data['duration'],
//     //    'feeDetails': paymentList,
//     //    'verified': 0,
//     //    'active': true,
//     //  }).then((value) {
//     //    if (enquiryId[currentUserEmail] != null) {
//     //      FirebaseFirestore.instance
//     //          .collection('enquiry')
//     //          .doc(enquiryId[currentUserEmail])
//     //          .update({
//     //        'status': 1,
//     //        'studentId': 'LTS' + studentId.toString(),
//     //      });
//     //    }
//     //
//     //    List StudentList = [];
//     //    StudentList.add('LTS' + studentId.toString());
//     //
//     //    FirebaseFirestore.instance
//     //        .collection('class')
//     //        .doc(ClassNameToId[classController?.text])
//     //        .update({
//     //      'students': FieldValue.arrayUnion(['LTS' + studentId.toString()]),
//     //    });
//     //  });
//     //  register_student(course.text,intakeCtlr.text,[email.text],firstName.text+lastName.text);
//     showUploadMessage(context, 'New Student Registered...');
//     Navigator.pushAndRemoveUntil(
//       context,
//       MaterialPageRoute(
//           builder: (context) => BottomBar(
//             bIndex: 0,
//           )),
//           (b) => false,
//     );
//   }
//
//   void _handlePaymentError(PaymentFailureResponse response) {
//     Fluttertoast.showToast(backgroundColor: Colors.red, msg: "Payment Failed");
//     _btnController1.error();
//     _btnController1.reset();
//   }
//
//   void _handleExternalWallet(ExternalWalletResponse response) {
//     Fluttertoast.showToast(
//         msg: "EXTERNAL_WALLET: " + response.walletName!,
//         toastLength: Toast.LENGTH_SHORT);
//   }
//   Razorpay? _razorpay;
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey.shade200,
//       appBar: AppBar(
//         backgroundColor: Colors.grey.shade200,
//         elevation: 0,
//         leading: InkWell(
//             onTap: () {
//               Navigator.pop(context);
//             },
//             child: Icon(
//               Icons.arrow_back,
//               color: Colors.black,
//             )),
//         title: Text(
//           'Registration Form',
//           style: GoogleFonts.lexend(
//               fontWeight: FontWeight.w500,
//               fontSize: w * 0.04,
//               color: Colors.black),
//         ),
//         centerTitle: true,
//       ),
//       body: classList.isEmpty?Center(child: CircularProgressIndicator()): SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.only(left: 15, right: 15, top: 15),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: [
//               imageUrl == ''
//                   ? InkWell(
//                 onTap: () {
//                   showDialog(
//                     context: context,
//                     builder: (ctx) => AlertDialog(
//                       title: const Text("Image"),
//                       content: Container(
//                         height: MediaQuery.of(context).size.height * 0.15,
//                         child: Column(
//                           mainAxisAlignment:
//                           MainAxisAlignment.spaceBetween,
//                           children: [
//                             TextButton(
//                               onPressed: () {
//                                 pickGellary();
//                                 Navigator.pop(context);
//                               },
//                               child: Container(
//                                 height:
//                                 MediaQuery.of(context).size.height *
//                                     0.03,
//                                 width: MediaQuery.of(context).size.width *
//                                     0.2,
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(8),
//                                   color: Colors.blueGrey,
//                                 ),
//                                 child: Center(
//                                   child: Text(
//                                     "Gallery",
//                                     style: TextStyle(
//                                         color: Colors.white,
//                                         fontSize: 18),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                             TextButton(
//                               onPressed: () async {
//                                 pickFiles();
//                                 Navigator.pop(context);
//                               },
//                               child: Container(
//                                 height:
//                                 MediaQuery.of(context).size.height *
//                                     0.03,
//                                 width: MediaQuery.of(context).size.width *
//                                     0.2,
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(8),
//                                   color: Colors.blueGrey,
//                                 ),
//                                 child: Center(
//                                   child: Text("Camera",
//                                       style: TextStyle(
//                                           color: Colors.white,
//                                           fontSize: 18)),
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   );
//                 },
//                 child: Container(
//                   width: w * 0.5,
//                   height: w * 0.5,
//                   decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(10),
//                       color: Colors.white,
//                       border: Border.all(color: Color(0xffD8D8D8))),
//                   child: Stack(
//                     children: [
//                       Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         crossAxisAlignment: CrossAxisAlignment.stretch,
//                         children: [
//                           SvgPicture.asset(
//                             'assets/icons/photo.svg',
//                             color: Color(0xffD8D8D8),
//                           ),
//                           SizedBox(
//                             height: w * 0.02,
//                           ),
//                           Center(
//                             child: Text(
//                               'Upload photo',
//                               style: GoogleFonts.lexend(
//                                   fontWeight: FontWeight.w400,
//                                   fontSize: w * 0.03,
//                                   color: Color(0xffD8D8D8)),
//                             ),
//                           ),
//                         ],
//                       ),
//                       imageStatus == 1
//                           ? Center(
//                           child: CircularProgressIndicator(
//                             color: Colors.black,
//                           ))
//                           : Container(),
//                     ],
//                   ),
//                 ),
//               )
//                   : Container(
//                 width: w * 0.5,
//                 height: w * 0.5,
//                 decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(10),
//                     border: Border.all(color: Color(0xffD8D8D8)),
//                     image: DecorationImage(
//                         image: CachedNetworkImageProvider(imageUrl),
//                         fit: BoxFit.cover)),
//               ),
//               // imageUrl==''? InkWell(
//               //   onTap: () {
//               //
//               //     showDialog(
//               //       context: context,
//               //       builder: (ctx) => AlertDialog(
//               //         title: const Text("Image"),
//               //         content: Container(
//               //           height: MediaQuery.of(context).size.height*0.15,
//               //           child: Column(
//               //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               //             children: [
//               //               TextButton(
//               //                 onPressed: () {
//               //                   pickGellary();
//               //                   Navigator.pop(context);
//               //                 },
//               //                 child: Container(
//               //                   height: MediaQuery.of(context).size.height * 0.03,
//               //                   width: MediaQuery.of(context).size.width * 0.2,
//               //                   decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),color:Colors.blueGrey,),
//               //                   child: Center(
//               //                     child: Text(
//               //                       "Gallery",
//               //                       style: TextStyle( color:Colors.white, fontSize: 18),
//               //                     ),
//               //                   ),
//               //                 ),
//               //               ),
//               //               TextButton(
//               //                 onPressed: () async {
//               //                   pickFiles();
//               //                   Navigator.pop(context);
//               //                 },
//               //                 child: Container(
//               //                   height: MediaQuery.of(context).size.height * 0.03,
//               //                   width: MediaQuery.of(context).size.width * 0.2,
//               //                   decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color:Colors.blueGrey,),
//               //                   child: Center(
//               //                     child: Text("Camera",
//               //                         style: TextStyle( color:Colors.white, fontSize: 18)),
//               //                   ),
//               //                 ),
//               //               ),
//               //             ],
//               //           ),
//               //         ),
//               //       ),
//               //     );
//               //   },
//               //   child: Container(
//               //     height: MediaQuery.of(context).size.height*0.07,
//               //     decoration: BoxDecoration(
//               //       color: primary,
//               //       borderRadius: BorderRadius.circular(8),
//               //     ),
//               //     child: Center(
//               //       child: Text(
//               //         'Upload Image',
//               //         style: TextStyle(
//               //             color: Colors.black, fontSize: 18),
//               //       ),
//               //     ),
//               //   ),
//               // ):CachedNetworkImage(imageUrl: imageUrl,),
//               SizedBox(
//                 height: w * .03,
//               ),
//
//               Container(
//                 height: 50,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(
//                     color: Color(0xFFE6E6E6),
//                   ),
//                 ),
//                 child: Padding(
//                   padding: EdgeInsets.only(left: w * .028),
//                   child: TextFormField(
//                     controller: firstName,
//                     style: GoogleFonts.poppins(
//                         color: Colors.black, fontSize: w * .039),
//                     keyboardType: TextInputType.name,
//                     decoration: InputDecoration(
//                       border: InputBorder.none,
//                       focusedBorder: InputBorder.none,
//                       hintText: "First name",
//                       hintStyle: GoogleFonts.poppins(
//                           color: Colors.black, fontSize: w * .039),
//                     ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .03,
//               ),
//               Container(
//                 height: 50,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(
//                     color: Color(0xFFE6E6E6),
//                   ),
//                 ),
//                 child: Padding(
//                   padding: EdgeInsets.only(left: w * .028),
//                   child: TextFormField(
//                     controller: lastName,
//                     style: GoogleFonts.poppins(
//                         color: Colors.black, fontSize: w * .039),
//                     keyboardType: TextInputType.name,
//                     decoration: InputDecoration(
//                       border: InputBorder.none,
//                       focusedBorder: InputBorder.none,
//                       hintText: "Last name",
//                       hintStyle: GoogleFonts.poppins(
//                           color: Colors.black, fontSize: w * .039),
//                     ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .03,
//               ),
//
//               Container(
//                 // height: 50,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(
//                     color: Color(0xFFE6E6E6),
//                   ),
//                 ),
//                 child: Padding(
//                   padding: EdgeInsets.only(left: w * .028),
//                   child: TextFormField(
//                     controller: email,
//                     autovalidateMode: AutovalidateMode.onUserInteraction,
//                     validator: (email) {
//                       if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w]{2,4}')
//                           .hasMatch(email!)) {
//                         return "Email not valid";
//                       } else if (student != null && student.docs.isNotEmpty) {
//                         return "Email already registered with us";
//                       } else {
//                         return null;
//                       }
//                     },
//                     onChanged: (text) {
//                       checkEmail(text);
//                     },
//                     style: GoogleFonts.poppins(
//                         color: Colors.black, fontSize: w * .039),
//                     keyboardType: TextInputType.name,
//                     decoration: InputDecoration(
//                       border: InputBorder.none,
//                       focusedBorder: InputBorder.none,
//                       hintText: "Email",
//                       hintStyle: GoogleFonts.poppins(
//                           color: Colors.black, fontSize: w * .039),
//                     ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .03,
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text('Male'),
//                   SizedBox(
//                     width: 5,
//                   ),
//                   Radio(
//                     activeColor: Colors.yellow,
//                     fillColor: MaterialStateProperty.all(Colors.black),
//                     overlayColor: MaterialStateProperty.all(Colors.grey[200]),
//                     focusColor: Colors.green,
//                     value: male,
//                     onChanged: (bool? value) {
//                       setState(() {
//                         value = true;
//                         male = value!;
//                         other = false;
//                         female = false;
//                         radioval2 = 'Male';
//                         print(radioval2);
//                         radioSelected2 = value!;
//                       });
//                     },
//                     groupValue: radioSelected2,
//                   ),
//                   SizedBox(
//                     width: 10,
//                   ),
//                   Text('Female'),
//                   SizedBox(
//                     width: 5,
//                   ),
//                   Radio(
//                     activeColor: Colors.yellow,
//                     fillColor: MaterialStateProperty.all(Colors.black),
//                     overlayColor: MaterialStateProperty.all(Colors.grey[200]),
//                     focusColor: Colors.green,
//                     value: female,
//                     onChanged: (bool? value) {
//                       value = true;
//                       setState(() {
//                         radioval2 = 'Female';
//                         print(radioval2);
//                         female = value!;
//                         male = false;
//                         other = false;
//                         radioSelected2 = value;
//                       });
//                     },
//                     groupValue: radioSelected2,
//                   ),
//                   SizedBox(
//                     width: 10,
//                   ),
//                   Text('other'),
//                   SizedBox(
//                     width: 5,
//                   ),
//                   Radio(
//                     activeColor: Colors.yellow,
//                     fillColor: MaterialStateProperty.all(Colors.black),
//                     overlayColor: MaterialStateProperty.all(Colors.grey[200]),
//                     focusColor: Colors.green,
//                     value: other,
//                     onChanged: (bool? value) {
//                       value = true;
//                       setState(() {
//                         radioval2 = 'Other';
//                         print(radioval2);
//                         other = value!;
//                         male = false;
//                         female = false;
//                         radioSelected2 = value;
//                       });
//                     },
//                     groupValue: radioSelected2,
//                   ),
//                 ],
//               ),
//
//               SizedBox(
//                 height: w * .03,
//               ),
//
//               InkWell(
//                 onTap: () {
//                   selectDate(context);
//                 },
//                 child: Container(
//                   height: h * .06,
//                   decoration: BoxDecoration(
//                     color: Colors.white,
//                     borderRadius: BorderRadius.circular(8),
//                     border: Border.all(
//                       color: Color(0xFFE6E6E6),
//                     ),
//                   ),
//                   child: Row(
//                     children: [
//                       Container(
//                         width: w * .47,
//                         child: Padding(
//                           padding: EdgeInsets.only(left: w * .028),
//                           child: Text(
//                             selectedDate.millisecond != currentDate.millisecond
//                                 ? '${selectedDate.day} | ${selectedDate.month} | ${selectedDate.year}'
//                                 : 'Date | Month | Year',
//                             style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w500,
//                               fontSize: w * .034,
//                               color: Colors.black,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .03,
//               ),
//               Container(
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(
//                     color: Color(0xFFE6E6E6),
//                   ),
//                 ),
//                 child: Center(
//                   child: Padding(
//                     padding: EdgeInsets.only(left: w * .028),
//                     child: IntlPhoneField(
//                       controller: mobile,
//                       decoration: InputDecoration(
//                         border: InputBorder.none,
//                         // focusedBorder: InputBorder.none,
//                         hintText: "Phone number",
//                         hintStyle: GoogleFonts.poppins(
//                             color: Color(0xffBBC5CD), fontSize: w * .039),
//                       ),
//                       initialCountryCode: countryCode,
//                       onChanged: (phone) {
//                         phoneCode = phone.countryCode;
//                         countryCode = phone.countryISOCode;
//                         log(countryCode + '****');
//                         log(phoneCode + '****');
//                         setState(() {});
//                       },
//                     ),
//                     // TextFormField(
//                     //   controller: mobile,
//                     //   style: GoogleFonts.poppins(
//                     //       color: Colors.black,
//                     //       fontSize: w*.039),
//                     //   keyboardType: TextInputType.number,
//                     //   decoration:   InputDecoration(
//                     //     border: InputBorder.none,
//                     //     focusedBorder: InputBorder.none,
//                     //     hintText: "Mobile number",
//                     //     hintStyle: GoogleFonts.poppins(
//                     //         color:Colors.black,
//                     //         fontSize: w*.039),
//                     //
//                     //
//                     //   ),
//                     // ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .03,
//               ),
//               Container(
//                 height: 100,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(
//                     color: Color(0xFFE6E6E6),
//                   ),
//                 ),
//                 child: Padding(
//                   padding: EdgeInsets.only(left: w * .028),
//                   child: TextFormField(
//                     controller: address,
//                     style: GoogleFonts.poppins(
//                         color: Colors.black, fontSize: w * .039),
//                     keyboardType: TextInputType.name,
//                     decoration: InputDecoration(
//                       border: InputBorder.none,
//                       focusedBorder: InputBorder.none,
//                       hintText: "Address",
//                       hintStyle: GoogleFonts.poppins(
//                           color: Colors.black, fontSize: w * .039),
//                     ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .03,
//               ),
//               Container(
//                 height: 50,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(8),
//                   border: Border.all(
//                     color: Color(0xFFE6E6E6),
//                   ),
//                 ),
//                 child: Padding(
//                   padding: EdgeInsets.only(left: w * .028),
//                   child: TextFormField(
//                     controller: place,
//                     style: GoogleFonts.poppins(
//                         color: Colors.black, fontSize: w * .039),
//                     keyboardType: TextInputType.name,
//                     decoration: InputDecoration(
//                       border: InputBorder.none,
//                       focusedBorder: InputBorder.none,
//                       hintText: "Place",
//                       hintStyle: GoogleFonts.poppins(
//                           color: Colors.black, fontSize: w * .039),
//                     ),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 height: w * .05,
//               ),
//               InkWell(
//                 onTap: () {
//                   showUniversity = !showUniversity;
//
//                   setState(() {});
//                 },
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text(
//                       'University',
//                       style: GoogleFonts.poppins(
//                         color: Colors.grey,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                     Icon(
//                       Icons.keyboard_arrow_down,
//                       color: Colors.black,
//                     )
//                   ],
//                 ),
//               ),
//
//               showUniversity == true
//                   ? Container(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: university,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.name,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "University",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: course,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.name,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "Course",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//
//                     Container(
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: const Color(0xffFFFFFF),
//                         border: Border.all(
//                             color: const Color(0xffEAEAEA), width: 2),
//                       ),
//                       child: CustomDropdown.search(
//                         controller: intakeCtlr,
//                         items: intakes,
//                         hintText: "Select Intake",
//                         // suggestions: intakes,
//                         // hint: 'Choose the In takes',
//                         // searchStyle: TextStyle(
//                         //   fontSize: 15,
//                         //   color: Colors.black,
//                         // ),
//                         // maxSuggestionsInViewPort: 3,
//                         // suggestionState: SuggestionState.enabled,
//                         // searchInputDecoration: InputDecoration(
//                         //   focusedBorder: OutlineInputBorder(
//                         //     borderSide: BorderSide(
//                         //       color: Colors.black,
//                         //     ),
//                         //   ),
//                         // ),
//                         onChanged: (x) {
//                           inTakeId = intakesId[x];
//
//                           print(inTakeId);
//                           setState(() {});
//                         },
//                       ),
//                     ),
//
//                     // Container(
//                     //   decoration: BoxDecoration(
//                     //     borderRadius: BorderRadius.circular(10),
//                     //     color: const Color(0xffFFFFFF),
//                     //     border: Border.all(
//                     //         color: const Color(0xffEAEAEA), width: 2),
//                     //   ),
//                     //   child: SearchField(
//                     //     controller: intakeCtlr,
//                     //     suggestions: intakes,
//                     //     hint: 'Choose the In takes',
//                     //     searchStyle: TextStyle(
//                     //       fontSize: 15,
//                     //       color: Colors.black,
//                     //     ),
//                     //     maxSuggestionsInViewPort: 3,
//                     //     suggestionState: SuggestionState.enabled,
//                     //     searchInputDecoration: InputDecoration(
//                     //       focusedBorder: OutlineInputBorder(
//                     //         borderSide: BorderSide(
//                     //           color: Colors.black,
//                     //         ),
//                     //       ),
//                     //     ),
//                     //     onTap: (x) {
//                     //       inTakeId = intakesId[x];
//                     //
//                     //       print(inTakeId);
//                     //       setState(() {});
//                     //     },
//                     //   ),
//                     // ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                     classList.isNotEmpty?
//                     Container(
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: const Color(0xffFFFFFF),
//                         border: Border.all(
//                             color: const Color(0xffEAEAEA), width: 2),
//                       ),
//                       child: CustomDropdown.search(
//                         controller: classController,
//                         items: classList,
//                         hintText: "Select Batch",
//                         onChanged: (x) {
//                           setState(() {});
//                         },
//                       ),
//                       // child: SearchField(
//                       //   controller: classController,
//                       //   suggestions: classList,
//                       //   hint: 'Choose the Class',
//                       //   searchStyle: TextStyle(
//                       //     fontSize: 15,
//                       //     color: Colors.black,
//                       //   ),
//                       //   maxSuggestionsInViewPort: 3,
//                       //   suggestionState: SuggestionState.enabled,
//                       //   searchInputDecoration: InputDecoration(
//                       //     focusedBorder: OutlineInputBorder(
//                       //       borderSide: BorderSide(
//                       //         color: Colors.black,
//                       //       ),
//                       //     ),
//                       //   ),
//                       //   onTap: (x) {
//                       //     setState(() {});
//                       //   },
//                       // ),
//                     )
//                         :Container(
//                       height: 50,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: const Color(0xffFFFFFF),
//                         border: Border.all(
//                             color: const Color(0xffEAEAEA), width: 2),
//                       ),
//                       child: Center(
//                           child: Text('No batch found for the selected course',
//                             style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),)
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                   ],
//                 ),
//               )
//                   : Container(
//                 height: w * .02,
//               ),
//
//               InkWell(
//                 onTap: () {
//                   document = !document;
//
//                   setState(() {});
//                 },
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text(
//                       'Documents',
//                       style: GoogleFonts.poppins(
//                         color: Colors.grey,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                     Icon(
//                       Icons.keyboard_arrow_down,
//                       color: Colors.black,
//                     )
//                   ],
//                 ),
//               ),
//
//               document == true
//                   ? Container(
//                 width: w,
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     // SizedBox(
//                     //   child:DataTable(
//                     //     horizontalMargin: 30,
//                     //     columnSpacing: 30,
//                     //     columns: [
//                     //       DataColumn(
//                     //         label: Text(
//                     //           "Document Name",
//                     //           style: TextStyle(
//                     //               fontWeight: FontWeight.bold, fontSize: 15),
//                     //         ),
//                     //       ),
//                     //       DataColumn(
//                     //         label:  Text(
//                     //           "upload",
//                     //           style: TextStyle(
//                     //               fontWeight: FontWeight.bold, fontSize: 15),
//                     //         ),
//                     //       ),
//                     //
//                     //     ],
//                     //     rows: List.generate(
//                     //       uploadDocument.length,
//                     //           (index) {
//                     //         var docName = uploadDocument[index];
//                     //         print(data.keys.toList());
//                     //
//                     //
//                     //         return DataRow(
//                     //           color: index.isOdd
//                     //               ? MaterialStateProperty.all(Colors
//                     //               .blueGrey.shade50
//                     //               .withOpacity(0.7))
//                     //               : MaterialStateProperty.all(
//                     //               Colors.blueGrey.shade50),
//                     //           cells: [
//                     //             DataCell(SelectableText(
//                     //               docName,
//                     //               style: GoogleFonts.poppins(
//                     //                 color: Colors.black,
//                     //                 fontSize: 11,
//                     //                 fontWeight: FontWeight.bold,
//                     //               ),
//                     //             )),
//                     //             DataCell( Padding(
//                     //               padding: EdgeInsetsDirectional.fromSTEB(0, 0, 8, 0),
//                     //               child:
//                     //               InkWell(
//                     //                 onTap: () async {
//                     //                   showUploadMessage(context, 'please upload ${docName}');
//                     //                     selectFile(docName.toUpperCase());
//                     //                     setState(() {
//                     //
//                     //                     });
//                     //
//                     //                 },
//                     //                 child: Container(
//                     //                   height: 40,
//                     //                   width: 100,
//                     //                   decoration: BoxDecoration(
//                     //                     borderRadius: BorderRadius.circular(10),
//                     //                     color: data.keys.toList().contains(docName.toString().toUpperCase())? Color(0xFF4B39EF):Colors.teal,
//                     //                   ),
//                     //                   child: Center(
//                     //                     child: Text(
//                     //                         data.keys.toList().contains(docName.toString().toUpperCase())?'edit':'Upload'  ,
//                     //                     style: GoogleFonts.poppins( color: Colors.white,
//                     //                 fontSize: 12,
//                     //                 fontWeight: FontWeight.bold,),),
//                     //                   ),
//                     //                 ),
//                     //               ),
//                     //
//                     //             )),
//                     //
//                     //           ],
//                     //         );
//                     //       },
//                     //     ),
//                     //   ),
//                     // ),
//
//                     SizedBox(
//                       child: GridView.builder(
//                         gridDelegate:
//                         SliverGridDelegateWithFixedCrossAxisCount(
//                             childAspectRatio: 1,
//                             crossAxisCount: 3,
//                             crossAxisSpacing: 5,
//                             mainAxisSpacing: 10),
//                         itemCount: uploadDocument.length,
//                         physics: NeverScrollableScrollPhysics(),
//                         shrinkWrap: true,
//                         itemBuilder: (context, index) {
//                           return InkWell(
//                             onTap: () {
//                               selectFile(
//                                   uploadDocument[index].toUpperCase());
//                               setState(() {});
//                             },
//                             child: Container(
//                               decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(10),
//                                   color: Colors.white,
//                                   image: data.keys.toList().contains(
//                                       uploadDocument[index]
//                                           .toString()
//                                           .toUpperCase())
//                                       ? DecorationImage(
//                                       image:
//                                       CachedNetworkImageProvider(
//                                           data[uploadDocument[
//                                           index]
//                                               .toUpperCase()]))
//                                       : null,
//                                   border: Border.all(
//                                       color: Color(0xffD8D8D8))),
//                               child: Container(
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(10),
//                                   color: data.keys.toList().contains(
//                                       uploadDocument[index]
//                                           .toString()
//                                           .toUpperCase())
//                                       ? Colors.black.withOpacity(0.5)
//                                       : Colors.black.withOpacity(0),
//                                 ),
//                                 child: Stack(
//                                   children: [
//                                     Column(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.center,
//                                       crossAxisAlignment:
//                                       CrossAxisAlignment.stretch,
//                                       children: [
//                                         SvgPicture.asset(
//                                           'assets/icons/photo.svg',
//                                           color: Color(0xffD8D8D8),
//                                         ),
//                                         SizedBox(
//                                           height: w * 0.02,
//                                         ),
//                                         Center(
//                                           child: Text(
//                                             uploadDocument[index],
//                                             style: GoogleFonts.lexend(
//                                                 fontWeight:
//                                                 FontWeight.w400,
//                                                 fontSize: w * 0.03,
//                                                 color: data.keys
//                                                     .toList()
//                                                     .contains(
//                                                     uploadDocument[
//                                                     index]
//                                                         .toString()
//                                                         .toUpperCase())
//                                                     ? Colors.white
//                                                     : Colors
//                                                     .grey.shade500),
//                                             textAlign: TextAlign.center,
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                     selected ==
//                                         '${uploadDocument[index].toString().toUpperCase()}0'
//                                         ? Center(
//                                         child:
//                                         CircularProgressIndicator(
//                                           color: Colors.black,
//                                         ))
//                                         : Container()
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           );
//                         },
//                       ),
//                     ),
//
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                   ],
//                 ),
//               )
//                   : Container(
//                 height: w * .02,
//               ),
//
//               InkWell(
//                 onTap: () {
//                   print(feeDetails);
//                   feeDetails = !feeDetails;
//
//                   setState(() {});
//                   print(feeDetails);
//                 },
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text(
//                       'Fee Details',
//                       style: GoogleFonts.poppins(
//                         color: Colors.grey,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                     Icon(
//                       Icons.keyboard_arrow_down,
//                       color: Colors.black,
//                     )
//                   ],
//                 ),
//               ),
//               feeDetails == true
//                   ? Container(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text('Admission Fees'),
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: admissionFee,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.name,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "Admission Fees",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                     Text('University Fees'),
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: universityFee,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.name,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "University Fees",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                     Text('Convocation Fees'),
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: convacationFee,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.name,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "Convocation Fees",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                     Text(
//                         'Tuition Fees  ( ₹${tuision.toStringAsFixed(2)} )'),
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: tuitionFee,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.numberWithOptions(),
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "Tuition Fees",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     Padding(
//                       padding: EdgeInsets.all(w * .01),
//                       child: Text(
//                         'Minimum ₹${(tuision * 50 / 100).toStringAsFixed(2)} (50% of tuition fee) will pay',
//                         style: GoogleFonts.lexend(fontSize: 12),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                     Text('Total Fees'),
//                     Container(
//                       height: 50,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(8),
//                         border: Border.all(
//                           color: Color(0xFFE6E6E6),
//                         ),
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.only(left: w * .028),
//                         child: TextFormField(
//                           controller: totalFee,
//                           enableInteractiveSelection: false,
//                           enabled: false,
//                           style: GoogleFonts.poppins(
//                               color: Colors.black, fontSize: w * .039),
//                           keyboardType: TextInputType.name,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             focusedBorder: InputBorder.none,
//                             hintText: "Total Fees",
//                             hintStyle: GoogleFonts.poppins(
//                                 color: Colors.black, fontSize: w * .039),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       height: w * .03,
//                     ),
//                   ],
//                 ),
//               )
//                   : Container(
//                 height: w * .03,
//               ),
//
//               RoundedLoadingButton(
//                 successIcon: Icons.check,
//                 failedIcon: Icons.close,
//                 valueColor: Colors.black,
//                 color: Color(0xffFEDE00),
//                 child: Text('Register and Pay\n₹${(total.toStringAsFixed(2))}',
//                     textAlign: TextAlign.center,
//                     style: GoogleFonts.lexend(
//                         color: Colors.black, fontWeight: FontWeight.bold)),
//                 controller: _btnController1,
//                 onPressed: () async {
//                   if (firstName.text != '' &&
//                       lastName.text != '' &&
//                       mobile.text != '' &&
//                       email.text != '' &&
//                       imageUrl != '' &&
//                       selectedDate != '' &&
//                       address?.text != '' &&
//                       place?.text != '' &&
//                       inTakeId != '' &&
//                       admissionFee?.text != '' &&
//                       universityFee != '' &&
//                       radioval2 != '') {
//                     await addPayments();
//                     _btnController1.reset();
//                   } else {
//                     print(dob);
//                     _btnController1.reset();
//
//                     firstName.text == ''
//                         ? Fluttertoast.showToast(
//                         msg: 'Please Enter First Name',
//                         backgroundColor: Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER)
//                         : lastName.text == ''
//                         ? Fluttertoast.showToast(
//                         msg: 'Please Enter Last Name',
//                         backgroundColor: Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER)
//                         : mobile.text == ''
//                         ? Fluttertoast.showToast(
//                         msg: 'Please Enter Mobile Number',
//                         backgroundColor: Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER)
//                         : email.text == ''
//                         ? Fluttertoast.showToast(
//                         msg: 'Please Enter Email',
//                         backgroundColor: Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER)
//                         : course.text == ''
//                         ? Fluttertoast.showToast(
//                         msg: 'Please Select Class',
//                         backgroundColor: Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER)
//                         : inTakeId == ''
//                         ? Fluttertoast.showToast(
//                         msg: 'Please Select Intake',
//                         backgroundColor: Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER)
//                         : selectedDate == null
//                         ? Fluttertoast.showToast(
//                         msg:
//                         'Please Select Date of Birth',
//                         backgroundColor: Colors.red,
//                         toastLength:
//                         Toast.LENGTH_LONG,
//                         gravity:
//                         ToastGravity.CENTER)
//                         : address.text == ''
//                         ? Fluttertoast.showToast(
//                         msg:
//                         'Please Enter Address',
//                         backgroundColor:
//                         Colors.red,
//                         toastLength:
//                         Toast.LENGTH_LONG,
//                         gravity:
//                         ToastGravity.CENTER)
//                         : place.text == ''
//                         ? Fluttertoast.showToast(
//                         msg:
//                         'Please Enter Place',
//                         backgroundColor:
//                         Colors.red,
//                         toastLength: Toast
//                             .LENGTH_LONG,
//                         gravity:
//                         ToastGravity
//                             .CENTER)
//                         : radioval2 == ''
//                         ? Fluttertoast.showToast(
//                         msg:
//                         'Please Choose Gender',
//                         backgroundColor:
//                         Colors.red,
//                         toastLength: Toast
//                             .LENGTH_LONG,
//                         gravity: ToastGravity
//                             .CENTER)
//                         : Fluttertoast.showToast(
//                         msg:
//                         'Please Upload Image',
//                         backgroundColor:
//                         Colors.red,
//                         toastLength: Toast.LENGTH_LONG,
//                         gravity: ToastGravity.CENTER);
//                   }
//                 },
//               ),
//               Container(
//                 height: w * .03,
//               ),
//             ],
//           ),
//         ),
//       ),
//     );;
//   }
// }
