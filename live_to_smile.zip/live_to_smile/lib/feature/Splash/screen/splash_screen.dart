import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:live_to_smile/core/routing/routing.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../authentication/screen/login_screen.dart';
import '../../onBoarding/onboarding.dart';

class Splash extends ConsumerStatefulWidget {
  const Splash({super.key});

  @override
  ConsumerState createState() => _SplashState();
}

class _SplashState extends ConsumerState<Splash> {
  UsersModel? usersModel;
  late SharedPreferences localStorage;

  Future getValidationData() async {
    localStorage = await SharedPreferences.getInstance();
    var us = localStorage.getString('email').toString();
    var id = localStorage.getString('id').toString();
    if (id != "null") {
      usersModel =
      await ref.read(authControllerProvider.notifier).getUserData(id).first;
    }
    ref.read(userProvider.notifier).update((state) => usersModel);
    currentUserId = id;
    print(currentUserId.toString() + '  kkkkk');
    setState(() {});
  }

  final Future<SharedPreferences> local = SharedPreferences.getInstance();
  bool firstTime = true;

  @override
  void initState() {
    local.then((value) async {
      if (value.getBool("firstTime") ?? true) {
        value.setBool("firstTime", false);
      } else {
        firstTime = false;
        setState(() {});
      }
    });
    getValidationData().whenComplete(() async {
      Timer(Duration(seconds: 3), () {
        if (mounted) {
          if (firstTime == true) {
            print('1:1');

            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => OnBoarding(),
                ),
                    (route) => false);
          } else if (currentUserId == null || currentUserId == "null") {
            print('1:2');
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => LoginPage(),
                ),
                    (route) => false);
          } else {
            print('1.3');
            Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => BottomBar(),
                ),
                    (route) => false);
          }
        }
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        height: h,
        width: w,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/icons/splash_back.png'),
                fit: BoxFit.fill)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Center(
            child: Container(
              height: h * .35,
              width: w * .35, //1382
              child: SvgPicture.asset('assets/icons/logo.svg'),
            ),
          ),
        ),
      ),
    );
  }
}
