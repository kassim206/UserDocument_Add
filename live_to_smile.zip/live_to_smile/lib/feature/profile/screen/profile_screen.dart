// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bounce/flutter_bounce.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:live_to_smile/Models/candidates_model.dart';
// import 'package:live_to_smile/Models/user_model.dart';
// import 'package:live_to_smile/bottom_bar/bottomBar.dart';
// import 'package:live_to_smile/profile/developer_contact.dart';
// import 'package:rounded_loading_button/rounded_loading_button.dart';
// import '../../../core/routing/routing.dart';
// import '../../../payments/payments.dart';
// import '../../../profile/edit_profile.dart';
// import '../../authentication/controller/auth_controller.dart';
// import '../../authentication/screen/login_screen.dart';
// import '../../edit_profile/screen/edit_profilescreen.dart';
// import '../../homepage/screen/home_page.dart';
// import '../../studentData/screen/studentData_screen.dart';
//
// class Profiles extends ConsumerStatefulWidget {
//   const Profiles({Key? key}) : super(key: key);
//
//   @override
//   ConsumerState<Profiles> createState() => _ProfileState();
// }
//
// class _ProfileState extends ConsumerState<Profiles> {
//   UsersModel? user;
//   final RoundedLoadingButtonController _btnController1 =
//       RoundedLoadingButtonController();
//
//   signOut() {
//     ref.read(authControllerProvider.notifier).signOut();
//   }
//
//   Future<bool> goBack(context) async {
//     bool ret = await showDialog(
//       context: context,
//       builder: (context) => Padding(
//         padding: EdgeInsets.fromLTRB(
//             20,
//             MediaQuery.of(context).size.height * 0.4,
//             20,
//             MediaQuery.of(context).size.height * 0.4),
//         child: Container(
//           width: MediaQuery.of(context).size.width,
//           decoration: BoxDecoration(
//               color: Colors.white, borderRadius: BorderRadius.circular(10)),
//           child: Padding(
//             padding: const EdgeInsets.only(left: 20),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Text(
//                   'Do you want to exit from\nLive to Smile?',
//                   style: GoogleFonts.lexend(
//                       fontSize: w * 0.04,
//                       fontWeight: FontWeight.w600,
//                       color: Colors.black,
//                       decoration: TextDecoration.none),
//                 ),
//                 SizedBox(
//                   height: 25,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.end,
//                   children: [
//                     GestureDetector(
//                       onTap: () {
//                         Navigator.of(context).pop(false);
//                       },
//                       child: Text(
//                         'NO',
//                         style: GoogleFonts.lexend(
//                             fontSize: 14,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.green,
//                             decoration: TextDecoration.none),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 30,
//                     ),
//                     GestureDetector(
//                       onTap: () {
//                         Navigator.of(context).pop(true);
//                       },
//                       child: Text(
//                         'EXIT',
//                         style: GoogleFonts.lexend(
//                             fontSize: 14,
//                             fontWeight: FontWeight.w700,
//                             color: Colors.red,
//                             decoration: TextDecoration.none),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 50,
//                     ),
//                   ],
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//     return ret;
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     user = ref.read(userProvider);
//     _btnController1.stateStream.listen((value) {
//       print(value);
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // final currentUserImage= ref.read(currentUserImageProvider);
//     // final currentUserName= ref.read(currentUserNameProvider);
//     // final student =ref.read(studentIdProvider);
//     // final currentUserPhone = ref.read(currentUserPhoneProvider);
//
//     return WillPopScope(
//       onWillPop: () {
//         Future<bool> ret = goBack(context);
//         return ret;
//       },
//       child: Scaffold(
//         backgroundColor: back,
//         appBar: AppBar(
//           backgroundColor: back,
//           foregroundColor: Colors.black,
//           automaticallyImplyLeading: false,
//           elevation: 0,
//           title: Text(
//             "Profile",
//             style: GoogleFonts.lexend(
//                 fontWeight: FontWeight.w500,
//                 fontSize: w * 0.045,
//                 color: Colors.black),
//           ),
//         ),
//         body: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             Center(
//               child: Container(
//                 height: w * 0.3,
//                 width: w * 0.3,
//                 child: Stack(
//                   children: [
//                     Bounce(
//                       onPressed: () {
//                         if (user!.uid != '') {
//                           Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                   builder: (context) => StudentData()));
//                         }
//                       },
//                       duration: Duration(milliseconds: 100),
//                       child: Container(
//                         height: w * 0.3,
//                         width: w * 0.3,
//                         child: Container(
//                           decoration: BoxDecoration(
//                               color: primary,
//                               image: DecorationImage(
//                                   image: user!.photo_url == ""
//                                       ? AssetImage(
//                                               'assets/icons/graduation.png')
//                                           as ImageProvider
//                                       : CachedNetworkImageProvider(
//                                           user!.photo_url),
//                                   fit: BoxFit.cover),
//                               shape: BoxShape.circle),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//             SizedBox(
//               height: w * 0.05,
//             ),
//             Center(
//               child: Text(
//                 user!.display_name,
//                 style: GoogleFonts.lexend(
//                     fontSize: w * 0.045, fontWeight: FontWeight.w500),
//               ),
//             ),
//             SizedBox(
//               height: w * 0.01,
//             ),
//             Center(
//               child: Text(
//                 user!.uid == '' ? '' : '@${user!.uid}',
//                 style: GoogleFonts.lexend(
//                     fontSize: w * 0.035, fontWeight: FontWeight.w400),
//               ),
//             ),
//             SizedBox(
//               height: w * 0.01,
//             ),
//             Center(
//               child: Text(
//                 candidatesModel!.verified == 0 && user!.uid == ''
//                     ? 'you haven\'t purchased any course'
//                     : candidatesModel!.verified == 0 && user!.uid != ''
//                         ? 'Document verification is under process'
//                         : candidatesModel!.verified == 1
//                             ? 'Document Verification Completed'
//                             : 'Uploaded Documents Rejected',
//                 style: GoogleFonts.lexend(
//                     fontSize: w * 0.03,
//                     fontWeight: FontWeight.w400,
//                     color: candidatesModel!.verified == 1 ? Colors.green : Colors.red),
//               ),
//             ),
//             SizedBox(
//               height: w * 0.1,
//             ),
//             Padding(
//               padding: EdgeInsets.only(
//                 top: w * 0.1,
//                 left: w * 0.15,
//                 right: w * 0.15,
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   (user!.uid != '')
//                       ? Row(
//                           children: [
//                             Center(
//                                 child: SvgPicture.asset(
//                                     'assets/icons/certificate.svg')),
//                             SizedBox(
//                               width: w * 0.05,
//                             ),
//                             Expanded(
//                                 child: Text(
//                               user!.phoneNo ?? '',
//                               style: GoogleFonts.lexend(
//                                   fontWeight: FontWeight.w400,
//                                   fontSize: w * 0.04),
//                             )),
//                             Icon(
//                               Icons.arrow_forward_ios_outlined,
//                               color: Color(0xffCFCFCF),
//                               size: w * 0.04,
//                             )
//                           ],
//                         )
//                       : Container(),
//                   (user!.uid != '')
//                       ? Padding(
//                           padding: EdgeInsets.only(
//                             top: w * 0.02,
//                             bottom: w * 0.02,
//                           ),
//                           child: Divider(
//                             color: Color(0xffCFCFCF),
//                             thickness: 1,
//                           ),
//                         )
//                       : Container(),
//                   InkWell(
//                     onTap: () {
//                       if (user!.uid != '') {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => StudentData()));
//                       }
//                     },
//                     child: Row(
//                       children: [
//                         SvgPicture.asset('assets/icons/downloads.svg'),
//                         SizedBox(
//                           width: w * 0.05,
//                         ),
//                         Expanded(
//                             child: Text(
//                           'My Details',
//                           style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w400, fontSize: w * 0.04),
//                         )),
//                         Icon(
//                           Icons.arrow_forward_ios_outlined,
//                           color: Color(0xffCFCFCF),
//                           size: w * 0.04,
//                         )
//                       ],
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                       top: w * 0.02,
//                       bottom: w * 0.02,
//                     ),
//                     child: Divider(
//                       color: Color(0xffCFCFCF),
//                       thickness: 1,
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () {
//                       Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                               builder: (context) => SupportContact()));
//                     },
//                     child: Row(
//                       children: [
//                         SvgPicture.asset('assets/icons/help.svg'),
//                         SizedBox(
//                           width: w * 0.05,
//                         ),
//                         Expanded(
//                             child: Text(
//                           'Help Center',
//                           style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w400, fontSize: w * 0.04),
//                         )),
//                         Icon(
//                           Icons.arrow_forward_ios_outlined,
//                           color: Color(0xffCFCFCF),
//                           size: w * 0.04,
//                         )
//                       ],
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                       top: w * 0.02,
//                       bottom: w * 0.02,
//                     ),
//                     child: Divider(
//                       color: Color(0xffCFCFCF),
//                       thickness: 1,
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () {
//                       if (user!.uid != null && user!.uid != '') {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => Payments()));
//                       }
//                     },
//                     child: Row(
//                       children: [
//                         SvgPicture.asset('assets/icons/payments.svg'),
//                         SizedBox(
//                           width: w * 0.05,
//                         ),
//                         Expanded(
//                             child: Text(
//                           'Payments',
//                           style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w400, fontSize: w * 0.04),
//                         )),
//                         Icon(
//                           Icons.arrow_forward_ios_outlined,
//                           color: Color(0xffCFCFCF),
//                           size: w * 0.04,
//                         )
//                       ],
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                       top: w * 0.02,
//                       bottom: w * 0.02,
//                     ),
//                     child: Divider(
//                       color: Color(0xffCFCFCF),
//                       thickness: 1,
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () {
//                       if (user!.uid != '') {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => EditProfile()));
//                       }
//                     },
//                     child: Row(
//                       children: [
//                         SvgPicture.asset('assets/icons/settings-sliders 1.svg'),
//                         SizedBox(
//                           width: w * 0.05,
//                         ),
//                         Expanded(
//                             child: Text(
//                           'Edit profile',
//                           style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w400, fontSize: w * 0.04),
//                         )),
//                         Icon(
//                           Icons.arrow_forward_ios_outlined,
//                           color: Color(0xffCFCFCF),
//                           size: w * 0.04,
//                         )
//                       ],
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                       top: w * 0.02,
//                       bottom: w * 0.02,
//                     ),
//                     child: Divider(
//                       color: Color(0xffCFCFCF),
//                       thickness: 1,
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () async {
//                       showDialog(
//                           context: context,
//                           builder: (context) => Padding(
//                                 padding: EdgeInsets.fromLTRB(
//                                     20,
//                                     MediaQuery.of(context).size.height * 0.4,
//                                     20,
//                                     MediaQuery.of(context).size.height * 0.4),
//                                 child: Container(
//                                   width: MediaQuery.of(context).size.width,
//                                   decoration: BoxDecoration(
//                                       color: Colors.white,
//                                       borderRadius: BorderRadius.circular(10)),
//                                   child: Padding(
//                                     padding: const EdgeInsets.only(left: 20),
//                                     child: Column(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.stretch,
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.center,
//                                       children: [
//                                         Text(
//                                           'Are you sure you want to logout?',
//                                           style: GoogleFonts.lexend(
//                                               fontSize: w * 0.04,
//                                               fontWeight: FontWeight.w600,
//                                               color: Colors.black,
//                                               decoration: TextDecoration.none),
//                                         ),
//                                         SizedBox(
//                                           height: 25,
//                                         ),
//                                         Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.end,
//                                           children: [
//                                             GestureDetector(
//                                               onTap: () {
//                                                 Navigator.pop(context);
//                                               },
//                                               child: Container(
//                                                 width: w * 0.25,
//                                                 height: w * 0.1,
//                                                 decoration: BoxDecoration(
//                                                     color: Colors.grey.shade200,
//                                                     borderRadius:
//                                                         BorderRadius.circular(
//                                                             10)),
//                                                 child: Center(
//                                                   child: Text(
//                                                     'Cancel',
//                                                     style: GoogleFonts.lexend(
//                                                         fontSize: 14,
//                                                         fontWeight:
//                                                             FontWeight.w700,
//                                                         decoration:
//                                                             TextDecoration
//                                                                 .none),
//                                                   ),
//                                                 ),
//                                               ),
//                                             ),
//                                             SizedBox(
//                                               width: 30,
//                                             ),
//                                             Container(
//                                               width: w * 0.25,
//                                               height: w * 0.1,
//                                               child: RoundedLoadingButton(
//                                                 successIcon: Icons.check,
//                                                 failedIcon: Icons.close,
//                                                 elevation: 0,
//                                                 borderRadius: 10,
//                                                 color: primary,
//                                                 child: Text('Confirm',
//                                                     style: GoogleFonts.lexend(
//                                                         fontSize: 14,
//                                                         fontWeight:
//                                                             FontWeight.w700,
//                                                         decoration:
//                                                             TextDecoration
//                                                                 .none)),
//                                                 controller: _btnController1,
//                                                 onPressed: () async {
//                                                   await signOut();
//                                                   ref
//                                                       .read(
//                                                           userProvider.notifier)
//                                                       .update((state) =>
//                                                           null); // ref.read(currentUserNameProvider.notifier).state = '';
//                                                   // ref.read(currentUserImageProvider.notifier).state = '';
//                                                   user!.email = '';
//                                                   candidatesModel!.classId = '';
//                                                   candidatesModel!.course = '';
//                                                   currentUserId = '';
//                                                   notifications = [];
//                                                   upComing = [];
//                                                   completedClass = [];
//                                                   nextClass = {};
//                                                   // ref.read(studentIdProvider.notifier).state = '';
//                                                   await Navigator
//                                                       .pushAndRemoveUntil(
//                                                           context,
//                                                           MaterialPageRoute(
//                                                               builder: (context) =>
//                                                                   LoginPage()),
//                                                           (route) => false);
//                                                 },
//                                               ),
//                                             ),
//                                             SizedBox(
//                                               width: 50,
//                                             ),
//                                           ],
//                                         )
//                                       ],
//                                     ),
//                                   ),
//                                 ),
//                               ));
//                     },
//                     child: Row(
//                       children: [
//                         SvgPicture.asset('assets/icons/logout.svg'),
//                         SizedBox(
//                           width: w * 0.05,
//                         ),
//                         Expanded(
//                             child: Text(
//                           'Logout',
//                           style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w400, fontSize: w * 0.04),
//                         )),
//                         Icon(
//                           Icons.arrow_forward_ios_outlined,
//                           color: Color(0xffCFCFCF),
//                           size: w * 0.04,
//                         )
//                       ],
//                     ),
//                   ),
//                   Padding(
//                     padding: EdgeInsets.only(
//                       top: w * 0.02,
//                       bottom: w * 0.02,
//                     ),
//                     child: Divider(
//                       color: Color(0xffCFCFCF),
//                       thickness: 1,
//                     ),
//                   ),
//                 ],
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
