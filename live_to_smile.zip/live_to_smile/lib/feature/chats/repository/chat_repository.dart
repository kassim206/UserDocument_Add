import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/chat_model.dart';
import 'package:live_to_smile/core/constants/firebaseconstants/firebase_constants.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';
import '../../../core/routing/routing.dart';

final chatRepositoryProvider = StateProvider(
    (ref) => chatRepository(firestore: ref.watch(firestoreProvider)));

class chatRepository {
  final FirebaseFirestore _firestore;
  chatRepository({required FirebaseFirestore firestore
  }) : _firestore = firestore;
  CollectionReference get _chat =>
      _firestore.collection(FirebaseConstants.chatCollection);

  // getChat() async {
  //   _firestore
  //       .collection('class')
  //       .doc(CurrentUserClassId)
  //       .collection('chat')
  //       .orderBy('time', descending: false)
  //       .snapshots()
  //       .listen((event) async {
  //     chat = await event.docs;
  //
  //     // if (mounted) {
  //     //   setState(() {});
  //     // }
  //   });
  // }
  Stream<List<chatModel>> getChat() {
    List<chatModel> chat = [];
    return _firestore
        .collection('class')
        .doc(candidatesModel!.classId)
        .collection('chat')
        .orderBy('time', descending: false)
        .snapshots()
        .map((event) {
      chat = [];
      for (var i in event.docs) {
        chat.add(chatModel.fromMap(i.data()));
      }
      return chat;
    });
  }

  getChatBounce({
    required String name,
      required String Image,
      required String msg,
      required String studentId}) {
    _firestore
        .collection('class')
        .doc(candidatesModel!.classId)
        .collection('chat')
        .add({
      'type': 0,
      'name': name,
      'photo': Image,
      'msg': msg,
      'time': FieldValue.serverTimestamp(),
      'id': studentId,
    });
  }

  Stream<CandidatesModel> getCandidate(String student) {
    return _firestore.collection('candidates').doc(student).snapshots().map(
        (event) =>
            CandidatesModel.fromMap(event.data() as Map<String, dynamic>));
  }
}
