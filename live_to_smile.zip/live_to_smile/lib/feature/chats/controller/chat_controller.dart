import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/chat_model.dart';
import 'package:live_to_smile/feature/chats/repository/chat_repository.dart';
import '../../../Models/candidates_model.dart';

final getChatControllerProvider = StateProvider(
    (ref) => chatController(repository: ref.read(chatRepositoryProvider)));
final getchatCandidateProvider = StreamProvider.family((ref, String student) =>
    ref.read(getChatControllerProvider).getCandidate(student));
final getChatStreamProvider =
    StreamProvider((ref) => ref.read(getChatControllerProvider).getChat());

class chatController {
  final chatRepository _repository;
  chatController({required chatRepository repository})
      : _repository = repository;
  Stream<List<chatModel>> getChat() {
    return _repository.getChat();
  }

  getChatBounce(
      {required String name,
      required String Image,
      required String msg,
      required String studentId}) {
    _repository.getChatBounce(
        name: name, Image: Image, msg: msg, studentId: studentId);
  }

  Stream<CandidatesModel> getCandidate(String student) {
    return _repository.getCandidate(student);
  }
}
