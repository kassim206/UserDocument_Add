// import 'package:flutter/material.dart';
// import 'package:flutter_bounce/flutter_bounce.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:live_to_smile/Models/candidates_model.dart';
// import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
// import 'package:intl/intl.dart';
// import 'package:live_to_smile/notification/view_msg.dart';
// import '../../../bottom_bar/bottomBar.dart';
// import '../../../chat/chat.dart';
// import '../../../core/routing/routing.dart';
// import '../../homepage/screen/home_page.dart';
// import '../../view_msge/screen/viewmsge_screen.dart';
//
//
// class Notifications extends ConsumerStatefulWidget {
//   const Notifications({Key? key}) : super(key: key);
//
//   @override
//   ConsumerState<Notifications> createState() => _NotificationsState();
// }
//
// class _NotificationsState extends ConsumerState<Notifications> {
//
//
//   @override
//   Widget build(BuildContext context) {
//     final student =ref.read(userProvider);
//
//
//     return WillPopScope(
//       onWillPop: () {
//         Navigator.pushAndRemoveUntil(
//           context,
//           MaterialPageRoute(
//               builder: (context) => BottomBar(bIndex: 0,)),
//               (b) => false,
//         );
//         return Future.value(true);
//       },
//       child:((student!.uid=='')||candidatesModel!.verified==2)?
//       WillPopScope(onWillPop: () {
//         Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => BottomBar(bIndex: 0,)),
//               (b) => false,
//         );
//         return Future.value(true);
//       },
//
//           child: Scaffold(
//             backgroundColor: primary,
//             body: Container(
//               decoration: BoxDecoration(
//                   image: DecorationImage(
//                       image: AssetImage('assets/icons/splash_back.png'),
//                       fit: BoxFit.fill
//                   )
//               ),
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.stretch,
//                   children: [
//                     Padding(
//                       padding:  EdgeInsets.only(
//                         left: w*0.25,
//                         right: w*0.25,
//                       ),
//                       child: Image.asset('assets/icons/logo.png',width: w*0.5,),
//                     ),
//                     SizedBox(height: w*0.05,),
//                     Text(student.uid==''
//                         ? 'Your haven\'t purchased any course.\nPlease enroll for a course first.'
//                         :candidatesModel!.verified==2?'Uploaded Documents Rejected. \nPlease Resubmit your Documents'
//                         :'',
//                       style: GoogleFonts.lexend(
//                           fontSize: 18),
//                       textAlign: TextAlign.center,),
//                   ],
//                 ),
//               ),
//             ),
//           )
//       )
//           :notifications.length==0?WillPopScope(
//           onWillPop: (){
//             Navigator.pushAndRemoveUntil(
//               context,
//               MaterialPageRoute(
//                   builder: (context) => BottomBar(bIndex: 0,)),
//                   (b) => false,
//             );
//             return Future.value(true);
//           },
//
//           child: Scaffold(
//             backgroundColor: primary,
//             body: Container(
//               decoration: BoxDecoration(
//                   image: DecorationImage(
//                       image: AssetImage('assets/icons/splash_back.png'),
//                       fit: BoxFit.fill
//                   )
//               ),
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.stretch,
//                   children: [
//                     Padding(
//                       padding:  EdgeInsets.only(
//                         left: w*0.25,
//                         right: w*0.25,
//                       ),
//                       child: Image.asset('assets/icons/logo.png',width: w*0.5,),
//                     ),
//                     SizedBox(height: w*0.05,),
//                     Text('Your haven\'t any messages.',style: GoogleFonts.lexend(
//                         fontSize: 18
//                     ),textAlign: TextAlign.center,),
//                   ],
//                 ),
//               ),
//             ),
//           )
//       )
//           :Scaffold(
//         backgroundColor: back,
//         appBar: AppBar(
//           backgroundColor: back,
//           foregroundColor: Colors.black,
//           automaticallyImplyLeading: false,
//           elevation: 0,
//           title: Text("Announcement",style: GoogleFonts.lexend(
//               fontWeight: FontWeight.w500,
//               fontSize: w*0.045,color: Colors.black
//           ),),
//
//         ),
//         body: SingleChildScrollView(
//           physics: BouncingScrollPhysics(),
//           child: Column(
//             children: [
//               ListView.builder(
//                 itemCount: notifications.length,
//                 shrinkWrap: true,
//                 physics: NeverScrollableScrollPhysics(),
//                 padding: EdgeInsets.only(
//                   left:w*0.05,
//                   right:w*0.05,
//                   top:w*0.05,
//                 ),
//                 itemBuilder: (context,index){
//                   List view=notifications[index]['view'];
//                   DateTime notDate=notifications[index]['date'].toDate();
//                   String notTime=formattedTime(notDate).toString();
//                   return Bounce(
//                     onPressed: () async {
//                       await Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewMsgs(data: notifications[index],notDate: notDate,notTime: notTime,)));
//                       setState(() {
//
//                       });
//                     },
//                     duration: Duration(milliseconds: 100),
//                     child: Container(
//                       height:w*0.4,
//                       child: Stack(
//                         children: [
//                           Center(
//                             child: Container(
//                               height:w*0.35,
//                               decoration: BoxDecoration(
//                                 color: Colors.white,
//                                 borderRadius: BorderRadius.circular(w*0.05),
//                                 boxShadow: [
//                                   BoxShadow(
//                                     color:Colors.grey.shade300,
//                                     offset: const Offset(
//                                       5.0,
//                                       2.0,
//                                     ),
//                                     blurRadius: 15.0,
//                                     spreadRadius: -10.0,
//                                   ), //BoxShadow
//                                   //BoxShadow
//                                 ],
//                               ),
//                               child: Padding(
//                                 padding:  EdgeInsets.all(w*0.03),
//                                 child: Column(
//                                   children: [
//                                     Align(
//                                         alignment: Alignment.topLeft,
//                                         child: Row(
//                                           children: [
//                                             CircleAvatar(
//                                               backgroundColor:view.contains(student.uid)?Colors.green: Colors.red,
//                                               radius:w*0.02 ,
//                                             ),
//                                             SizedBox(width: w*0.02,),
//                                             Text(((notDate.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
//                                             'Today':(notDate.toString().substring(0,10)==DateTime.now().add(Duration(days: -1)).toString().substring(0,10))?
//                                             'Yesterday':DateFormat("MMM dd yyyy").format(notDate))+'  '+notTime,style: GoogleFonts.lexend(
//                                                 fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                                             )),
//                                           ],
//                                         )
//                                     ),
//                                     Expanded(
//                                       child: Column(
//                                         crossAxisAlignment: CrossAxisAlignment.start,
//                                         mainAxisAlignment: MainAxisAlignment.spaceAround,
//                                         children: [
//
//                                           Row(
//                                             children: [
//                                               Expanded(
//                                                 flex: 3,
//                                                 child: Text(notifications[index]['title'],style: GoogleFonts.lexend(
//                                                     fontWeight: FontWeight.w500,fontSize: w*0.03
//                                                 ),),
//                                               ),
//                                               Expanded(
//                                                 flex: 2,
//                                                 child: SizedBox(),
//                                               ),
//                                             ],
//                                           ),
//                                           Padding(
//                                             padding:  EdgeInsets.only(
//                                                 left: w*0.003
//                                             ),
//                                             child: Text(notifications[index]['message'],style: GoogleFonts.lexend(
//                                                 fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                                             ),maxLines: 3,),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ),
//                           Align(
//                             alignment: Alignment.topRight,
//                             child: Padding(
//                               padding:  EdgeInsets.only(right: w*0.03),
//                               child: Image.asset('assets/icons/mike.png',width: w*0.2,),
//                             ),
//                           ),
//
//                         ],
//                       ),
//                     ),
//                   );
//                 },
//               ),
//               SizedBox(height:w*0.25)
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
//
//
