import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import '../repository/class_repository.dart';
final candidatesRep1StreamProvider =StreamProvider.family((ref,String encode) =>
    ref.watch(classControllerProvider).candidatesRep1(encode:encode ));
final candidatesRepStreamProvider =StreamProvider.family((ref,String encode1) =>
    ref.watch(classControllerProvider).candidatesRep(encode: encode1));

final getClassRoomStreamProvider = StreamProvider((ref) => ref.read(classControllerProvider).getClassRoom());
final getMeetingsStreamProvider = StreamProvider((ref) => ref.read(classControllerProvider).getMeetings());
final getTokenStreamProvider = StreamProvider((ref) => ref.read(classControllerProvider).getToken());

final classControllerProvider = Provider(
        (ref) => classController(repository: ref.read(classRepositoryProvider)));

class classController {
  final classRepository _repository;
  classController({required classRepository repository})
      : _repository = repository;
  getMeetingVideo2(String id, String classId, String token) {
    _repository.getMeetingVideo2(id, classId, token);
  }

  getMeetingVideo(
      String id, String classId, String token, BuildContext context) async {
    _repository.getMeetingVideo(id, classId, token);
  }
 Stream <List> getMeetings() {
   return _repository.getMeetings();
  }
  Stream<List>getClassRoom() {
    print(candidatesModel!.classId);
    print("&&&&&&&&&&&&&&&&&&&&&&&&");
    return  _repository.getClassRoom();
  }
  Stream<String>getToken(){
   return _repository.getToken();
  }
  // getToken(){
  //   _repository.getToken();
  // }
  //candidatesRep candidates
  getClassZoom(int index,List classMates){_repository.getClassZoom(index,classMates);}
  Stream<CandidatesModel>candidatesRep({required String encode}){
    Map<String,dynamic> map= jsonDecode(encode);

    return _repository.candidates(map['index'],map['list']);
  }
  getClassZoom1(int index,List classMates){_repository.getClassZoom1(index,classMates);}

  Stream<CandidatesModel>candidatesRep1({required String encode}){
    Map<String,dynamic> map= jsonDecode(encode);

    return _repository.candidates1(map['index'],map['list']);
  }
  getZoomBounce(){_repository.getZoomBounce();}
}