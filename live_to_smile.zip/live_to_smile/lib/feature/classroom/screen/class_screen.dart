import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/core/common/error.dart';
import 'package:live_to_smile/core/common/loader.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../bottom_bar/bottomBar.dart';
import '../../../chat/chat.dart';
import '../../homepage/screen/home_page.dart';
import '../../session/screen/session_screen.dart';
import '../controller/class_controller.dart';

List classMates = [];
class classScreen extends ConsumerStatefulWidget {
  const classScreen({super.key});

  @override
  ConsumerState createState() => _classScreenState();
}

class _classScreenState extends ConsumerState<classScreen>
    with SingleTickerProviderStateMixin {
  UsersModel? user;

  int selectedIndex = 0;
  String selectedSubject = 'All';
  //FlickManager flickManager;
  TextEditingController meetingIdController =
      TextEditingController(text: '8402973253');
  TextEditingController meetingPasswordController =
      TextEditingController(text: 'smile@1123');
  Timer? timer;
  List onGoing = [];
  getMeetingVideo2(BuildContext context) {
    ref
        .read(classControllerProvider)
        .getMeetingVideo2('studentId', nextClass, accessToken);
  }

  getMeetingVideo() {
    ref
        .read(classControllerProvider)
        .getMeetingVideo('studentId', nextClass, accessToken, context);
  }

  getClassZoom(int index,List classMates) {
    ref.read(classControllerProvider).getClassZoom(index, classMates);
  }

  getClassZoom1(int index,List classMates) {
    ref.read(classControllerProvider).getClassZoom1(index, classMates);
  }

  getZoomBounce() {
    ref.read(classControllerProvider).getZoomBounce();
  }

  getBounceTap() {
    if (nextClass['start'] == true && nextClass['status'] == 0) {
      launchURL(nextClass['join_url']);
    } else {
      getMeetingVideo2(context);
    }
  }

  int status = 0;
  Duration? TotalMinuts;
  DateTime? inTime;
  int count = 1;
  Future launchURL(String url) async {
    var uri = Uri.parse(url).toString();
    try {
      await launch(uri);
    } catch (e) {
      throw 'Could not launch $uri: $e';
    }
  }

  _launchZoomUrl(Uri fileUrl) async {
    if (await canLaunchUrl(fileUrl)) {
      await launchUrl(
        fileUrl,
        mode: LaunchMode.externalApplication,
      );
    } else {
      throw 'Could not launch $fileUrl';
    }
  }

  counter(DateTime time) async {
    for (int i = count; i > 0; i--) {
      await Future.delayed(const Duration(seconds: 1));
      TotalMinuts = time.difference(DateTime.now());
    }

    if (mounted) {
      setState(() {});
    }
    counter(time);
  }

  getTabs() {}
  List subjects = ['All'];

  void initState() {
    // TODO: implement initState
    // getToken();
    if (ClassIdToName[candidatesModel == null?"":candidatesModel!.classId] != null) {
      _tabController = TabController(length: 3, vsync: this);
      subjects.addAll(classMap[candidatesModel!.classId]['subject']);
    }
    // paginationFunction();
    super.initState();
  }


  TabController? _tabController;
  TabController? _tabController2;
  @override
  Widget build(BuildContext context) {
    var h = MediaQuery.of(context).size.height;
    var W = MediaQuery.of(context).size.width;
    DateTime? date;
    String? time;
    if (nextClass.toString() != '{}') {
      date = nextClass['scheduled'].toDate();
      time = formattedTime(date!).toString();
      counter(date);
    }
    //ToDO studentid
    return ref.watch(getTokenStreamProvider).when(data:(zoom) {
      return  (candidatesModel == null || candidatesModel!.studentId == ''|| candidatesModel!.verified == 2)
          ? WillPopScope(
          onWillPop: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                  builder: (context) => BottomBar(
                    bIndex: 0,
                  )),
                  (b) => false,
            );
            return Future.value(true);
          },
          child: Scaffold(
            backgroundColor: primary,
            body: Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/icons/splash_back.png'),
                      fit: BoxFit.fill)),
              child: Padding(
                padding: EdgeInsets.all(w * 0.05),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        left: w * 0.25,
                        right: w * 0.25,
                      ),
                      child: Image.asset(
                        'assets/icons/logo.png',
                        width: w * 0.5,
                      ),
                    ),
                    SizedBox(
                      height: w * 0.05,
                    ),
                    //TODO studentid
                    Text(
                      candidatesModel == null   || candidatesModel!.studentId == ""
                          ? 'Your haven\'t purchased any course.\nPlease enroll for a course first.'
                          : candidatesModel!.verified == 2
                          ? 'Uploaded Documents Rejected. \nPlease Resubmit your Documents'
                          : '',
                      style: GoogleFonts.lexend(fontSize: 18),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ))
          : nextClass.toString() == '{}'
          ? WillPopScope(
          onWillPop: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                  builder: (context) => BottomBar(
                    bIndex: 0,
                  )),
                  (b) => false,
            );
            return Future.value(true);
          },
          child: Scaffold(
            backgroundColor: primary,
            body: Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/icons/splash_back.png'),
                      fit: BoxFit.fill)),
              child: Padding(
                padding: EdgeInsets.all(w * 0.05),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        left: w * 0.25,
                        right: w * 0.25,
                      ),
                      child: Image.asset(
                        'assets/icons/logo.png',
                        width: w * 0.5,
                      ),
                    ),
                    SizedBox(
                      height: w * 0.05,
                    ),
                    Text(
                      'Completed classes is empty now',
                      style: GoogleFonts.lexend(fontSize: 18),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ))
          :  ref.watch(getClassRoomStreamProvider).when(data: (classMates) {
        return ref.watch(getMeetingsStreamProvider).when(data: (onGoing) {
          return WillPopScope(
              onWillPop: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                      builder: (context) => BottomBar(
                        bIndex: 0,
                      )),
                      (b) => false,
                );
                return Future.value(true);
              },
              child: Scaffold(
                body: DefaultTabController(
                  length: subjects.length,
                  child: CustomScrollView(
                    slivers: [
                      SliverAppBar(
                        expandedHeight: kToolbarHeight,
                        pinned: true,
                        backgroundColor: Colors.white,
                        elevation: 0,
                        title: Text(
                          '${ClassIdToName[candidatesModel!.classId]}',
                          style: GoogleFonts.lexend(
                              fontWeight: FontWeight.w500,
                              fontSize: w * 0.04,
                              color: Colors.black),
                        ),
                        centerTitle: false,
                        actions: [
                          SizedBox(
                            width: w * 0.05,
                          ),
                          Center(
                            child: InkWell(
                              onTap: () {},
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xff343434),
                                  borderRadius: BorderRadius.circular(w * 0.02),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.shade300,
                                      offset: const Offset(
                                        5.0,
                                        2.0,
                                      ),
                                      blurRadius: 10.0,
                                      spreadRadius: -2.0,
                                    ), //BoxShadow
                                    //BoxShadow
                                  ],
                                ),
                                child: Padding(
                                  padding: EdgeInsets.fromLTRB(
                                    w * 0.03,
                                    w * 0.01,
                                    w * 0.03,
                                    w * 0.01,
                                  ),
                                  child: Text(
                                    '${completedClass.length} Classes',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w500,
                                        fontSize: w * 0.035,
                                        color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: w * 0.05,
                          )
                        ],
                      ),
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: EdgeInsets.all(w * 0.05),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Stack(
                                children: [
                                  Bounce(
                                    onPressed: () {
                                      getBounceTap();
                                      getZoomBounce();
                                    },
                                    duration: Duration(milliseconds: 100),
                                    child: Container(
                                      height: w * 0.53,
                                      width: w * 0.9,
                                      child: Stack(
                                        children: [
                                          Center(
                                              child: Padding(
                                                padding: const EdgeInsets.all(20),
                                                child: Image.asset(
                                                    'assets/icons/logo.png'),
                                              )),
                                          Container(
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                BorderRadius.circular(10),
                                                color: Colors.black
                                                    .withOpacity(0.8)),
                                            child: Center(
                                              child: CircleAvatar(
                                                backgroundColor:
                                                primary.withOpacity(0.5),
                                                radius: w * 0.08,
                                                child: Icon(
                                                  Icons.play_arrow,
                                                  color: Colors.white,
                                                  size: 30,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: w * 0.03,
                                        top: w * 0.03,
                                      ),
                                      child: nextClass['start'] == false
                                          ? Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: [
                                          (TotalMinuts == null ||
                                              TotalMinuts! <
                                                  Duration(
                                                      seconds: 1))
                                              ? Text(
                                            'Will start soon',
                                            style:
                                            GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight:
                                                FontWeight
                                                    .w500,
                                                color: Colors
                                                    .white),
                                            textAlign:
                                            TextAlign.left,
                                          )
                                              : Text(
                                            'Starts in:',
                                            style:
                                            GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight:
                                                FontWeight
                                                    .w500,
                                                color: Colors
                                                    .white),
                                            textAlign:
                                            TextAlign.left,
                                          ),
                                          (TotalMinuts == null ||
                                              TotalMinuts! <
                                                  Duration(
                                                      seconds: 1))
                                              ? Text(
                                            "".toString(),
                                            style:
                                            GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight:
                                                FontWeight
                                                    .bold,
                                                color: Colors
                                                    .redAccent),
                                            textAlign:
                                            TextAlign.left,
                                          )
                                              : Text(
                                            "${TotalMinuts!.inDays < 1 ? '' : TotalMinuts?.inDays}${TotalMinuts!.inDays < 1 ? '' : ':'}${TotalMinuts?.inHours.remainder(24)}:${TotalMinuts?.inMinutes.remainder(60)}"
                                                ":${TotalMinuts?.inSeconds.remainder(60)}"
                                                .toString(),
                                            style:
                                            GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight:
                                                FontWeight
                                                    .bold,
                                                color: Colors
                                                    .redAccent),
                                            textAlign:
                                            TextAlign.left,
                                          ),
                                        ],
                                      )
                                          : nextClass['start'] == true &&
                                          nextClass['status'] == 0
                                          ? Image.asset(
                                        'assets/icons/live.png',
                                        height: w * 0.05,
                                      )
                                          : Text(''),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: w * 0.03,
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: w * 0.02,
                                  right: w * 0.02,
                                ),
                                child: Row(
                                  children: [
                                    Row(
                                      children: [
                                        tutorMap[nextClass['tutor']]
                                        ['photo_url'] ==
                                            ''
                                            ? CircleAvatar(
                                          backgroundImage: AssetImage(
                                              ('assets/icons/appicon.jpg')),
                                        )
                                            : CircleAvatar(
                                          radius: w * 0.04,
                                          backgroundImage: NetworkImage(
                                              tutorMap[nextClass['tutor']]
                                              ['photo_url']),
                                          backgroundColor: Colors.white,
                                        ),
                                        SizedBox(
                                          width: w * 0.025,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'Session by',
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w * 0.03,
                                                  color: Colors.black),
                                            ),
                                            Text(
                                              tutorMap[nextClass['tutor']]
                                              ['display_name'],
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w * 0.028,
                                                  color: Color(0xffFA2B3A)),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      width: w * 0.01,
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: EdgeInsets.only(
                                          left: w * 0.003,
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '${nextClass['subject']}',
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: w * 0.035,
                                                  color: Colors.black),
                                            ),
                                            Text(
                                              '${(date.toString().substring(0, 10) == DateTime.now().toString().substring(0, 10)) ? 'Today' : (date.toString().substring(0, 10) == DateTime.now().add(Duration(days: 1)).toString().substring(0, 10)) ? 'Tomorrow' : DateFormat("MMM dd yyyy").format(date!)}  $time',
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: w * 0.025,
                                                  color: darkT),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: w * 0.05,
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: w * 0.025,
                                  right: w * 0.025,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      nextClass['name'],
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.w500,
                                          fontSize: w * 0.035,
                                          color: Colors.black),
                                    ),
                                    Text(
                                      'Created in ${DateFormat("MMM dd yyyy").format(nextClass['date'].toDate())}',
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.w400,
                                          fontSize: w * 0.025,
                                          color: darkT),
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: w * 0.05,
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: w * 0.025,
                                  right: w * 0.025,
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Your Classmates',
                                            style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w500,
                                                fontSize: w * 0.035,
                                                color: Colors.black),
                                          ),
                                          Text(
                                            '${classMates.length} Students here!',
                                            style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w400,
                                                fontSize: w * 0.025,
                                                color: darkT),
                                          )
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                        child: SizedBox(
                                          width: 100,
                                          child: Row(
                                            children: [
                                              classMates.length == 0
                                                  ? Container()
                                                  : Container(
                                                  height: w * 0.08,
                                                  child: Stack(
                                                    children: List.generate(
                                                        classMates.length > 4
                                                            ? 4
                                                            : classMates.length,
                                                            (index) => Padding(
                                                            padding:
                                                            EdgeInsets.only(
                                                                left: w *
                                                                    0.07 *
                                                                    index),
                                                            child: index == 3
                                                                ? CircleAvatar(
                                                              radius:
                                                              w * 0.04,
                                                              backgroundColor:
                                                              Color(
                                                                  0xffD9D9D9),
                                                              child: Text(
                                                                '+' +
                                                                    (classMates.length -
                                                                        3)
                                                                        .toString(),
                                                                style: GoogleFonts.lexend(
                                                                    fontSize: w *
                                                                        0.02,
                                                                    color: Colors
                                                                        .black),
                                                              ),
                                                            )
                                                                : Consumer(
                                                              builder: (BuildContext
                                                              context,
                                                                  WidgetRef
                                                                  ref,
                                                                  Widget?
                                                                  child) {
                                                                Map<String,
                                                                    dynamic>
                                                                map = {
                                                                  'index':
                                                                  index, // Add additional keys and values as needed
                                                                  'list':
                                                                  classMates,
                                                                };
                                                                return tutorMap[nextClass['tutor']]['photo_url'] ==
                                                                        ''
                                                                        ? CircleAvatar(
                                                                        radius: w * 0.04,
                                                                        backgroundColor: Color(0xffD9D9D9),
                                                                        backgroundImage: AssetImage('assets/icons/graduation.png'))
                                                                        : CircleAvatar(
                                                                      backgroundImage: CachedNetworkImageProvider(tutorMap[nextClass['tutor']]['photo_url']),
                                                                    );
                                                                    // Handle the data here
                                                                  },

                                                            )

                                                          // StreamBuilder<
                                                          //             DocumentSnapshot>(
                                                          //         stream:
                                                          //             getClassZoom(index),
                                                          //         builder:
                                                          //             (context,
                                                          //                 snapshot) {
                                                          //           if (!snapshot
                                                          //               .hasData) {
                                                          //             return CircleAvatar(
                                                          //               radius:
                                                          //                   w * 0.04,
                                                          //               backgroundColor:
                                                          //                   Color(0xffD9D9D9),
                                                          //             );
                                                          //           }
                                                          //           var data =
                                                          //               snapshot
                                                          //                   .data;
                                                          //           return tutorMap[nextClass['tutor']]['photo_url'] ==
                                                          //                   ''
                                                          //               ? CircleAvatar(
                                                          //                   radius: w * 0.04,
                                                          //                   backgroundColor: Color(0xffD9D9D9),
                                                          //                   backgroundImage: AssetImage('assets/icons/graduation.png'))
                                                          //               : CircleAvatar(
                                                          //                   backgroundImage: CachedNetworkImageProvider(data?['photo']),
                                                          //                 );
                                                          //         }),
                                                        )),
                                                  )),
                                              Expanded(child: SizedBox()),
                                              Bounce(
                                                onPressed: () {
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              ChatScreen()));
                                                },
                                                duration: Duration(milliseconds: 100),
                                                child: Container(
                                                  height: w * 0.08,
                                                  width: w * 0.1,
                                                  decoration: BoxDecoration(
                                                      color: Color(0xff343434),
                                                      borderRadius:
                                                      BorderRadius.circular(10)),
                                                  child: Padding(
                                                    padding: EdgeInsets.all(w * 0.01),
                                                    child: SvgPicture.asset(
                                                        'assets/icons/message.svg'),
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                        )),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: w * 0.05,
                              ),
                              Text(
                                "Description",
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * 0.04,
                                    color: Colors.black),
                              ),
                              SizedBox(
                                height: w * 0.03,
                              ),
                              Text(
                                nextClass['description'],
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w400,
                                    fontSize: w * 0.03,
                                    color: Colors.black.withOpacity(0.7)),
                              ),
                              SizedBox(
                                height: w * 0.02,
                              ),
                              Divider(
                                color: darkT,
                              ),
                              SizedBox(
                                height: w * 0.04,
                              ),
                              nextClass['notes'].length == 0
                                  ? Container()
                                  : Text(
                                "Notes",
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * 0.04,
                                    color: Colors.black),
                              ),
                              nextClass['notes'].length == 0
                                  ? Container()
                                  : SizedBox(
                                height: w * 0.03,
                              ),
                              nextClass['notes'].length == 0
                                  ? Container()
                                  : Padding(
                                padding: EdgeInsets.only(
                                  left: w * 0.02,
                                  right: w * 0.02,
                                ),
                                child: ListView.builder(
                                  itemCount: nextClass['notes'].length,
                                  shrinkWrap: true,
                                  padding: EdgeInsets.zero,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    return Padding(
                                      padding: EdgeInsets.only(
                                          bottom: w * 0.02),
                                      child: Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only(
                                                top: w * 0.01),
                                            child: Icon(
                                              Icons.circle,
                                              color: Colors.black
                                                  .withOpacity(0.7),
                                              size: w * 0.02,
                                            ),
                                          ),
                                          SizedBox(
                                            width: w * 0.03,
                                          ),
                                          Expanded(
                                            child: Text(
                                              nextClass['notes'][index],
                                              style: GoogleFonts.lexend(
                                                  fontWeight:
                                                  FontWeight.w400,
                                                  fontSize: w * 0.03,
                                                  color: Colors.black
                                                      .withOpacity(0.7)),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                              nextClass['notes'].length == 0
                                  ? Container()
                                  : Divider(
                                color: darkT,
                              ),
                              nextClass['documents'].length == 0
                                  ? Container()
                                  : Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Documents",
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w500,
                                        fontSize: w * 0.04,
                                        color: Colors.black),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      color: Color(0xff343434),
                                      borderRadius:
                                      BorderRadius.circular(w * 0.02),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.shade400,
                                          offset: const Offset(
                                            5.0,
                                            2.0,
                                          ),
                                          blurRadius: 10.0,
                                          spreadRadius: -2.0,
                                        ), //BoxShadow
                                        //BoxShadow
                                      ],
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                        w * 0.03,
                                        w * 0.01,
                                        w * 0.03,
                                        w * 0.01,
                                      ),
                                      child: Text(
                                        nextClass['documents']
                                            .length
                                            .toString(),
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w400,
                                            fontSize: w * 0.035,
                                            color: Colors.white),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              nextClass['documents'].length == 0
                                  ? Container()
                                  : SizedBox(
                                height: w * 0.03,
                              ),
                              nextClass['documents'].length == 0
                                  ? Container()
                                  : Container(
                                height: w * 0.3,
                                child: ListView.builder(
                                  padding: EdgeInsets.zero,
                                  itemCount:nextClass['documents'].length,
                                  scrollDirection: Axis.horizontal,reverse: true,
                                  itemBuilder: (context, index) {
                                    return Padding(
                                      padding: EdgeInsets.only(
                                        right: w * 0.03,
                                      ),
                                      child: Bounce(
                                        onPressed: () async {
                                          print(nextClass['documents']
                                          [index]['url']);
                                          print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                                          _launchZoomUrl(Uri.tryParse(
                                              nextClass['documents']
                                              [index]['url']
                                                  .toString())!);
                                        },
                                        duration:
                                        Duration(milliseconds: 100),
                                        child: Container(
                                          width: w * 0.26,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                              BorderRadius.circular(
                                                  10),
                                              border: Border.all(
                                                  color:
                                                  Color(0xffD8D8D8))),
                                          child: Column(
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: [
                                              SvgPicture.asset(
                                                'assets/icons/dcmnt.svg',
                                                color: Color(0xffD8D8D8),
                                              ),
                                              SizedBox(
                                                height: w * 0.02,
                                              ),
                                              Text(
                                                nextClass['documents']
                                                [index]['name'],
                                                style: GoogleFonts.lexend(
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    fontSize: w * 0.03,
                                                    color: Color(
                                                        0xffD8D8D8)),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SliverPersistentHeader(
                        delegate: MyDelegate(TabBar(
                          controller: _tabController,
                          tabs: [
                            Tab(
                              text: 'Last Sessions',
                            ),
                            Tab(
                              text: 'First Sessions',
                            ),
                            Tab(
                              text: 'Not played',
                            ),
                          ],
                          unselectedLabelStyle: GoogleFonts.lexend(
                            fontSize: w * 0.025,
                          ),
                          unselectedLabelColor: darkT,
                          indicator: BoxDecoration(
                              color: Color(0xff343434),
                              borderRadius: BorderRadius.circular(10)),
                          labelStyle: GoogleFonts.lexend(
                              fontSize: w * 0.025,
                              color: Colors.white,
                              fontWeight: FontWeight.w500),
                          onTap: (index) {
                            setState(() {
                              selectedIndex = index;
                            });
                          },
                        )),
                        pinned: true,
                      ),
                      SliverPersistentHeader(
                        delegate: MyDelegate(TabBar(
                          tabs: List.generate(
                              subjects.length,
                                  (index) => Tab(
                                text: subjects[index],
                              )),
                          unselectedLabelStyle: GoogleFonts.lexend(
                            fontSize: w * 0.035,
                          ),
                          isScrollable: true,
                          unselectedLabelColor: darkT,
                          indicator: BoxDecoration(
                              color: Colors.green.shade600,
                              borderRadius: BorderRadius.circular(10)),
                          labelStyle: GoogleFonts.lexend(
                              fontSize: w * 0.035,
                              color: Colors.white,
                              fontWeight: FontWeight.w500),
                          onTap: (index) {
                            setState(() {
                              selectedSubject = subjects[index];
                            });
                          },
                        )),
                        pinned: true,
                      ),
                      SliverToBoxAdapter(
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: w * 0.05,
                              right: w * 0.05,
                            ),
                            child: Column(
                              children: [
                                selectedIndex == 0
                                    ? Container(
                                  child: completedClass.length == 0
                                      ? Padding(
                                    padding: EdgeInsets.only(
                                      top: h * 0.2,
                                      bottom: h * 0.3,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                            left: w * 0.15,
                                            right: w * 0.15,
                                            bottom: w * 0.075,
                                          ),
                                          child: Image.asset(
                                              'assets/icons/empty.png'),
                                        ),
                                        Text(
                                          'No sessions here',
                                          style: GoogleFonts.lexend(
                                              fontSize: w * 0.04,
                                              color: darkT,
                                              fontWeight:
                                              FontWeight.w400),
                                        )
                                      ],
                                    ),
                                  )
                                      : ListView.builder(
                                    // controller: l< completedClass.length?scrollController:null,
                                    itemCount:completedClass.length,
                                    // l< completedClass.length?l:completedClass.length,
                                    padding:
                                    EdgeInsets.only(top: w * 0.03),
                                    shrinkWrap: true,
                                    physics:
                                    NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      DateTime date =
                                      completedClass[index]
                                      ['scheduled']
                                          .toDate();
                                      String time = formattedTime(date)
                                          .toString();
                                      return (selectedSubject !=
                                          'All' &&
                                          completedClass[index]
                                          ['subject'] !=
                                              selectedSubject)
                                          ? Container()
                                          : Padding(
                                        padding: EdgeInsets.only(
                                            bottom: w * 0.03),
                                        child: Bounce(
                                          duration: Duration(
                                              milliseconds: 110),
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder:
                                                        (context) =>
                                                        Session(
                                                          data:
                                                          completedClass[index],
                                                          index: index + 1 < 10
                                                              ? '#0${index + 1}'
                                                              : '#${index + 1}',
                                                        )));
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color:
                                                Colors.white,
                                                borderRadius:
                                                BorderRadius
                                                    .circular(
                                                    15)),
                                            child: Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: EdgeInsets
                                                        .all(w *
                                                        0.05),
                                                    child: Row(
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundColor:
                                                          back,
                                                          radius: w *
                                                              0.08,
                                                          backgroundImage:
                                                          AssetImage('assets/icons/vplay.png'),
                                                        ),
                                                        SizedBox(
                                                          width: w *
                                                              0.05,
                                                        ),
                                                        Expanded(
                                                          child:
                                                          Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            children: [
                                                              Text(
                                                                completedClass[index]['name'],
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w500, fontSize: w * 0.035, color: Colors.black),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.005,
                                                              ),
                                                              Text(
                                                                completedClass[index]['subject'],
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w400, fontSize: w * 0.03, color: darkT),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.005,
                                                              ),
                                                              Text(
                                                                ((date.toString().substring(0, 10) == DateTime.now().toString().substring(0, 10))
                                                                    ? 'Today'
                                                                    : (date.toString().substring(0, 10) == DateTime.now().add(Duration(days: -1)).toString().substring(0, 10))
                                                                    ? 'Yesterday'
                                                                    : DateFormat("MMM dd yyyy").format(date)) +
                                                                    '  ' +
                                                                    time,
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w500, fontSize: w * 0.025, color: Color(0xffFA2B3A)),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.01,
                                                              ),
                                                              Padding(
                                                                padding: EdgeInsets.only(
                                                                  left: w * 0.003,
                                                                ),
                                                                child: Text(
                                                                  'by ' + tutorMap[completedClass[index]['tutor']]['display_name'],
                                                                  style: GoogleFonts.lexend(fontWeight: FontWeight.w400, fontSize: w * 0.025, color: darkT),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  height:
                                                  w * 0.08,
                                                  width: w * 0.1,
                                                  decoration: BoxDecoration(
                                                      color: Color(
                                                          0xffFEDE00),
                                                      borderRadius:
                                                      BorderRadius.only(
                                                          topRight:
                                                          Radius.circular(15))),
                                                  child: Center(
                                                      child: Text(
                                                        index + 1 < 10
                                                            ? '#0${index + 1}'
                                                            : '#${index + 1}',
                                                        style: GoogleFonts.lexend(
                                                            fontWeight:
                                                            FontWeight
                                                                .w500,
                                                            fontSize: w *
                                                                0.025),
                                                      )),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                )
                                    : selectedIndex == 1
                                    ? Container(
                                  child: completedClass.length == 0
                                      ? Padding(
                                    padding: EdgeInsets.only(
                                      top: h * 0.2,
                                      bottom: h * 0.3,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                            left: w * 0.15,
                                            right: w * 0.15,
                                            bottom: w * 0.075,
                                          ),
                                          child: Image.asset(
                                              'assets/icons/empty.png'),
                                        ),
                                        Text(
                                          'No sessions here',
                                          style: GoogleFonts.lexend(
                                              fontSize: w * 0.04,
                                              color: darkT,
                                              fontWeight:
                                              FontWeight.w400),
                                        )
                                      ],
                                    ),
                                  )
                                      : ListView.builder(
                                    itemCount:
                                    completedClass.length,
                                    padding: EdgeInsets.only(
                                        top: w * 0.03),
                                    shrinkWrap: true,
                                    reverse: true,
                                    physics:
                                    NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      DateTime date =
                                      completedClass[index]
                                      ['scheduled']
                                          .toDate();
                                      String time =
                                      formattedTime(date)
                                          .toString();
                                      return (selectedSubject !=
                                          'All' &&
                                          completedClass[index]
                                          ['subject'] !=
                                              selectedSubject)
                                          ? Container()
                                          : Padding(
                                        padding:
                                        EdgeInsets.only(
                                            bottom:
                                            w * 0.03),
                                        child: Bounce(
                                          duration: Duration(
                                              milliseconds:
                                              110),
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Session(
                                                          data:
                                                          completedClass[index],
                                                          index: index + 1 < 10
                                                              ? '#0${index + 1}'
                                                              : '#${index + 1}',
                                                        )));
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: Colors
                                                    .white,
                                                borderRadius:
                                                BorderRadius
                                                    .circular(
                                                    15)),
                                            child: Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Expanded(
                                                  child:
                                                  Padding(
                                                    padding: EdgeInsets
                                                        .all(w *
                                                        0.05),
                                                    child:
                                                    Row(
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundColor:
                                                          back,
                                                          radius:
                                                          w * 0.08,
                                                          backgroundImage:
                                                          AssetImage('assets/icons/vplay.png'),
                                                        ),
                                                        SizedBox(
                                                          width:
                                                          w * 0.05,
                                                        ),
                                                        Expanded(
                                                          child:
                                                          Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Text(
                                                                completedClass[index]['name'],
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w500, fontSize: w * 0.035, color: Colors.black),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.005,
                                                              ),
                                                              Text(
                                                                completedClass[index]['subject'],
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w400, fontSize: w * 0.03, color: darkT),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.005,
                                                              ),
                                                              Text(
                                                                ((date.toString().substring(0, 10) == DateTime.now().toString().substring(0, 10))
                                                                    ? 'Today'
                                                                    : (date.toString().substring(0, 10) == DateTime.now().add(Duration(days: -1)).toString().substring(0, 10))
                                                                    ? 'Yesterday'
                                                                    : DateFormat("MMM dd yyyy").format(date)) +
                                                                    '  ' +
                                                                    time,
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w500, fontSize: w * 0.025, color: Color(0xffFA2B3A)),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.01,
                                                              ),
                                                              Padding(
                                                                padding: EdgeInsets.only(
                                                                  left: w * 0.003,
                                                                ),
                                                                child: Text(
                                                                  'by ' + tutorMap[completedClass[index]['tutor']]['display_name'],
                                                                  style: GoogleFonts.lexend(fontWeight: FontWeight.w400, fontSize: w * 0.025, color: darkT),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  height: w *
                                                      0.08,
                                                  width:
                                                  w * 0.1,
                                                  decoration: BoxDecoration(
                                                      color: Color(
                                                          0xffFEDE00),
                                                      borderRadius:
                                                      BorderRadius.only(topRight: Radius.circular(15))),
                                                  child: Center(
                                                      child: Text(
                                                        index + 1 <
                                                            10
                                                            ? '#0${index + 1}'
                                                            : '#${index + 1}',
                                                        style: GoogleFonts.lexend(
                                                            fontWeight: FontWeight
                                                                .w500,
                                                            fontSize:
                                                            w * 0.025),
                                                      )),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                )
                                    : Container(
                                  child: notPlayed.length == 0
                                      ? Padding(
                                    padding: EdgeInsets.only(
                                      top: h * 0.2,
                                      bottom: h * 0.3,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                            left: w * 0.15,
                                            right: w * 0.15,
                                            bottom: w * 0.075,
                                          ),
                                          child: Image.asset(
                                              'assets/icons/empty.png'),
                                        ),
                                        Text(
                                          'No sessions here',
                                          style: GoogleFonts.lexend(
                                              fontSize: w * 0.04,
                                              color: darkT,
                                              fontWeight:
                                              FontWeight.w400),
                                        )
                                      ],
                                    ),
                                  )
                                      : ListView.builder(
                                    itemCount: notPlayed.length,
                                    padding: EdgeInsets.only(
                                        top: w * 0.03),
                                    shrinkWrap: true,
                                    physics:
                                    NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      DateTime date =
                                      notPlayed[index]
                                      ['scheduled']
                                          .toDate();
                                      String time =
                                      formattedTime(date)
                                          .toString();
                                      return (selectedSubject !=
                                          'All' &&
                                          notPlayed[index]
                                          ['subject'] !=
                                              selectedSubject)
                                          ? Container()
                                          : Padding(
                                        padding:
                                        EdgeInsets.only(
                                            bottom:
                                            w * 0.03),
                                        child: Bounce(
                                          duration: Duration(
                                              milliseconds:
                                              110),
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Session(
                                                          data:
                                                          notPlayed[index],
                                                          index: index + 1 < 10
                                                              ? '#0${index + 1}'
                                                              : '#${index + 1}',
                                                        )));
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: Colors
                                                    .white,
                                                borderRadius:
                                                BorderRadius
                                                    .circular(
                                                    15)),
                                            child: Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Expanded(
                                                  child:
                                                  Padding(
                                                    padding: EdgeInsets
                                                        .all(w *
                                                        0.05),
                                                    child:
                                                    Row(
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundColor:
                                                          back,
                                                          radius:
                                                          w * 0.08,
                                                          backgroundImage:
                                                          AssetImage('assets/icons/vplay.png'),
                                                        ),
                                                        SizedBox(
                                                          width:
                                                          w * 0.05,
                                                        ),
                                                        Expanded(
                                                          child:
                                                          Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Text(
                                                                notPlayed[index]['name'],
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w500, fontSize: w * 0.035, color: Colors.black),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.005,
                                                              ),
                                                              Text(
                                                                notPlayed[index]['subject'],
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w400, fontSize: w * 0.03, color: darkT),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.005,
                                                              ),
                                                              Text(
                                                                ((date.toString().substring(0, 10) == DateTime.now().toString().substring(0, 10))
                                                                    ? 'Today'
                                                                    : (date.toString().substring(0, 10) == DateTime.now().add(Duration(days: -1)).toString().substring(0, 10))
                                                                    ? 'Yesterday'
                                                                    : DateFormat("MMM dd yyyy").format(date)) +
                                                                    '  ' +
                                                                    time,
                                                                style: GoogleFonts.lexend(fontWeight: FontWeight.w500, fontSize: w * 0.025, color: Color(0xffFA2B3A)),
                                                              ),
                                                              SizedBox(
                                                                height: w * 0.01,
                                                              ),
                                                              Padding(
                                                                padding: EdgeInsets.only(
                                                                  left: w * 0.003,
                                                                ),
                                                                child: Text(
                                                                  'by ' + tutorMap[notPlayed[index]['tutor']]['display_name'],
                                                                  style: GoogleFonts.lexend(fontWeight: FontWeight.w400, fontSize: w * 0.025, color: darkT),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  height: w *
                                                      0.08,
                                                  width:
                                                  w * 0.1,
                                                  decoration: BoxDecoration(
                                                      color: Color(
                                                          0xffFEDE00),
                                                      borderRadius:
                                                      BorderRadius.only(topRight: Radius.circular(15))),
                                                  child: Center(
                                                      child: Text(
                                                        index + 1 <
                                                            10
                                                            ? '#0${index + 1}'
                                                            : '#${index + 1}',
                                                        style: GoogleFonts.lexend(
                                                            fontWeight: FontWeight
                                                                .w500,
                                                            fontSize:
                                                            w * 0.025),
                                                      )),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                SizedBox(height: w * 0.25),
                              ],
                            ),
                          )),
                    ],
                  ),
                ),
              ));
        },
          error: (error, stackTrace) {
            print(error);
            return ErrorText(error: error.toString());},
          loading: () => Loader(),);
      },
        error: (error, stackTrace) {
          print(error);
          return ErrorText(error: error.toString());},
        loading: () => Loader(),);
    },
        error: (error, stackTrace) {
          print(error);
          return ErrorText(error: error.toString());},
        loading: () => Loader(),);

  }

  static Future downloadFile(Reference ref) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${ref.name}');

    await ref.writeToFile(file);
  }
  //
  // Row headerBottomBarWidget() {
  //   return Row(
  //     mainAxisSize: MainAxisSize.max,
  //     mainAxisAlignment: MainAxisAlignment.end,
  //     crossAxisAlignment: CrossAxisAlignment.center,
  //     children: const [
  //       Icon(
  //         Icons.settings,
  //         color: Colors.white,
  //       ),
  //     ],
  //   );
  // }

  // Widget headerWidget(BuildContext context) {
  //   DateTime date = nextClass['scheduled'].toDate();
  //   String time = formattedTime(date).toString();
  //   return Container(
  //     decoration: BoxDecoration(),
  //     child: Padding(
  //       padding: EdgeInsets.only(
  //         left: w * 0.05,
  //         right: w * 0.05,
  //       ),
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         children: [
  //           Expanded(child: SizedBox()),
  //           // Container(
  //           //   height: w*0.5,
  //           //   width: w*0.9,
  //           //   decoration: BoxDecoration(
  //           //     color: Colors.white
  //           //   ),
  //           // ),
  //           Stack(
  //             children: [
  //               // ClipRRect(
  //               //   borderRadius: BorderRadius.circular(10),
  //               //   child: FlickVideoPlayer(
  //               //       flickManager: flickManager
  //               //   ),
  //               // ),
  //               Bounce(
  //                 onPressed: () {
  //                   if (onGoing.length != 0) {
  //                     // joinMeeting(context);
  //                   }
  //                 },
  //                 duration: Duration(milliseconds: 100),
  //                 child: Container(
  //                   height: w * 0.53,
  //                   width: w * 0.9,
  //                   child: Stack(
  //                     children: [
  //                       Center(
  //                           child: Padding(
  //                         padding: const EdgeInsets.all(20),
  //                         child: Image.asset('assets/icons/logo.png'),
  //                       )),
  //                       Container(
  //                         decoration: BoxDecoration(
  //                             borderRadius: BorderRadius.circular(10),
  //                             color: Colors.black.withOpacity(0.8)),
  //                         child: Center(
  //                           child: CircleAvatar(
  //                             backgroundColor: primary.withOpacity(0.5),
  //                             radius: w * 0.08,
  //                             child: Icon(
  //                               Icons.play_arrow,
  //                               color: Colors.white,
  //                               size: 30,
  //                             ),
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //
  //               Align(
  //                 alignment: Alignment.topLeft,
  //                 child: Padding(
  //                   padding: EdgeInsets.only(
  //                     left: w * 0.03,
  //                     top: w * 0.03,
  //                   ),
  //                   child: nextClass['start'] == false
  //                       ? Column(
  //                           mainAxisAlignment: MainAxisAlignment.center,
  //                           children: [
  //                             Text(
  //                               'Starts in:',
  //                               style: GoogleFonts.poppins(
  //                                   fontSize: 14,
  //                                   fontWeight: FontWeight.w500,
  //                                   color: Colors.white),
  //                               textAlign: TextAlign.left,
  //                             ),
  //                             TotalMinuts == null
  //                                 ? Text(
  //                                     "".toString(),
  //                                     style: GoogleFonts.poppins(
  //                                         fontSize: 14,
  //                                         fontWeight: FontWeight.bold,
  //                                         color: Colors.redAccent),
  //                                     textAlign: TextAlign.left,
  //                                   )
  //                                 : Text(
  //                                     "${TotalMinuts!.inDays < 1 ? '' : TotalMinuts?.inDays}${TotalMinuts!.inDays < 1 ? '' : ':'}${TotalMinuts?.inHours.remainder(24)}:${TotalMinuts?.inMinutes.remainder(60)}"
  //                                             ":${TotalMinuts?.inSeconds.remainder(60)}"
  //                                         .toString(),
  //                                     style: GoogleFonts.poppins(
  //                                         fontSize: 14,
  //                                         fontWeight: FontWeight.bold,
  //                                         color: Colors.redAccent),
  //                                     textAlign: TextAlign.left,
  //                                   ),
  //                           ],
  //                         )
  //                       : Image.asset(
  //                           'assets/icons/live.png',
  //                           height: w * 0.05,
  //                         ),
  //                 ),
  //               )
  //             ],
  //           ),
  //           // ClipRRect(
  //           //   borderRadius: BorderRadius.circular(10),
  //           //   child: FlutterFlowVideoPlayer(
  //           //     path:'https://firebasestorage.googleapis.com/v0/b/movieflix-baeb9.appspot.com/o/users%2FiF0TtLy7QuaZFuDOGVyb1MD4Vez2%2Fuploads%2F1656669364993000.mp4?alt=media&token=325fb835-6b36-433b-af64-d5eea24ca50d',
  //           //     videoType: VideoType.network,
  //           //     autoPlay:true,
  //           //     looping: true,
  //           //     showControls: true,
  //           //     allowFullScreen: true,
  //           //     allowPlaybackSpeedMenu: false,
  //           //   ),
  //           // ),
  //           SizedBox(
  //             height: w * 0.03,
  //           ),
  //           Padding(
  //             padding: EdgeInsets.only(
  //               left: w * 0.025,
  //               right: w * 0.025,
  //             ),
  //             child: Row(
  //               children: [
  //                 Expanded(
  //                     child: Row(
  //                   children: [
  //                     CircleAvatar(
  //                       radius: w * 0.04,
  //                       backgroundImage:
  //                           NetworkImage(tutorMap[nextClass['tutor']]['image']),
  //                       backgroundColor: Colors.white,
  //                     ),
  //                     SizedBox(
  //                       width: w * 0.025,
  //                     ),
  //                     Column(
  //                       crossAxisAlignment: CrossAxisAlignment.start,
  //                       children: [
  //                         Text(
  //                           'Session by',
  //                           style: GoogleFonts.lexend(
  //                               fontWeight: FontWeight.w500,
  //                               fontSize: w * 0.03,
  //                               color: Colors.black),
  //                         ),
  //                         Text(
  //                           tutorMap[nextClass['tutor']]['name'],
  //                           style: GoogleFonts.lexend(
  //                               fontWeight: FontWeight.w500,
  //                               fontSize: w * 0.028,
  //                               color: Color(0xffFA2B3A)),
  //                         )
  //                       ],
  //                     )
  //                   ],
  //                 )),
  //                 Padding(
  //                   padding: EdgeInsets.only(
  //                     left: w * 0.003,
  //                   ),
  //                   child: Text(
  //                     '${(date.toString().substring(0, 10) == DateTime.now().toString().substring(0, 10)) ? 'Today' : (date.toString().substring(0, 10) == DateTime.now().add(Duration(days: 1)).toString().substring(0, 10)) ? 'Tomorrow' : DateFormat("MMM dd yyyy").format(date)}  $time',
  //                     style: GoogleFonts.lexend(
  //                         fontWeight: FontWeight.w400,
  //                         fontSize: w * 0.025,
  //                         color: darkT),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           ),
  //           SizedBox(
  //             height: w * 0.05,
  //           ),
  //           Padding(
  //             padding: EdgeInsets.only(
  //               left: w * 0.025,
  //               right: w * 0.025,
  //             ),
  //             child: Column(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               children: [
  //                 Text(
  //                   nextClass['name'],
  //                   style: GoogleFonts.lexend(
  //                       fontWeight: FontWeight.w500,
  //                       fontSize: w * 0.035,
  //                       color: Colors.black),
  //                 ),
  //                 Text(
  //                   'Created in ${DateFormat("MMM dd yyyy").format(nextClass['date'].toDate())}',
  //                   style: GoogleFonts.lexend(
  //                       fontWeight: FontWeight.w400,
  //                       fontSize: w * 0.025,
  //                       color: darkT),
  //                 )
  //               ],
  //             ),
  //           ),
  //           SizedBox(
  //             height: w * 0.05,
  //           ),
  //           Padding(
  //             padding: EdgeInsets.only(
  //               left: w * 0.025,
  //               right: w * 0.025,
  //             ),
  //             child: Row(
  //               children: [
  //                 Expanded(
  //                   child: Column(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: [
  //                       Text(
  //                         'Your Classmates',
  //                         style: GoogleFonts.lexend(
  //                             fontWeight: FontWeight.w500,
  //                             fontSize: w * 0.035,
  //                             color: Colors.black),
  //                       ),
  //                       Text(
  //                         '${classMates.length} Students here!',
  //                         style: GoogleFonts.lexend(
  //                             fontWeight: FontWeight.w400,
  //                             fontSize: w * 0.025,
  //                             color: darkT),
  //                       )
  //                     ],
  //                   ),
  //                 ),
  //                 Expanded(
  //                     child: Row(
  //                   children: [
  //                     classMates.length == 0
  //                         ? Container()
  //                         : Container(
  //                             height: w * 0.08,
  //                             child: Stack(
  //                               children: List.generate(
  //                                   classMates.length > 4
  //                                       ? 4
  //                                       : classMates.length, (index) {
  //                                 return Padding(
  //                                     padding: EdgeInsets.only(
  //                                         left: w * 0.07 * index),
  //                                     child: index == 3
  //                                         ? CircleAvatar(
  //                                             radius: w * 0.04,
  //                                             backgroundColor:
  //                                                 Color(0xffD9D9D9),
  //                                             child: Text(
  //                                               '+' +
  //                                                   (classMates.length - 3)
  //                                                       .toString(),
  //                                               style: GoogleFonts.lexend(
  //                                                   fontSize: w * 0.02,
  //                                                   color: Colors.black),
  //                                             ),
  //                                           )
  //                                         : Consumer(
  //                                             builder: (BuildContext context,
  //                                                 WidgetRef ref,
  //                                                 Widget? child) {
  //                                               Map<String, dynamic> map = {
  //                                                 'index':
  //                                                     index, // Add additional keys and values as needed
  //                                                 'list': classMates,
  //                                               };
  //                                               return ref
  //                                                   .watch(
  //                                                       candidatesRep1StreamProvider(
  //                                                           jsonEncode(map)))
  //                                                   .when(
  //                                                 data: (data) {
  //                                                   return (data.photo == "" ||
  //                                                           data.photo == null)
  //                                                       ? CircleAvatar(
  //                                                           radius: w * 0.04,
  //                                                           backgroundColor:
  //                                                               Color(
  //                                                                   0xffD9D9D9),
  //                                                           backgroundImage:
  //                                                               AssetImage(
  //                                                                   'assets/icons/graduation.png'),
  //                                                         )
  //                                                       : CircleAvatar(
  //                                                           backgroundImage:
  //                                                               CachedNetworkImageProvider(
  //                                                                   data.photo),
  //                                                         );
  //                                                   // Handle the data here
  //                                                 },
  //                                                 error: (error, stack) {
  //                                                   return ErrorText(
  //                                                       error:
  //                                                           error.toString());
  //                                                   // Handle error, if any
  //                                                 },
  //                                                 loading: () {
  //                                                   return const Loader();
  //                                                   // Handle loading state, if needed
  //                                                 },
  //                                               );
  //                                             },
  //                                           )
  //                                     // StreamBuilder<DocumentSnapshot>(
  //                                     //         stream: getClassZoom1(index),
  //                                     //         builder: (context, snapshot) {
  //                                     //           if (!snapshot.hasData) {
  //                                     //             return CircleAvatar(
  //                                     //               radius: w * 0.04,
  //                                     //               backgroundColor:
  //                                     //                   Color(0xffD9D9D9),
  //                                     //             );
  //                                     //           }
  //                                     //           var data = snapshot.data;
  //                                     //           return (data?['photo'] == "" ||
  //                                     //                   data?['photo'] == null)
  //                                     //               ? CircleAvatar(
  //                                     //                   radius: w * 0.04,
  //                                     //                   backgroundColor:
  //                                     //                       Color(0xffD9D9D9),
  //                                     //                   backgroundImage: AssetImage(
  //                                     //                       'assets/icons/graduation.png'),
  //                                     //                 )
  //                                     //               : CircleAvatar(
  //                                     //                   backgroundImage:
  //                                     //                       CachedNetworkImageProvider(
  //                                     //                           data?['photo']),
  //                                     //                 );
  //                                     //         }),
  //                                     );
  //                               }),
  //                             )),
  //                     Expanded(child: SizedBox()),
  //                     Bounce(
  //                       onPressed: () {
  //                         Navigator.push(
  //                             context,
  //                             MaterialPageRoute(
  //                                 builder: (context) => ChatScreen()));
  //                       },
  //                       duration: Duration(milliseconds: 100),
  //                       child: Container(
  //                         height: w * 0.08,
  //                         width: w * 0.1,
  //                         decoration: BoxDecoration(
  //                             color: Color(0xff343434),
  //                             borderRadius: BorderRadius.circular(10)),
  //                         child: Padding(
  //                           padding: EdgeInsets.all(w * 0.01),
  //                           child: SvgPicture.asset('assets/icons/message.svg'),
  //                         ),
  //                       ),
  //                     )
  //                   ],
  //                 )),
  //               ],
  //             ),
  //           ),
  //           SizedBox(
  //             height: w * 0.03,
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }
}

class MyDelegate extends SliverPersistentHeaderDelegate {
  MyDelegate(this.tabBar);
  final TabBar tabBar;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.all(10),
      height: 50,
      child: tabBar,
    );
  }

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  bool shouldRebuild(SliverPersistentHeaderDelegate oldDelegate) {
    return false;
  }
}
