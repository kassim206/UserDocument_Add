import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/core/constants/firebaseconstants/firebase_constants.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import '../../../Models/candidates_model.dart';
import '../../../core/routing/routing.dart';
import '../../homepage/screen/home_page.dart';
import '../screen/class_screen.dart';

final classRepositoryProvider = StateProvider(
        (ref) => classRepository(firestore: ref.watch(firestoreProvider)));

class classRepository {
  final FirebaseFirestore _firestore;
  classRepository({required FirebaseFirestore firestore})
      : _firestore = firestore;
  CollectionReference get _class =>
      _firestore.collection(FirebaseConstants.classCollection);
  CollectionReference get _candidates =>
      _firestore.collection(FirebaseConstants.candidatesCollection);
  int status = 0;
  Future<void> _launchInWebViewOrVC(Uri url) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.inAppWebView,
      webViewConfiguration: const WebViewConfiguration(
          headers: <String, String>{'my_header_key': 'my_header_value'}),
    )) {
      throw 'Could not launch $url';
    }
  }

  getMeetingVideo2(String id, String classId, String token) async {
    print(accessToken);
    status = 1;
    // setState(() {
    //
    // });
    print(id);
    // showDialog(
    //     context: context,
    //     builder: (context) =>
    //         Center(child: CircularProgressIndicator())
    // );
    var headers = {
      'Authorization': 'Bearer $token'
      // 'Authorization': 'Bearer $accessToken'
      //'access_token': accessToken
    };

    var response = await http.get(
        Uri.parse('https://api.zoom.us/v2/meetings/$id/recordings'),
        headers: headers);
    // Navigator.pop(context);
    status = 0;
    Map<String, dynamic> body = json.decode(response.body);

    print(response.statusCode);
    print(body);
    if (response.statusCode == 200) {
      await _launchInWebViewOrVC(
          Uri.tryParse(body['recording_files'][0]['play_url'])!);
      print(classId);
      FirebaseFirestore.instance.collection('zoomClass').doc(classId).update({
        'played': FieldValue.arrayUnion(['studentId']),
      });
    } else {
      print('Error!!');
      throw Exception('Failed to Load Post');
    }
    // if (mounted) {
    //   setState(() {
    //
    //   });
    // }
  }

  getMeetingVideo(String id, String classId, String token) async {
    Future<void> _launchInWebViewOrVC(Uri url) async {
      if (!await launchUrl(
        url,
        mode: LaunchMode.inAppWebView,
        webViewConfiguration: const WebViewConfiguration(
            headers: <String, String>{'my_header_key': 'my_header_value'}),
      )) {
        throw 'Could not launch $url';
      }
    }

    var headers = {
      // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOm51bGwsImlzcyI6ImF3QWt6Vl9wVHFHN1ExS2lwZFRxbFEiLCJleHAiOjIwNzk2MDM4NDAsImlhdCI6MTY2ODc3MTkxNH0.bSQC8Tip3vUh42Bdp3EGnC666qHiEUWgbbZr-8xEy9s'
      // 'access_token': accessToken
      'access_token': token
    };

    var response = await http.get(
      // Uri.parse('https://api.zoom.us/v2/meetings/$id/recordings?access_token=$accessToken'),
        Uri.parse(
            'https://api.zoom.us/v2/meetings/$id/recordings?access_token=$token'),
        headers: headers);

    Map<String, dynamic> body = json.decode(response.body);

    // List list = body['getCustomerList'];

    if (response.statusCode == 200) {
      _launchInWebViewOrVC(
          Uri.tryParse(body['recording_files'][0]['play_url'])!);
    _firestore.collection('zoomClass').doc(classId).update({
        'played': FieldValue.arrayUnion(['studentId']),
      });
    } else {
      throw Exception('Failed to Load Post');
    }
    // if (mounted) {
    //   setState(() {
    //
    //   });
    // }
  }

Stream<List>getMeetings(){
    return  _firestore
        .collection('zoomClass')
        .where('batch', isEqualTo: candidatesModel!.classId)
        .orderBy('scheduled', descending: false)
        .where('start', isEqualTo: true)
        .snapshots().map((event) {
          List onGoing =event.docs;
          return onGoing;
        });
}
  //TODO Change
  Stream<List> getClassRoom() {
    return _firestore.collection('class').doc(candidatesModel!.classId).snapshots().map((event){
      // classMates = [];
      classMates = event.data()?['students']??[];
      return classMates;
  });
}
Stream<String> getToken(){
    return _firestore.collection('zoomAccount')
        .where('email', isEqualTo: nextClass['email'])
        .snapshots().map((event) {
          String currentToken =event.docs.first['token'];
          return currentToken;
        });
}

  Stream getClassZoom(int index, List classMates) {
    return _firestore
        .collection('candidates')
        .doc(classMates[index])
        .snapshots();
  }
  // candidates
  Stream<CandidatesModel> candidates(int index, List classMates) {
    return _candidates.doc(classMates[index]).snapshots().map((event) {
      print('4444444444444444444');
      return CandidatesModel.fromMap(event.data() as Map<String, dynamic>);
    });
  }

  getClassZoom1(int index, List classMates) {
    _firestore
        .collection('candidates')
        .doc(classMates[index])
        .snapshots();
  }

  Stream<CandidatesModel> candidates1(int index, List classMates) {
    return _candidates.doc(classMates[index]).snapshots().map((event) {

      return CandidatesModel.fromMap(event.data() as Map<String, dynamic>);
    });
  }

  getZoomBounce() {
    _firestore
        .collection('zoomClass')
        .doc(nextClass['zoomClsId'])
        .update({
      'attendance': FieldValue.arrayUnion(['studentId']),
      'played': FieldValue.arrayUnion(['studentId']),
    });
  }
}