// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:live_to_smile/feature/view_msge/repository/viewmsge_repository.dart';
//
// final viewmsgecontroller=Provider((ref) {
//   return ViewmsgeController(viewmsgeRepository: ref.read(viewmsgeProvider));
// });
// class ViewmsgeController{
//   final ViewmsgeRepository _viewmsgeRepository;
//   ViewmsgeController({
//     required ViewmsgeRepository viewmsgeRepository,
// }):
//         _viewmsgeRepository=viewmsgeRepository;
//
//
//   updateMsg(String student,String id){
//     _viewmsgeRepository.updateMsg(student, id);
//   }
//
// }