// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:intl/intl.dart';
// import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
// import 'package:live_to_smile/feature/view_msge/controller/viewmsge_controller.dart';
// import '../../../bottom_bar/bottomBar.dart';
//
// class ViewMsgs extends ConsumerStatefulWidget {
//   final dynamic data;
//   final DateTime notDate;
//   final String notTime;
//   const ViewMsgs({Key? key, this.data,  required this.notDate,  required this.notTime}) : super(key: key);
//
//   @override
//   ConsumerState<ViewMsgs> createState() => _ViewMsgsState();
// }
//
// class _ViewMsgsState extends ConsumerState<ViewMsgs> {
//
//   // updateMsg(){
//   //   final student=ref.read(userProvider);
//   //
//   //   FirebaseFirestore.instance.collection('notifications').doc(widget.data['id']).update({
//   //     'view':FieldValue.arrayUnion([student!.uid])
//   //   });
//   // }
//   updateMsg(){
//     final student=ref.read(userProvider);
//     ref.read(viewmsgecontroller).updateMsg(student!.uid, widget.data["id"]);
//   }
//
//
//   @override
//   void initState() {
//     updateMsg();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         foregroundColor: Colors.black,
//         title: Text(((widget.notDate.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
//         'Today':(widget.notDate.toString().substring(0,10)==DateTime.now().add(Duration(days: -1)).toString().substring(0,10))?
//         'Yesterday':DateFormat("MMM dd yyyy").format(widget.notDate))+'  '+widget.notTime,style: GoogleFonts.lexend(
//             fontWeight: FontWeight.w400,fontSize: w*0.035,color: darkT
//         )),
//       ),
//       body: Padding(
//         padding:  EdgeInsets.all(w*0.075),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             Container(
//               decoration: BoxDecoration(
//                   border: Border(
//                     top: BorderSide(),
//                     left: BorderSide(),
//                     right: BorderSide(),
//                   )
//               ),
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: Text(widget.data['title'],style: GoogleFonts.lexend(
//                     fontWeight: FontWeight.w500,fontSize: w*0.045
//                 ),textAlign: TextAlign.center,),
//               ),
//             ),
//             Container(
//               decoration: BoxDecoration(
//                   border: Border.all()
//               ),
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: Text(widget.data['message'],style: GoogleFonts.lexend(
//                     fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.grey.shade700
//                 ),textAlign: TextAlign.start,),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
