// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:live_to_smile/core/providers/firebase_providers.dart';
//
//
//
// final viewmsgeProvider=Provider((ref) {
//   return ViewmsgeRepository(firestore: ref.read(firestoreProvider));
// });
//
// class ViewmsgeRepository{
//   final FirebaseFirestore _firestore;
//   ViewmsgeRepository({
//     required FirebaseFirestore firestore,
// }): _firestore=firestore;
//
//
//   updateMsg(String student,String id){
//
//     FirebaseFirestore.instance.collection('notifications').doc(id).update({
//       'view':FieldValue.arrayUnion([student])
//     });
//   }
//
// }