import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/feature/authentication/repository/auth_repository.dart';

import '../repository/feature_repository.dart';

final FeatureControllerProvider=Provider((ref) => FeatureController(featureRepository: ref.read(featureRepositoryProvider)));
final getClassStreamProvider = StreamProvider.family((ref, String classId) => ref.read(FeatureControllerProvider).getClasses(classId: classId));
final getMeetingsStreamProvider = StreamProvider.family((ref,String studentId) => ref.read(FeatureControllerProvider).getMeetings(studentId));

class FeatureController{
  final FeatureRepository _featureRepository;
  FeatureController({
    required FeatureRepository featureRepository,
  }):
        _featureRepository = featureRepository;

  getSettings(){
    return _featureRepository.getSettings();
  }

Stream getClasses({required String classId}){
  return _featureRepository.getClasses(classId);
}
Stream getMeetings(String studentId){
  return _featureRepository.getMeetings(studentId);
}
}