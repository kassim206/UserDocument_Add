import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/core/providers/firebase_providers.dart';

import '../../../core/routing/routing.dart';
import '../screen/home_page.dart';

final featureRepositoryProvider = Provider((ref) {
  return FeatureRepository(
      firestore: ref.watch(firestoreProvider),
      auth: ref.watch(authProvider),
      googleSignIn: ref.watch(googleSignInProvider));
});


class FeatureRepository {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;
  final GoogleSignIn _googleSignIn;
  FeatureRepository({
        required FirebaseFirestore firestore,
      required FirebaseAuth auth,
      required GoogleSignIn googleSignIn})
      : _firestore = firestore,
        _auth = auth,
        _googleSignIn = googleSignIn;
  //
  // CollectionReference get _users =>
  //     _firestore.collection(FirebaseConstants.userCollection);
  // CollectionReference get _settings =>
  //     _firestore.collection(FirebaseConstants.settingsCollection);

  getSettings() async {

    DocumentSnapshot doc = await _firestore
        .collection('settings')
        .doc('O0juQP9oPBfxZveBeWzn')
        .get();
    accessToken = doc.get('token');
  }

  // late StreamSubscription a;
  // late StreamSubscription b;

  // getClasses(WidgetRef ref,String classId) async {
  //
  //   while (studentId == "") {
  //     await Future.delayed(Duration(seconds: 1));
  //   }
  //   a = _firestore
  //       .collection('zoomClass')
  //       .where('batch', isEqualTo: classId)
  //       .orderBy('scheduled', descending: true)
  //       .snapshots()
  //       .listen((event) {
  //     completedClass = [];
  //     notPlayed = [];
  //     if (event.docs.isNotEmpty) {
  //       for (DocumentSnapshot data in event.docs) {
  //         List played = data['played'];
  //         if (data['status'] == 1) {
  //           completedClass.add(data);
  //         }
  //         if ((!played.contains(studentId)) && data['status'] == 1) {
  //           notPlayed.add(data);
  //         }
  //       }
  //     }
  //   });
  // }
  Stream getClasses(String classId){
    return _firestore.collection('zoomClass')
        .where('batch', isEqualTo: classId)
        .orderBy('scheduled',descending: true)
        .snapshots().map((event) {
      completedClass = [];
      notPlayed = [];
      if (event.docs.isNotEmpty) {
        for (DocumentSnapshot data in event.docs) {
          List played = data['played'];
          if (data['status'] == 1) {
            completedClass.add(data);
          }
          if ((!played.contains(studentId)) && data['status'] == 1) {
            notPlayed.add(data);
          }
        }
      }
    });
  }
  // getMeetings(WidgetRef ref,String studentId) async {
  //   while (studentId == "") {
  //     await Future.delayed(Duration(seconds: 1));
  //   }
  //   b = _firestore
  //       .collection('zoomClass')
  //       .where('batch', isEqualTo: studentId)
  //       .where('status', isEqualTo: 0)
  //       .orderBy('scheduled', descending: false)
  //       .snapshots()
  //       .listen((event) {
  //     if (event.docs.isNotEmpty) {
  //       upComing = event.docs;
  //       nextClass = event.docs[0].data();
  //     }
  //   });
  // }
  Stream getMeetings(String studentId){
    return _firestore
        .collection('zoomClass')
        .where('batch', isEqualTo: studentId)
        .where('status', isEqualTo: 0)
        .orderBy('scheduled', descending: false)
        .snapshots().map((event) {
      if (event.docs.isNotEmpty) {
        upComing = event.docs;
        nextClass = event.docs[0].data();
      }
    });
  }
}
