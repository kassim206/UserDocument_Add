import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:draggable_home/draggable_home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/notification_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:live_to_smile/core/common/loader.dart';
import 'package:live_to_smile/core/routing/routing.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../chat/chat.dart';
import '../../../payments/payments.dart';
import '../../AnnounceNotification/screens/msg_view.dart';
import '../../authentication/controller/auth_controller.dart';
import '../../courses/screen/courses_screen.dart';
import '../../resubmit/screen/resubmit_screen.dart';
import '../../searchpage/screen/searchpage_screen.dart';
import '../../session/screen/session_screen.dart';
import '../../studentData/screen/studentData_screen.dart';
import '../../univercities/screen/availablecourses_screen.dart';
import '../../view_msge/screen/viewmsge_screen.dart';
import '../cotroller/feature_controller.dart';

dynamic nextClass = {};
List completedClass = [];
List notPlayed = [];
List upComing = [];
List notifications = [];
String accessToken = '';
var studentId;

// updateProduct(){
//   FirebaseFirestore.instance.collection('candidates').get().then((value) {
//     for(DocumentSnapshot snap in value.docs){
//       // FirebaseFirestore.instance.collection('testProduct').add(snap.data());
//
//       FirebaseFirestore.instance.collection('candidates').doc(snap.id).update({
//         'active': true
//       });
//     }
//   });
// }

class HomePage extends ConsumerStatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  UsersModel? user;
  //
  // getUser(String email, String password) {
  //   ref.read(authControllerProvider)
  //       .getUser(email, password, _btnController1, context);
  // }

  //
  //
  getStudent() {
    FirebaseFirestore.instance
        .collection('candidates')
        .where('email', isEqualTo: user!.email)
        .snapshots()
        .listen((event) {
      print('asdfghj dhfgjhk : ' + event.docs[0].id);

      Map data = event.docs[0].data();
      String data2 = event.docs[0].data()['course'];
      print('asdfghjkl;');
      print(data.toString());
      print(data2.toString());

      try {
        setState(() {
          studentId = event.docs[0]['studentId'];
          candidatesModel!.classId = event.docs[0]['classId'];
          print(
              "00000000000000000000000000000000000000000000000000, ${candidatesModel!.classId}");
        });

        candidatesModel!.course = event.docs[0]['course'][0].toString();
        print('test ${event.docs[0]['course'][0]}');
      } catch (e) {
        print(e.toString());
      }
      if (mounted) {
        setState(() {});
      }
    });
  }

  getSettings() {
    ref.read(FeatureControllerProvider).getSettings();
  }

  // getMeetings() {
  //   ref.read(FeatureControllerProvider).getMeetings(ref, candidatesModel == null?"":candidatesModel!.classId);
  // }

  // getClasses() {
  //   ref.read(FeatureControllerProvider).getClasses(ref:  ref,classId:  candidatesModel==null?"":candidatesModel!.classId);
  // }

  Future<void> _launchInWebViewOrVC(Uri url) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.inAppWebView,
      webViewConfiguration: const WebViewConfiguration(
          headers: <String, String>{'my_header_key': 'my_header_value'}),
    )) {
      throw 'Could not launch $url';
    }
  }
  //
  // StreamSubscription? a;
  // StreamSubscription? b;

  @override
  void initState() {
    user = ref.read(userProvider);
    // print(candidatesModel!.email);
    // getStudent();
    getSettings();
    // getMeetings();
    // getClasses();
    super.initState();
  }

  late DateTime notDate;
  late String notTime;


  set() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    if (notifications.length != 0) {
      notDate = notifications[0]['date'].toDate();
      notTime = formattedTime(notDate).toString();
    }

    return ref.watch(getMeetingsStreamProvider(candidatesModel == null?"":candidatesModel!.classId)).when(data: (data) {
      return ref.watch(getClassStreamProvider(candidatesModel==null?"":candidatesModel!.classId)).when(data: (data) {
       return  WillPopScope(
          onWillPop: () async {
            bool ret = await showDialog(
                context: context,
                builder: (context) => Padding(
                  padding: EdgeInsets.fromLTRB(
                      20,
                      MediaQuery.of(context).size.height * 0.4,
                      20,
                      MediaQuery.of(context).size.height * 0.4),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10)),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Do you want to exit from\nLive to Smile?',
                            style: GoogleFonts.lexend(
                                fontSize: w * 0.04,
                                fontWeight: FontWeight.w600,
                                color: Colors.black,
                                decoration: TextDecoration.none),
                          ),
                          SizedBox(
                            height: 25,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  Navigator.of(context).pop(false);
                                },
                                child: Text(
                                  'NO',
                                  style: GoogleFonts.lexend(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.green,
                                      decoration: TextDecoration.none),
                                ),
                              ),
                              SizedBox(
                                width: 30,
                              ),
                              GestureDetector(
                                onTap: () {
                                  Navigator.of(context).pop(true);
                                },
                                child: Text(
                                  'EXIT',
                                  style: GoogleFonts.lexend(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.red,
                                      decoration: TextDecoration.none),
                                ),
                              ),
                              SizedBox(
                                width: 50,
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                )
              //         AlertDialog (title: Column(
              //           crossAxisAlignment: CrossAxisAlignment.start,
              //           children: [
              //             Text ('Do you want to exit from SOOK?',style: GoogleFonts.poppins(
              //               fontSize: 12,fontWeight: FontWeight.w500
              //             ),),
              //             Text ('if you exit now, the items in your cart will erase',style: GoogleFonts.poppins(
              //                 fontSize: 10
              //             ),),
              //           ],
              //         ), actions: <Widget>[
              //     ElevatedButton(
              //     child: Text ('exit '),
              //     onPressed: (){
              //       Navigator.of(context).pop(true);
              //
              //     }
              //
              //     ),
              //           ElevatedButton(
              //     child: const Text ('cancel '),
              //     onPressed: () {
              // Navigator.of(context).pop(false);
              //       },
              //     )])
            );
            return ret;
          },
          child: DraggableHome(
            headerExpandedHeight: 0.3,
            curvedBodyRadius: w * 0.07,

            leading: Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Center(
                  child: Bounce(
                    onPressed: () {
                      if (candidatesModel != null) {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => StudentData()));
                      }
                    },
                    duration: Duration(milliseconds: 100),
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      backgroundImage: user!.photo_url == ""
                          ? AssetImage('assets/icons/graduation.png') as ImageProvider
                          : CachedNetworkImageProvider(user!.photo_url),
                    ),
                  )),
            ),
            title: Text(
              'Hello ${user!.display_name} !',
              style: GoogleFonts.lexend(
                  fontWeight: FontWeight.w400,
                  fontSize: w * 0.04,
                  color: Colors.black),
            ),
            // bottom: PreferredSize(
            //   preferredSize: Size(100, 0),
            //   child: Row(
            //     children: [
            //       Text('134567890-'),
            //       Text('134567890-'),
            //       Text('134567890-'),
            //     ],
            //   ),
            // ),
            centerTitle: false,
            actions: [
              ClassIdToName[candidatesModel==null?"":candidatesModel!.classId]==null
                  ? Container()
                  : Center(
                  child: Bounce(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => Payments()));
                    },
                    duration: Duration(milliseconds: 100),
                    child: CircleAvatar(
                      radius: w * 0.05,
                      backgroundColor: Colors.white.withOpacity(0.5),
                      child: SvgPicture.asset('assets/icons/fees.svg'),
                    ),
                  )),
              SizedBox(
                width: w * 0.05,
              ),
              // Center(child: CircleAvatar(
              //   radius: w*0.05,
              //   backgroundColor: Colors.white.withOpacity(0.5),
              //   child: SvgPicture.asset('assets/icons/notification.svg'),
              // )),
              // SizedBox(width: w*0.05,)
            ],

            headerWidget: headerWidget(context),
            //headerBottomBar: headerBottomBarWidget(),

            body: [
              //TODO == changed
              (candidatesModel == null || (candidatesModel!.studentId == '') || candidatesModel!.verified == 2)
                  ? ListView(
                padding: EdgeInsets.only(top: 0),
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  candidatesModel == null ? Container() : candidatesModel!.verified == 2
                      ? Padding(
                    padding: EdgeInsets.all(w * 0.03),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Your submitted documents are rejected, please resubmit genuine documents',
                          style: GoogleFonts.lexend(
                              fontWeight: FontWeight.w600,
                              fontSize: w * 0.03,
                              color: Colors.red),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ReSubmit()));
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  height: 40,
                                  width: w * 0.35,
                                  decoration: BoxDecoration(
                                      color: Colors.green,
                                      borderRadius:
                                      BorderRadius.circular(15)),
                                  child: Center(
                                    child: Text(
                                      'Re-submit',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                      : Container(),
                  Padding(
                    padding: EdgeInsets.all(w * 0.03),
                    child: Text(
                      'Study with LTS!',
                      style: GoogleFonts.lexend(
                          fontWeight: FontWeight.w600, fontSize: w * 0.04),
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.all(w * 0.025),
                      child: Row(
                        children: [
                          Expanded(
                              child: Bounce(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => Courses()));
                                  },
                                  duration: Duration(milliseconds: 100),
                                  child:
                                  Image.asset('assets/icons/CLASS.png'))),
                          SizedBox(
                            width: w * 0.025,
                          ),
                          Expanded(
                              child: Bounce(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                Universities()));
                                  },
                                  duration: Duration(milliseconds: 100),
                                  child:
                                  Image.asset('assets/icons/UNI.png'))),
                        ],
                      )),
                ],
              )
                  : ListView(
                padding:
                EdgeInsets.only(left: w * 0.05, right: w * 0.05, top: 0),
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  ListView.builder(
                    itemCount: upComing.length,
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      return LiveClass(
                        data: upComing[index],
                        set: set,
                      );
                    },
                  ),
                  Padding(
                    padding: EdgeInsets.all(w * 0.03),
                    child: Text(
                      'Recent Saved Sessions',
                      style: GoogleFonts.lexend(
                          fontWeight: FontWeight.w600, fontSize: w * 0.04),
                    ),
                  ),
                  ListView.builder(
                    itemCount:
                    completedClass.length > 1 ? 2 : completedClass.length,
                    physics: NeverScrollableScrollPhysics(),
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      DateTime date =
                      completedClass[index]['scheduled'].toDate();
                      String time = formattedTime(date).toString();
                      return Padding(
                        padding: EdgeInsets.only(bottom: w * 0.03),
                        child: Bounce(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Session(
                                      data: completedClass[index],
                                      index: index + 1 < 10
                                          ? '#0${index + 1}'
                                          : '#${index + 1}',
                                    )));
                            // Navigator.pushAndRemoveUntil(
                            //   context,
                            //   MaterialPageRoute(
                            //       builder: (context) => BottomBar(bIndex: 1,)),
                            //       (b) => false,
                            // );
                          },
                          duration: Duration(milliseconds: 100),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(w * 0.05),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.shade300,
                                  offset: const Offset(
                                    5.0,
                                    2.0,
                                  ),
                                  blurRadius: 15.0,
                                  spreadRadius: -10.0,
                                ), //BoxShadow
                                //BoxShadow
                              ],
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(w * 0.03),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                      children: [
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            SingleChildScrollView(
                                              physics: NeverScrollableScrollPhysics(),
                                              scrollDirection: Axis.horizontal,
                                              child: Row(
                                                children: [
                                                  Image.asset(
                                                    'assets/icons/video button.png',
                                                    height: w * 0.05,
                                                  ),
                                                  SizedBox(
                                                    width: w * 0.02,
                                                  ),
                                                  Text(
                                                    completedClass[index]
                                                    ['name'],
                                                    overflow: TextOverflow.ellipsis,
                                                    style: GoogleFonts.lexend(
                                                        fontWeight:
                                                        FontWeight.w500,
                                                        fontSize: w * 0.035),
                                                  )
                                                ],
                                              ),
                                            ),
                                            SizedBox(
                                              height: w * 0.01,
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  left: w * 0.003),
                                              child: Text(
                                                completedClass[index]
                                                ['subject'],
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.lexend(
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontSize: w * 0.035,
                                                    color:
                                                    Colors.grey.shade600),
                                                maxLines: 1,
                                              ),
                                            ),
                                            SizedBox(
                                              height: w * 0.01,
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  left: w * 0.003),
                                              child: Text(
                                                completedClass[index]
                                                ['description'],
                                                style: GoogleFonts.lexend(
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    fontSize: w * 0.03,
                                                    color: darkT),
                                                maxLines: 2,
                                              ),
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          height: w * 0.02,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                CircleAvatar(
                                                  radius: w * 0.035,
                                                  backgroundImage: tutorMap[
                                                  completedClass[
                                                  index]
                                                  [
                                                  'tutor']]
                                                  ['photo_url'] ==
                                                      ''
                                                      ? AssetImage(
                                                      'assets/icons/appicon.jpg')
                                                  as ImageProvider
                                                      : NetworkImage(tutorMap[
                                                  completedClass[
                                                  index]
                                                  ['tutor']]
                                                  ['photo_url']),
                                                  backgroundColor:
                                                  Colors.white,
                                                ),
                                                SizedBox(
                                                  width: w * 0.02,
                                                ),
                                                Text(
                                                  tutorMap[completedClass[
                                                  index]['tutor']]
                                                  ['display_name'],
                                                  style: GoogleFonts.lexend(
                                                      fontWeight:
                                                      FontWeight.w500,
                                                      fontSize: w * 0.03,
                                                      color:
                                                      Color(0xffFA2B3A)),
                                                )
                                              ],
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  left: w * 0.003,
                                                  top: w * 0.01),
                                              child: Text(
                                                ((date.toString().substring(
                                                    0, 10) ==
                                                    DateTime.now()
                                                        .toString()
                                                        .substring(
                                                        0, 10))
                                                    ? 'Today'
                                                    : (date
                                                    .toString()
                                                    .substring(
                                                    0,
                                                    10) ==
                                                    DateTime.now()
                                                        .add(Duration(
                                                        days:
                                                        -1))
                                                        .toString()
                                                        .substring(
                                                        0,
                                                        10))
                                                    ? 'Yesterday'
                                                    : DateFormat(
                                                    "MMM dd yyyy")
                                                    .format(
                                                    date)) +
                                                    '  ' +
                                                    time,
                                                style: GoogleFonts.lexend(
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    fontSize: w * 0.025,
                                                    color: darkT),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    width: w * 0.03,
                                  ),
                                  Container(
                                    height: w * 0.2,
                                    width: w * 0.2,
                                    child: Stack(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                              color: back,
                                              shape: BoxShape.circle),
                                        ),
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                                left: w * 0.015),
                                            child: Image.asset(
                                              'assets/icons/play.png',
                                              width: w * 0.175,
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  Padding(
                    padding: EdgeInsets.all(w * 0.03),
                    child: Text(
                      'Last Announcement',
                      style: GoogleFonts.lexend(
                          fontWeight: FontWeight.w600, fontSize: w * 0.04),
                    ),
                  ),
                  notifications.length == 0
                      ? Container()
                      : Bounce(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ViewMsgs(
                                data: NotificationModel.fromMap(notifications[0]),
                                notDate: notDate,
                                notTime: notTime,
                              )));
                    },
                    duration: Duration(milliseconds: 100),
                    child: Container(
                      height: w * 0.4,
                      child: Stack(
                        children: [
                          Center(
                            child: Container(
                              height: w * 0.35,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius:
                                BorderRadius.circular(w * 0.05),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.shade300,
                                    offset: const Offset(
                                      5.0,
                                      2.0,
                                    ),
                                    blurRadius: 15.0,
                                    spreadRadius: -10.0,
                                  ), //BoxShadow
                                  //BoxShadow
                                ],
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(w * 0.03),
                                child: Column(
                                  children: [
                                    Align(
                                        alignment: Alignment.topLeft,
                                        child: Row(
                                          children: [
                                            CircleAvatar(
                                              backgroundColor:
                                              notifications[0]
                                              ['view']
                                                  .contains(
                                                  user!.uid)
                                                  ? Colors.green
                                                  : Colors.red,
                                              radius: w * 0.02,
                                            ),
                                            SizedBox(
                                              width: w * 0.02,
                                            ),
                                            Text(
                                                ((notDate.toString().substring(
                                                    0, 10) ==
                                                    DateTime.now()
                                                        .toString()
                                                        .substring(
                                                        0, 10))
                                                    ? 'Today'
                                                    : (notDate.toString().substring(
                                                    0,
                                                    10) ==
                                                    DateTime.now().add(Duration(days: -1)).toString().substring(
                                                        0,
                                                        10))
                                                    ? 'Yesterday'
                                                    : DateFormat("MMM dd yyyy")
                                                    .format(
                                                    notDate)) +
                                                    '  ' +
                                                    notTime,
                                                style: GoogleFonts.lexend(
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    fontSize: w * 0.025,
                                                    color: darkT)),
                                          ],
                                        )),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .spaceAround,
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                flex: 3,
                                                child: Text(
                                                  notifications[0]
                                                  ['title'],
                                                  style: GoogleFonts
                                                      .lexend(
                                                      fontWeight:
                                                      FontWeight
                                                          .w500,
                                                      fontSize:
                                                      w * 0.03),
                                                ),
                                              ),
                                              Expanded(
                                                flex: 2,
                                                child: SizedBox(),
                                              ),
                                            ],
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(
                                                left: w * 0.003),
                                            child: Text(
                                              notifications[0]
                                              ['message'],
                                              style: GoogleFonts.lexend(
                                                  fontWeight:
                                                  FontWeight.w400,
                                                  fontSize: w * 0.025,
                                                  color: darkT),
                                              maxLines: 3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topRight,
                            child: Padding(
                              padding: EdgeInsets.only(right: w * 0.03),
                              child: Image.asset(
                                'assets/icons/mike.png',
                                width: w * 0.2,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: w * 0.25)
                ],
              )
            ],
            fullyStretchable: false,
            alwaysShowTitle: false,
            alwaysShowLeadingAndAction: true,

            backgroundColor: back,
            appBarColor: primary,
          ),
        );
      }, error: (error, stackTrace) => Text(error.toString()), loading: () => Loader(),);

    }, error: (error, stackTrace) =>Text(error.toString()) , loading:() => Loader(), );

  }

  Row headerBottomBarWidget() {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: const [
        Icon(
          Icons.settings,
          color: Colors.white,
        ),
      ],
    );
  }

  Widget headerWidget(BuildContext context) {
    final student = ref.watch(userProvider);
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment(0.8, 1),
          colors: <Color>[
            Color(0xffFFEC6E),
            Color(0xffFEDE00),
          ], // Gradient from https://learnui.design/tools/gradient-generator.html
          tileMode: TileMode.mirror,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.only(
          left: w * 0.1,
          right: w * 0.1,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: SizedBox()),
            Expanded(child: SizedBox()),
            Expanded(child: SizedBox()),
            Expanded(child: SizedBox()),
            Text(
              "Hello ${user!.display_name}!",
              style: GoogleFonts.lexend(
                  fontWeight: FontWeight.w500,
                  fontSize: w * 0.06,
                  color: Colors.black),
            ),
            Padding(
              padding: EdgeInsets.only(left: w * 0.003),
              child: Text(
                ClassIdToName[candidatesModel == null ?"":candidatesModel!.classId] == null
                    ? ''
                    : "${ClassIdToName[candidatesModel!.classId]}",
                style: GoogleFonts.lexend(
                    fontWeight: FontWeight.w500,
                    fontSize: w * 0.03,
                    color: Colors.black),
              ),
            ),
            Expanded(child: SizedBox()),
            Bounce(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SearchPage()));
              },
              duration: Duration(milliseconds: 100),
              child: Container(
                height: w * 0.13,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(w * 0.5),
                ),
                child: Padding(
                  padding: EdgeInsets.only(
                    right: w * 0.05,
                    left: w * 0.05,
                  ),
                  child: Row(
                    children: [
                      SvgPicture.asset(
                        'assets/icons/search1.svg',
                        color: secondary,
                      ),
                      SizedBox(
                        width: w * 0.05,
                      ),
                      Text(
                        "Search your previous sections",
                        style: GoogleFonts.lexend(
                            fontWeight: FontWeight.w500,
                            fontSize: w * 0.03,
                            color: secondary),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(child: SizedBox()),
            Expanded(child: SizedBox()),
          ],
        ),
      ),
    );
  }
}

class LiveClass extends ConsumerStatefulWidget {
  final DocumentSnapshot data;
  final Function set;
  const LiveClass({Key? key, required this.data, required this.set})
      : super(key: key);

  @override
  ConsumerState<LiveClass> createState() => _LiveClassState();
}

class _LiveClassState extends ConsumerState<LiveClass> {
   Duration TotalMinuts=Duration();
   DateTime? inTime;
  int count = 1;

  counter(DateTime time) async {
    for (int i = count; i > 0; i--) {
      await Future.delayed(const Duration(seconds: 1));
      TotalMinuts = time.difference(DateTime.now());
    }

    if (mounted) {
      setState(() {});
    }
    counter(time);

    widget.set();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final student = ref.watch(userProvider);

    DateTime date = widget.data['scheduled'].toDate();
    String time = formattedTime(date).toString();
    counter(date);
    return Bounce(
      onPressed: () {
        if (widget.data['start'] == true) {
          FirebaseFirestore.instance
              .collection('zoomClass')
              .doc(widget.data['zoomClsId'])
              .update({
            'attendance': FieldValue.arrayUnion([student!.uid]),
          });
        }
        nextClass = widget.data;
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
              builder: (context) => BottomBar(
                    bIndex: 1,
                  )),
          (b) => false,
        );
      },
      duration: Duration(milliseconds: 100),
      child: Container(
        height: w * 0.4,
        child: Stack(
          children: [
            Center(
              child: Container(
                height: w * 0.35,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(w * 0.05),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade300,
                      offset: const Offset(
                        5.0,
                        2.0,
                      ),
                      blurRadius: 15.0,
                      spreadRadius: -10.0,
                    ), //BoxShadow
                    //BoxShadow
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.all(w * 0.03),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Image.asset(
                                'assets/icons/live.png',
                                height: w * 0.05,
                              ),
                              SizedBox(
                                width: w * 0.02,
                              ),
                              Text(
                                'Upcoming Live Session',
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * 0.035),
                              )
                            ],
                          ),
                          SizedBox(
                            height: w * 0.01,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: w * 0.003),
                            child: Text(
                              widget.data['name'],
                              style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w400,
                                  fontSize: w * 0.025,
                                  color: darkT),
                            ),
                          ),
                          SizedBox(
                            height: w * 0.01,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: w * 0.003),
                            child: Text(
                              widget.data['subject'],
                              style: GoogleFonts.lexend(
                                  fontWeight: FontWeight.w400,
                                  fontSize: w * 0.025,
                                  color: darkT),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: w * 0.003),
                                child: Text(
                                  (date.toString().substring(0, 10) ==
                                          DateTime.now()
                                              .toString()
                                              .substring(0, 10))
                                      ? 'Today'
                                      : (date.toString().substring(0, 10) ==
                                              DateTime.now()
                                                  .add(Duration(days: 1))
                                                  .toString()
                                                  .substring(0, 10))
                                          ? 'Tomorrow'
                                          : DateFormat("MMM dd yyyy")
                                              .format(date),
                                  style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w400,
                                      fontSize: w * 0.03,
                                      color: darkT),
                                ),
                              ),
                              Text(
                                time,
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * 0.045),
                              )
                            ],
                          ),
                          widget.data['start'] == false
                              ? Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    TotalMinuts < Duration(seconds: 1)
                                        ? Text(
                                            'Will start soon',
                                            style: GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black),
                                            textAlign: TextAlign.left,
                                          )
                                        : Text(
                                            'Starts in:',
                                            style: GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black),
                                            textAlign: TextAlign.left,
                                          ),
                                    TotalMinuts < Duration(seconds: 1)
                                        ? Text(
                                            "".toString(),
                                            style: GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.redAccent),
                                            textAlign: TextAlign.left,
                                          )
                                        : Text(
                                            "${TotalMinuts.inDays < 1 ? '' : TotalMinuts.inDays}${TotalMinuts.inDays < 1 ? '' : ':'}${TotalMinuts.inHours.remainder(24)}:${TotalMinuts.inMinutes.remainder(60)}"
                                                    ":${TotalMinuts.inSeconds.remainder(60)}"
                                                .toString(),
                                            style: GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.redAccent),
                                            textAlign: TextAlign.left,
                                          ),
                                  ],
                                )
                              : Container(),
                          Container(
                            decoration: BoxDecoration(
                              color: widget.data['start'] == true
                                  ? Color(0xffFA2B3A)
                                  : Color(0xff343434),
                              borderRadius: BorderRadius.circular(w * 0.04),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.shade300,
                                  offset: const Offset(
                                    5.0,
                                    2.0,
                                  ),
                                  blurRadius: 10.0,
                                  spreadRadius: -2.0,
                                ), //BoxShadow
                                //BoxShadow
                              ],
                            ),
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(
                                w * 0.03,
                                w * 0.01,
                                w * 0.03,
                                w * 0.01,
                              ),
                              child: Text(
                                widget.data['start'] == true
                                    ? 'JOIN'
                                    : 'Notify Me',
                                style: GoogleFonts.lexend(
                                    fontWeight: FontWeight.w500,
                                    fontSize: w * 0.035,
                                    color: Colors.white),
                              ),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: EdgeInsets.only(right: w * 0.03),
                child: Image.asset(
                  'assets/icons/camera.png',
                  width: w * 0.2,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
