import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:live_to_smile/payments/reports.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import '../core/common/showuploadmessage.dart';
import '../core/routing/routing.dart';

class Payments extends ConsumerStatefulWidget {
  const Payments({Key? key}) : super(key: key);

  @override
  ConsumerState<Payments> createState() => _PaymentsState();
}

class _PaymentsState extends ConsumerState<Payments> {
  List feeDetails = [];
  int currentYear = 1;

  UsersModel? user;

  final RoundedLoadingButtonController _btnController1 =
      RoundedLoadingButtonController();
  void paymentSuccessEmail(
    String paymentMode,
    String course,
    String intake,
    List emailList,
    String amount,
    String name,
  ) async {
    FirebaseFirestore.instance.collection('mail').add({
      'date': DateTime.now(),
      'html': '<body>'
          '<p>Hi <var>$name</var></p>'
          '<p>Your payment of <var>$amount</var> towards <var>$paymentMode</var> for <var>$course</var> of the academic year <var>$intake</var> is successfully received. </p>'
          '<p></p>'
          '<p></p>'
          '<p>Cordinator</p>'
          '<p>(<var>$course</var>)</p>'
          '<p>Live to smile digital academy</p>'
          '</body>',
      'emailList': emailList,
      'status': 'payment success'
    });

    print('eeee');
  }

  getPayments() {


    FirebaseFirestore.instance
        .collection('candidates')
        .doc(candidatesModel!.studentId)
        .snapshots()
        .listen((event) {
      feeDetails = event.get('feeDetails');
      currentYear = event.get('currentYear');
      if (mounted) {
        setState(() {});
      }
    });
    Future.delayed(Duration(milliseconds: 500), () {
      getPaymentData();
    });

    setState(() {});
  }

  double paid = 0.00;
  double unPaid = 0.00;
  List tuitionFee = [];
  getPaymentData() {
    paid = 0.00;

    tuitionFee = feeDetails?[currentYear - 1]['tuitionFee'] ?? [];
    print(tuitionFee.length);
    // paid+=double.tryParse(feeDetails[currentYear-1]['admissionFee'].toString())+double.tryParse(feeDetails[currentYear-1]['universityFee'].toString());
    // if(double.tryParse(feeDetails[currentYear-1]['convocationFee'].toString()).toStringAsFixed(2)!='0.00'){
    //   paid+=double.tryParse(feeDetails[currentYear-1]['convocationFee'].toString());
    // }
    for (int i = 0; i < tuitionFee.length; i++) {
      paid += double.tryParse(tuitionFee[i]['amount'].toString())!;
    }
    unPaid = (double.tryParse(
            feeDetails[currentYear - 1]['currentYearTotalFee'].toString())! -
        paid);
    if (mounted) {
      setState(() {});
    }
  }

  TextEditingController? amount;

  @override
  void initState() {
    user = ref.read(userProvider);
    _btnController1.stateStream.listen((value) {
      print(value);
    });

    _razorpay = Razorpay();
    _razorpay?.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay?.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay?.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);

    amount = TextEditingController();
    getPayments();
    super.initState();
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    //   int index=currentYear-1;
    //  print(index.toString()+'index');
    //
    //  List tuitionFeeList=feeDetails[index]['tuitionFee'];
    //  print(tuitionFeeList.length);
    //    tuitionFeeList.add({
    //      'date': Timestamp.now(),
    //      'amount': double.tryParse(amount.text),
    //      'modeOfPayment':'Bank',
    //      'paymentId':response.paymentId,
    //      'userId':currentUserId
    //    });
    //
    //
    //  List paymentList=feeDetails;
    //  Map data=feeDetails[currentYear-1];
    //  data['tuitionFee']=tuitionFeeList;
    //  await paymentList.removeAt(index);
    // await paymentList.insert(index, data);
    //
    //
    // print('working');
    //
    //
    // await FirebaseFirestore.instance.collection('candidates')
    //      .doc(studentId)
    //      .update({
    //    'feeDetails':paymentList,
    //
    //  });

    getPayments();
    getPaymentData();
    // paymentSuccessEmail('Bank',CourseIdToName[CurrentUserCourse],ClassIdToName[CurrentUserClassId],[currentUserEmail],amount.text,currentUserName);
    showUploadMessage(context, 'Paid successfully');

    _btnController1.success();
    // args['paymentId']=response.paymentId;
    // await _checkoutService.placeNewOrder(args);
    // promoCode = null;
    // Navigator.pop(context);
    // Navigator.pop(context);
    // _btnController1.success();
    // Navigator.of(context).push(
    //     MaterialPageRoute(builder: (context) => OrderSuccess(
    //     )));
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(backgroundColor: Colors.red, msg: "Payment Failed");
    _btnController1.error();
    _btnController1.reset();
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: " + response.walletName!,
        toastLength: Toast.LENGTH_SHORT);
  }

  static const platform = const MethodChannel("razorpay_flutter");
  Razorpay? _razorpay;

  Future<void> generate_ODID() async {
    final student = ref.read(userProvider);
    // final currentUserPhone=ref.read(currentUserPhoneProvider);
    // final currentUserName=ref.read(currentUserNameProvider);

    var orderOptions = {
      'amount': double.tryParse(amount!.text)! *
          100, // amount in the smallest currency unit
      'currency': "INR",
      'receipt': "order_rcptid_11"
    };
    print(1);
    final client = HttpClient();
    final request =
        await client.postUrl(Uri.parse('https://api.razorpay.com/v1/orders'));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
    print(2);
    String basicAuth = 'Basic ' +
        base64Encode(utf8.encode(
            '${'rzp_live_C190kQus1hA6p6'}:${'OUikvDm9CsPAJq6LjYaGCIOa'}'));
    print(3);
    request.headers.set(HttpHeaders.authorizationHeader, basicAuth);
    request.add(utf8.encode(json.encode(orderOptions)));
    print(4);
    final response = await request.close();
    print(5);
    response.transform(utf8.decoder).listen((contents) async {
      print(6);
      print('ORDERID' + contents);
      String orderId = contents.split(',')[0].split(":")[1];
      orderId = orderId.substring(1, orderId.length - 1);
      print(orderId + contents);
      print('orderId+contents');
      print(response.reasonPhrase.toString());
      print(12);
      print(response.certificate.toString());
      print(13);
      print(response.connectionInfo);
      Fluttertoast.showToast(
          msg: "Generating Fee Payment",
          backgroundColor: Colors.green,
          toastLength: Toast.LENGTH_SHORT);
      Map<String, dynamic> checkoutOptions = {
        'key': 'rzp_live_C190kQus1hA6p6',
        'amount': double.tryParse(amount!.text)! * 100,
        'name': 'Live to Smile',
        'order_id': orderId,
        'timeout': 600,
        'description': 'Course fee',
        'prefill': {'contact': '${user!.phoneNo}', 'email': '${user!.email}'},
        'external': {
          'wallets': ['paytm']
        }
      };
      int index = currentYear - 1;
      List tuitionFeeList = feeDetails[index]['tuitionFee'];
      tuitionFeeList.add({
        'date': Timestamp.now(),
        'amount': double.tryParse(amount!.text),
        'modeOfPayment': 'Bank',
        'paymentId': "",
        'userId': currentUserId
      });

      List paymentList = feeDetails;
      Map data = feeDetails[currentYear - 1];
      data['tuitionFee'] = tuitionFeeList;
      await paymentList.removeAt(index);
      paymentList.insert(index, data);

      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('candidates')
          .doc(user!.uid)
          .get();
      await FirebaseFirestore.instance
          .collection('pendingPayments')
          .doc(orderId)
          .set(doc.data() as Map<String, dynamic>);
      print(paymentList);
      FirebaseFirestore.instance
          .collection('pendingPayments')
          .doc(orderId)
          .update({
        'feeDetails': paymentList,
        'yearIndex': index,
        'feeIndex': tuitionFeeList.length - 1,
        'eCourse': CourseIdToName[candidatesModel!.course],
        'eIntake': ClassIdToName[candidatesModel!.classId],
        'eAmount': amount?.text,
        'eName': user!.display_name,
        'eDate': Timestamp.now()
      });
      try {
        _razorpay?.open(checkoutOptions);
      } catch (e) {
        print(e.toString());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    log('currentCourse');

    log(CourseIdToName[candidatesModel!.course]);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        title: Text(
          'Payments',
          style: GoogleFonts.lexend(),
        ),
        actions: [
          InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ReportsPage(
                              data: feeDetails,
                            )));
              },
              child: Icon(Icons.notes)),
          SizedBox(
            width: 15,
          )
        ],
      ),
      body: feeDetails.length == 0
          ? Container()
          : Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  height: w * 0.6,
                  decoration: BoxDecoration(),
                  child: Padding(
                    padding: EdgeInsets.all(w * 0.05),
                    child: Stack(
                      children: [
                        Center(
                            child: Image.asset(
                          'assets/icons/Group 25.png',
                          height: w * 0.5,
                          fit: BoxFit.cover,
                        )),
                        Padding(
                          padding: EdgeInsets.only(
                            left: w * 0.1,
                            right: w * 0.1,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Total Fee',
                                style: GoogleFonts.lexend(
                                    fontSize: 18, fontWeight: FontWeight.w700),
                              ),
                              Text(
                                '₹' +
                                    feeDetails[(currentYear - 1)]
                                            ['currentYearTotalFee']
                                        .toStringAsFixed(2),
                                style: GoogleFonts.lexend(
                                    fontSize: 25, fontWeight: FontWeight.w700),
                              ),
                              Text(
                                currentYear == 1
                                    ? '${currentYear}st Year'
                                    : currentYear == 2
                                        ? '${currentYear}nd Year'
                                        : currentYear == 3
                                            ? '${currentYear}rd Year'
                                            : '${currentYear}th Year',
                                style: GoogleFonts.lexend(
                                    fontSize: 18, fontWeight: FontWeight.w400),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                    child: Container(
                  color: Colors.grey.shade200,
                  child: Padding(
                    padding: EdgeInsets.all(w * 0.05),
                    child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 15),
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: white),
                              child: Padding(
                                padding: EdgeInsets.all(w * 0.05),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Text(
                                      'Total Fees Paid',
                                      style: GoogleFonts.lexend(fontSize: 18),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      '₹' + paid.toStringAsFixed(2),
                                      style: GoogleFonts.lexend(
                                          fontSize: 25,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.green),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      currentYear == 1
                                          ? '${currentYear}st Year'
                                          : currentYear == 2
                                              ? '${currentYear}nd Year'
                                              : currentYear == 3
                                                  ? '${currentYear}rd Year'
                                                  : '${currentYear}th Year',
                                      style: GoogleFonts.lexend(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.grey),
                                      textAlign: TextAlign.end,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 15),
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: white),
                              child: Padding(
                                padding: EdgeInsets.all(w * 0.05),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Text(
                                      'Total Balance to Pay',
                                      style: GoogleFonts.lexend(fontSize: 18),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      '₹' + unPaid.toStringAsFixed(2),
                                      style: GoogleFonts.lexend(
                                          fontSize: 25,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.red),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      currentYear == 1
                                          ? '${currentYear}st Year'
                                          : currentYear == 2
                                              ? '${currentYear}nd Year'
                                              : currentYear == 3
                                                  ? '${currentYear}rd Year'
                                                  : '${currentYear}th Year',
                                      style: GoogleFonts.lexend(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.grey),
                                      textAlign: TextAlign.end,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: Bounce(
                              onPressed: () async {
                                await addPayments();

                                setState(() {});
                              },
                              duration: Duration(milliseconds: 100),
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Color(0xff434343),
                                    borderRadius: BorderRadius.circular(20)),
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: w * 0.075,
                                    right: w * 0.075,
                                    top: w * 0.05,
                                    bottom: w * 0.05,
                                  ),
                                  child: Text(
                                    'Pay Now',
                                    style: GoogleFonts.lexend(
                                        color: white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )),
              ],
            ),
    );
  }

  addPayments() {
    if (tuitionFee.length == 2) {
      amount?.text = unPaid.toStringAsFixed(2);
    } else {
      amount?.text = '';
    }

    return showModalBottomSheet(
        backgroundColor: Colors.transparent,
        context: context,
        isScrollControlled: true,
        builder: (context) => StatefulBuilder(
              builder: (context, setState) {
                return Padding(
                  padding: MediaQuery.of(context).viewInsets,
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.3,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          topRight: Radius.circular(50),
                        )),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(15),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    'Pay your tuition fee',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    margin: EdgeInsets.only(right: 10),
                                    height: 20,
                                    width: 20,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.red),
                                    child: Center(
                                        child: Text(
                                      "X",
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                          fontSize: 12),
                                    )),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(child: SizedBox()),
                          Container(
                            width: double.infinity,
                            child: Center(
                              child: TextFormField(
                                controller: amount,
                                readOnly: tuitionFee.length == 2 ? true : false,
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  setState(() {});
                                },
                                maxLines: 1,
                                style: GoogleFonts.lexend(
                                    textStyle: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black)),
                                decoration: InputDecoration(
                                  fillColor: Colors.green.withOpacity(0.3),
                                  iconColor: Colors.black,
                                  hintStyle: GoogleFonts.lexend(
                                      textStyle: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.normal,
                                          color:
                                              Colors.black.withOpacity(0.250))),
                                  hintText: 'Enter amount here',
                                  prefixIcon: Icon(Icons.currency_rupee),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(9),
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              42, 172, 146, 0.0))),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(9),
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              42, 172, 146, 0.0))),
                                  filled: true,
                                  // border: OutlineInputBorder(
                                  //     borderRadius: BorderRadius.circular(20),
                                  //     borderSide: BorderSide(color: Colors.yellow)),
                                ),
                              ),
                            ),
                          ),
                          Expanded(child: SizedBox()),
                          RoundedLoadingButton(
                            successIcon: Icons.check,
                            failedIcon: Icons.close,
                            valueColor: Colors.black,
                            color: Color(0xffFEDE00),
                            child: Text(
                                'Pay Now\n₹${amount?.text == '' ? '0' : amount?.text}',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.lexend(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                            controller: _btnController1,
                            onPressed: () async {
                              if (amount?.text != '') {
                                if (double.tryParse(amount?.text == ''
                                            ? '0'
                                            : amount!.text)! >
                                        0 &&
                                    double.tryParse(amount?.text == ''
                                            ? '0'
                                            : amount!.text)! <=
                                        unPaid) {
                                  await generate_ODID();
                                  Navigator.pop(context);
                                } else if (double.tryParse(amount?.text == ''
                                        ? '0'
                                        : amount!.text)! >
                                    unPaid) {
                                  Fluttertoast.showToast(
                                      msg:
                                          'entered amount is greater than your total balance',
                                      backgroundColor: Colors.red);
                                  _btnController1.reset();
                                } else {
                                  Fluttertoast.showToast(
                                      msg: 'Please enter a valid amount',
                                      backgroundColor: Colors.red);
                                  _btnController1.reset();
                                }
                              } else {
                                Fluttertoast.showToast(
                                    msg: 'Please enter a valid amount',
                                    backgroundColor: Colors.red);
                                _btnController1.reset();
                              }
                            },
                          ),
                          Expanded(child: SizedBox()),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ));
  }
}
