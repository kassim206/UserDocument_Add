import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:intl/intl.dart';
import '../chat/chat.dart';

class ReportsPage extends StatefulWidget {
  final dynamic data;
  const ReportsPage({Key? key, this.data}) : super(key: key);

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  List payments = [];
  getPaymentData() {
    payments = [];
    for (dynamic data in widget.data) {
      // dynamic items=[
      //   {
      //     'name':'Admission Fee',
      //     'price':double.tryParse(data['admissionFee'].toString()),
      //     'date':data['date'],
      //   },
      //   {
      //     'name':'University Fee',
      //     'price':double.tryParse(data['universityFee'].toString()),
      //     'date':data['date'],
      //   },
      // ];
      List tuitionFee = data['tuitionFee'];
      log('ssssssdfghj');

      // if(double.tryParse(data['convocationFee'].toString()).toStringAsFixed(2)!='0.00'){
      //   payments.add({
      //     'name':'Convocation Fee',
      //     'price':double.tryParse(data['convocationFee'].toString()),
      //     'date':data['date'],
      //   },);
      // }
      for (int i = 0; i < tuitionFee.length; i++) {
        payments.add({
          'name': 'Course Fee',
          'price': double.tryParse(tuitionFee[i]['amount'].toString()),
          'date': tuitionFee[i]['date'],
        });
      }
    }
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void initState() {
    getPaymentData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade200,
        foregroundColor: Colors.black,
        elevation: 0,
        title: Text(
          'Reports',
          style: GoogleFonts.lexend(),
        ),
      ),
      body: ListView.builder(
        itemCount: payments.length,
        padding: EdgeInsets.only(
          left: w * 0.05,
          right: w * 0.05,
        ),
        itemBuilder: (context, index) {
          DateTime date = payments[index]['date'].toDate();
          String time = formattedTime(date).toString();
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15), color: white),
              child: Padding(
                padding: EdgeInsets.all(w * 0.05),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      payments[index]['name'],
                      style: GoogleFonts.lexend(fontSize: 18),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Price',
                            style: GoogleFonts.lexend(
                                color: Colors.grey.shade600, fontSize: 15),
                          ),
                          Text(
                            '₹' + payments[index]['price'].toStringAsFixed(2),
                            style: GoogleFonts.lexend(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Date',
                            style: GoogleFonts.lexend(
                                color: Colors.grey.shade600, fontSize: 15),
                          ),
                          Text(
                            ((date.toString().substring(0, 10) ==
                                        DateTime.now()
                                            .toString()
                                            .substring(0, 10))
                                    ? 'Today'
                                    : (date.toString().substring(0, 10) ==
                                            DateTime.now()
                                                .add(Duration(days: -1))
                                                .toString()
                                                .substring(0, 10))
                                        ? 'Yesterday'
                                        : DateFormat("MMM dd yyyy")
                                            .format(date)) +
                                '  ' +
                                time,
                            style: GoogleFonts.lexend(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Payment Mode',
                            style: GoogleFonts.lexend(
                                color: Colors.grey.shade600, fontSize: 15),
                          ),
                          Text(
                            'Online',
                            style: GoogleFonts.lexend(fontSize: 15),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
