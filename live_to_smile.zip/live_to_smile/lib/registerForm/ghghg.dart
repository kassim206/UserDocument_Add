//
// import 'dart:math';
//
// import 'package:animated_custom_dropdown/custom_dropdown.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter/material.dart';
// import '../homePage/routing.dart';
//
// class RegistrationFormWidget extends StatefulWidget {
//
//
//   const RegistrationFormWidget({Key? key,
//
//   }) : super(key: key);
//
//   @override
//   _RegistrationFormWidgetState createState() => _RegistrationFormWidgetState();
// }
//
// class _RegistrationFormWidgetState extends State<RegistrationFormWidget> {
//   TextEditingController? firstName;
//   TextEditingController? lastName;
//   TextEditingController? email;
//   TextEditingController? mobile;
//   TextEditingController? place;
//   TextEditingController? classController;
//   TextEditingController? address;
//   TextEditingController? university;
//   TextEditingController? course;
//   TextEditingController? classControlller;
//   TextEditingController? intakeCtlr;
//
//   TextEditingController? admissionFee;
//   TextEditingController? universityFee;
//   TextEditingController? tuitionFee;
//   TextEditingController? convacationFee;
//
//   final scaffoldKey = GlobalKey<ScaffoldState>();
//
//   List Ug=['Signature','SSLC','Plus two','Aadhaar/Passport'];
//   List Pg=['Signature','SSLC','Plus two','Aadhaar/Passport','Degree certificate','Degree marksheet'];
//   List SSLC=['Signature','8 th marksheet/self attested certificate','Aadhaar/Passport'];
//   List plusTwo=['Signature','SSLC','Aadhaar/Passport'];
//
//
//   List courseList=[];
//   String? selectedUniversity;
//   getCourses(String selectedUniversity)async{
//
//     List universityCourses=[];
//     DocumentSnapshot doc= await FirebaseFirestore.instance
//         .collection('university')
//         .doc(selectedUniversity)
//         .get();
//     courseList=doc.get('courses');
//     print(courseList);
//     for(var item in courseList){
//       universityCourses.add(CourseIdToName[item]);
//     }
//     print(universityCourses);
//     print('Jjjjjjjjjjjjjjj');
//     if(mounted){
//       setState(() {
//
//       });
//     }
//   }
//
//   List<String> classList=[];
//   String? selectedCourse;
//   String? selectedClass;
//   String? selectedIntake;
//   getClass(String selectedUniversity,String selectedCourse){
//     print(CourseIdToType[selectedCourse]);
//     FirebaseFirestore.instance
//         .collection('class')
//         .where('university',isEqualTo: selectedUniversity)
//         .where('course',isEqualTo: selectedCourse)
//         .snapshots()
//         .listen((event) {
//       classList=[];
//       for(var item in event.docs){
//         classList.add(item.get('name'));
//         ClassIdToName[item.id]=item.get('name');
//         ClassNameToId[item.get('name')]=item.id;
//       }
//       print(classList);
//     });
//
//     if(CourseIdToType[selectedCourse]=='PG'){
//       uploadDocument=Pg;
//     }else if(CourseIdToType[selectedCourse]=='UG'){
//       uploadDocument=Ug;
//     }else if(CourseIdToType[selectedCourse]=='SSLC'){
//       uploadDocument=SSLC;
//     }else{
//       uploadDocument=plusTwo;
//     }
//
//     setState(() {
//
//     });
//
//   }
//
//   DateTime? dob;
//   DateTime selectedDate = DateTime.now();
//
//   Map documents={};
//   String uploadedFileUrl='';
//
//   bool radioSelected1 = true;
//   bool cash=false;
//   bool bank=false;
//   String radioval='';
//
//   setSearchParam(String caseNumber) {
//     List<String> caseSearchList = <String>[];
//     String temp = "";
//
//     List<String> nameSplits = caseNumber.split(" ");
//     for (int i = 0; i < nameSplits.length; i++) {
//       String name = "";
//
//       for (int k = i; k < nameSplits.length; k++) {
//         name = name + nameSplits[k] + " ";
//       }
//       temp = "";
//
//       for (int j = 0; j < name.length; j++) {
//         temp = temp + name[j];
//         caseSearchList.add(temp.toUpperCase());
//       }
//     }
//     return caseSearchList;
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     firstName = TextEditingController(text: '');
//     lastName = TextEditingController(text: '');
//     email = TextEditingController(text: '');
//     mobile = TextEditingController(text: '');
//     place = TextEditingController(text: '');
//     classController = TextEditingController();
//     address = TextEditingController();
//     university = TextEditingController();
//     course = TextEditingController();
//     classControlller = TextEditingController();
//     intakeCtlr = TextEditingController();
//
//     admissionFee = TextEditingController();
//     universityFee = TextEditingController();
//     tuitionFee = TextEditingController();
//     convacationFee = TextEditingController();
//
//   }
//
//   PlatformFile pickFile;
//   late UploadTask uploadTask;
//   Future selectFile(String name)async{
//
//     final result = await FilePicker.platform.pickFiles();
//     if(result==null)
//       return;
//
//     pickFile=result.files.first;
//
//     String ext=pickFile.name.split('.').last;
//     final fileBytes = result.files.first.bytes;
//
//     showUploadMessage(context, 'Uploading...',showLoading: true);
//
//     uploadFileToFireBase(name,fileBytes,ext);
//
//     setState(() {
//
//     });
//
//   }
//   List uploadDocument=[];
//   Map data={};
//   Future uploadFileToFireBase(String name, fileBytes,String ext) async {
//
//     uploadTask= FirebaseStorage.instance.ref('uploads/${DateTime.now().toString().substring(0,10)}-$name.$ext').putData(fileBytes);
//     final snapshot= await  uploadTask.whenComplete((){});
//     final urlDownlod = await  snapshot.ref.getDownloadURL();
//
//     data.addAll({'$name':urlDownlod,});
//     print(data);
//     print('        SUCCESS           ');
//
//     showUploadMessage(context, '$name Uploaded Successfully...');
//     setState(() {
//
//     });
//   }
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: scaffoldKey,
//       appBar: AppBar(
//         backgroundColor: Color(0xFFF1F4F8),
//         iconTheme: IconThemeData(color: Color(0xFF383838)),
//         automaticallyImplyLeading: true,
//         title: Text(
//           'Student Registration Form',
//           style: FlutterFlowTheme.title2.override(
//             fontFamily: 'Lexend Deca',
//             color: Color(0xFF090F13),
//             fontSize: 20,
//             fontWeight: FontWeight.w600,
//           ),
//         ),
//         actions: [],
//         centerTitle: true,
//         elevation: 0,
//       ),
//       backgroundColor: Color(0xFFF1F4F8),
//       body:Padding(
//         padding: EdgeInsetsDirectional.fromSTEB(16, 8, 16, 16),
//         child: SingleChildScrollView(
//           physics: BouncingScrollPhysics(),
//           child: Column(
//             mainAxisSize: MainAxisSize.max,
//             children: [
//
//               Padding(
//                 padding: EdgeInsetsDirectional.fromSTEB(
//                     10, 12, 0, 0),
//                 child: Row(
//                   mainAxisSize: MainAxisSize.max,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     FlutterFlowIconButton(
//                       borderColor: Colors.transparent,
//                       borderRadius: 30,
//                       borderWidth: 1,
//                       buttonSize: 60,
//                       icon: Icon(
//                         Icons.photo_camera,
//                         color: Colors.black,
//                         size: 35,
//                       ),
//                       onPressed: () async {
//                         final selectedMedia =
//                         await selectMedia(
//                           mediaSource:
//                           MediaSource.photoGallery,
//                         );
//                         if (selectedMedia != null &&
//                             validateFileFormat(
//                                 selectedMedia.storagePath,
//                                 context)) {
//                           showUploadMessage(
//                               context, 'Uploading file...',
//                               showLoading: true);
//
//                           final metadata = SettableMetadata(
//                             contentType: 'image/jpeg',
//                             customMetadata: {
//                               'picked-file-path':
//                               selectedMedia.storagePath
//                             },
//                           );
//                           print(metadata.contentType);
//                           final uploadSnap =
//                           await FirebaseStorage
//                               .instance
//                               .ref()
//                               .child(
//                               DateTime.now()
//                                   .toLocal()
//                                   .toString()
//                                   .substring(0, 10))
//                               .child(
//                               DateTime.now()
//                                   .toLocal()
//                                   .toString()
//                                   .substring(10, 17))
//                               .putData(
//                               selectedMedia.bytes,
//                               metadata);
//                           final downloadUrl = await uploadSnap
//                               .ref
//                               .getDownloadURL();
//                           // final downloadUrl = await uploadData(
//                           //     selectedMedia.storagePath, selectedMedia.bytes);
//                           ScaffoldMessenger.of(context)
//                               .hideCurrentSnackBar();
//                           if (downloadUrl != null) {
//                             setState(() => uploadedFileUrl =
//                                 downloadUrl);
//                             showUploadMessage(
//                                 context, 'Success!');
//                           } else {
//                             showUploadMessage(context,
//                                 'Failed to upload media');
//                             return;
//                           }
//                         }
//                       },
//                     ),
//                   ],
//                 ),
//               ),
//
//               Padding(
//                 padding: EdgeInsetsDirectional.fromSTEB(30, 20, 30, 5),
//                 child: Row(
//                   children: [
//                     Expanded(
//                       child: Container(
//                         width: 330,
//                         height: 60,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: firstName,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'First Name',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               hintText: 'Please Enter First Name',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                               fontFamily: 'Montserrat',
//                               color: Colors.black,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 30,),
//                     Expanded(
//                       child: Container(
//                         width: 330,
//                         height: 60,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: lastName,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'Last Name',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               hintText: 'Please Enter Last Name',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                               fontFamily: 'Montserrat',
//                               color: Colors.black,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 30,),
//                     Expanded(
//                       child: Container(
//                         width: 330,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             inputFormatters: <TextInputFormatter>[
//                               LengthLimitingTextInputFormatter(10)
//                             ],
//                             autovalidateMode: AutovalidateMode.onUserInteraction,
//                             keyboardType: TextInputType.phone,
//                             validator: (email) {
//                               if (email.isEmpty) {
//                                 return "Enter your phone number";
//                               } else if (!RegExp(r'(^(?:[+0]9)?[0-9]{10,12}$)')
//                                   .hasMatch(email)) {
//                                 return "phone number is not valid";
//                               } else {
//                                 return null;
//                               }
//                             },
//                             controller: mobile,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'Mobile',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               hintText: 'Please Enter Mobile',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                               fontFamily: 'Montserrat',
//                               color: Colors.black,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//
//                   ],
//                 ),
//               ),
//               Padding(
//                 padding: EdgeInsetsDirectional.fromSTEB(30, 5, 30, 5),
//                 child: Row(
//                   children: [
//                     Expanded(
//                       child: Container(
//                         width: 330,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: email,
//                             autovalidateMode: AutovalidateMode.onUserInteraction,
//                             keyboardType: TextInputType.emailAddress,
//                             validator: (email) {
//                               if (email.isEmpty) {
//                                 return "Enter your email";
//                               } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w]{2,4}')
//                                   .hasMatch(email)) {
//                                 return "Email not valid";
//                               } else {
//                                 return null;
//                               }
//                             },
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'Email',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               hintText: 'Please Enter Email Address',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                               fontFamily: 'Montserrat',
//                               color: Colors.black,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 30,),
//                     Expanded(
//                       child: Container(
//                         width: 330,
//                         height: 60,
//
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: place,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'place',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               hintText: 'Please Enter place',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                               fontFamily: 'Montserrat',
//                               color: Colors.black,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 30,),
//                     Expanded(
//                       child: InkWell(
//                         onTap: () async {
//                           final DateTime selected = await showDatePicker(
//                             fieldHintText: 'dd/mm/yyyy',
//                             context: context,
//                             initialDate: DateTime.now(),
//                             firstDate: DateTime(1950),
//                             lastDate: DateTime(2050),
//                           );
//                           if (selected != null && selected != dob) {
//                             setState(() {
//                               dob = DateTime(selected.year,selected.month,selected.day,0,0,0);
//                             });
//                           }
//                         },
//                         child: Container(
//                           width: 350,
//                           height: 60,
//                           decoration: BoxDecoration(
//                             color: Colors.white,
//                             borderRadius:
//                             BorderRadius.circular(8),
//                             border: Border.all(
//                               color: Color(0xFFE6E6E6),
//                             ),
//                           ),
//                           child: Padding(
//                             padding: EdgeInsets.fromLTRB(
//                                 16, 10, 0, 0),
//                             child: Container(
//                               child:Center(child:dob==null?
//                               Text('please choose date of birth')
//                                   :Text("${dob.day}/${dob.month}/${dob.year}",
//                                 style: FlutterFlowTheme
//                                     .bodyText2
//                                     .override(
//                                     fontFamily: 'Montserrat',
//                                     color: Colors.black,
//                                     fontWeight: FontWeight.w500,
//                                     fontSize: 12
//
//                                 ), ),
//
//                               ),
//
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(width: 30,),
//               Padding(
//                 padding: EdgeInsetsDirectional.fromSTEB(30, 5, 30, 5),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceAround,
//                   children: [
//                     Expanded(
//                       child: Container(
//                         width: MediaQuery.of(context).size.width*0.2,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(8),
//                           border: Border.all(
//                               color:Color(0xFFE6E6E6)
//                           ),
//                         ),
//                         child:Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: CustomDropdown.search(
//                             hintText: 'Select University',hintStyle: TextStyle(color:Colors.black),
//                             items: universityList,
//                             controller: university,
//                             onChanged: (text){
//                               setState(() {
//                                 selectedUniversity=UniversityNameToId[university.text];
//                                 print(selectedUniversity);
//                                 course.text='';
//                                 selectedCourse;
//                                 selectedClass;
//                                 courseList=[];
//                                 classList=[];
//                                 getCourses(selectedUniversity);
//                                 setState(() {
//
//                                 });
//
//                               });
//                             },
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 30,),
//                     selectedUniversity!=null&& universityCourses.isNotEmpty?
//                     Expanded(
//                       child: Container(
//                         width: MediaQuery.of(context).size.width*0.2,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(8),
//                           border: Border.all(
//                               color:Color(0xFFE6E6E6)
//                           ),
//                         ),
//                         child:Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: CustomDropdown.search(
//                             hintText: 'Select Course',hintStyle: TextStyle(color:Colors.black),
//                             items: universityCourses,
//                             controller: course,
//                             onChanged: (text){
//                               setState(() {
//                                 selectedCourse=CourseNameToId[course.text];
//                                 getClass(selectedUniversity, selectedCourse);
//                               });
//                             },
//                           ),
//                         ),
//                       ),
//                     )
//                         :Container(),
//
//                     SizedBox(width: 30,),
//
//                     selectedUniversity!=null&& universityCourses.isNotEmpty
//                         && selectedCourse!=null&& courseList.isNotEmpty &&classList.isNotEmpty?
//                     Expanded(
//                       child: Container(
//                         width: MediaQuery.of(context).size.width*0.2,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(8),
//                           border: Border.all(
//                               color:Color(0xFFE6E6E6)
//                           ),
//                         ),
//                         child:Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: CustomDropdown.search(
//                             hintText: 'Select Class',hintStyle: TextStyle(color:Colors.black),
//                             items: classList,
//                             controller: classControlller,
//                             // excludeSelected: false,
//                             onChanged: (text){
//                               setState(() {
//                                 selectedClass=ClassNameToId[classControlller.text];
//                               });
//                             },
//                           ),
//                         ),
//                       ),
//                     )
//                         :Container(),
//
//                     SizedBox(width: 30,),
//
//                     Expanded(
//                       child: Container(
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(8),
//                           border: Border.all(
//                               color:Color(0xFFE6E6E6)
//                           ),
//                         ),
//                         child:Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: CustomDropdown.search(
//                             hintText: 'Select InTake',hintStyle: TextStyle(color:Colors.black),
//                             items: inTakes,
//                             controller: intakeCtlr,
//                             onChanged: (text){
//                               setState(() {
//                                 selectedIntake=InTakeNameToId[intakeCtlr.text];
//                               });
//                             },
//                           ),
//                         ),
//                       ),
//                     ),
//
//                   ],
//                 ),
//               ),
//
//               Padding(
//                 padding: EdgeInsetsDirectional.fromSTEB(30, 5, 30, 5),
//                 child: Row(
//                   children: [
//                     Expanded(
//                       child: Container(
//                         width: 330,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             maxLines: 5,
//                             keyboardType: TextInputType.multiline,
//                             controller: address,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'address',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               hintText: 'Please Enter address',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Colors.black,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                               fontFamily: 'Montserrat',
//                               color: Colors.black,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(width: 30,),
//
//               selectedCourse!=null?
//               Padding(
//                 padding: const EdgeInsets.only(top: 20,bottom: 20),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text('Documents',
//                       style: FlutterFlowTheme.title2.override(
//                         fontFamily: 'Lexend Deca',
//                         color: Colors.grey,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                       ),)
//                   ],
//                 ),
//               )
//                   :Container(),
//
//               selectedCourse!=null?
//               SizedBox(
//                 width: MediaQuery.of(context).size.width*0.6,
//                 child:DataTable(
//                   horizontalMargin: 10,
//                   columnSpacing: 20,
//                   columns: [
//                     DataColumn(
//                       label: Text(
//                         "Document Name",
//                         style: TextStyle(
//                             fontWeight: FontWeight.bold, fontSize: 15),
//                       ),
//                     ),
//                     DataColumn(
//                       label:  Text(
//                         "upload",
//                         style: TextStyle(
//                             fontWeight: FontWeight.bold, fontSize: 15),
//                       ),
//                     ),
//
//                   ],
//                   rows: List.generate(
//                     uploadDocument.length,
//                         (index) {
//                       var docName = uploadDocument[index];
//                       print(data.keys.toList());
//
//
//                       return DataRow(
//                         color: index.isOdd
//                             ? MaterialStateProperty.all(Colors
//                             .blueGrey.shade50
//                             .withOpacity(0.7))
//                             : MaterialStateProperty.all(
//                             Colors.blueGrey.shade50),
//                         cells: [
//                           DataCell(SelectableText(
//                             docName,
//                             style: FlutterFlowTheme.bodyText2.override(
//                               fontFamily: 'Lexend Deca',
//                               color: Colors.black,
//                               fontSize: 11,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           )),
//                           DataCell( Padding(
//                             padding: EdgeInsetsDirectional.fromSTEB(0, 0, 8, 0),
//                             child: FFButtonWidget(
//                               onPressed: ()  async {
//
//                                 bool pressed=await alert(context, 'please upload ${docName}');
//                                 if(pressed){
//                                   selectFile(docName.toUpperCase());
//                                   setState(() {
//
//                                   });
//                                 }
//
//                               },
//                               text: data.keys.toList().contains(docName.toString().toUpperCase())?'Edit':'Upload'
//                               ,options: FFButtonOptions(
//                               width: 100,
//                               height: 40,
//                               color: data.keys.toList().contains(docName.toString().toUpperCase())? Color(0xFF4B39EF):Colors.teal,
//                               textStyle: FlutterFlowTheme
//                                   .subtitle2
//                                   .override(
//                                 fontFamily: 'Poppins',
//                                 color: Colors.white,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                               elevation: 2,
//                               borderSide: BorderSide(
//                                 color: Colors.transparent,
//                                 width: 1,
//                               ),
//                               borderRadius: 50,
//                             ),
//                             ),
//                           )),
//
//                         ],
//                       );
//                     },
//                   ),
//                 ),
//               )
//                   :Container(),
//
//               Padding(
//                 padding: const EdgeInsets.only(top: 20,bottom: 20),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text('Payment',
//                       style: FlutterFlowTheme.title2.override(
//                         fontFamily: 'Lexend Deca',
//                         color: Colors.grey,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                       ),)
//                   ],
//                 ),
//               ),
//
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text('Bank'),
//                   SizedBox(width: 20,),
//                   Radio(
//                     activeColor: Colors.yellow,
//                     fillColor: MaterialStateProperty.all(Colors.black),
//                     overlayColor: MaterialStateProperty.all(Colors.grey[200]),
//                     focusColor: Colors.green,
//                     value: bank,
//                     onChanged: (value) {
//                       setState(() {
//                         value=true;
//                         bank=value;
//                         cash=false;
//                         radioval='Bank';
//                         print(radioval);
//                         radioSelected1=value;
//                       });
//                     },
//
//                     groupValue: radioSelected1,
//                   ),
//                   SizedBox(width: 40,),
//                   Text('Cash'),
//                   SizedBox(width: 20,),
//                   Radio(
//                     activeColor: Colors.yellow,
//                     fillColor: MaterialStateProperty.all(Colors.black),
//                     overlayColor: MaterialStateProperty.all(Colors.grey[200]),
//                     focusColor: Colors.green,
//                     value: cash,
//                     onChanged: (value) {
//                       value=true;
//
//                       setState(() {
//                         radioval='Cash';
//                         print(radioval);
//                         cash = value;
//                         bank=false;
//                         radioSelected1=value;
//                       });
//                     },
//
//                     groupValue: radioSelected1,
//                   ),
//                 ],
//               ),
//
//               Padding(
//                 padding: EdgeInsets.only(top: 20,left: 20,right: 20),
//                 child:  Row(
//                   children: [
//                     Expanded(
//                       child: Container(
//                         width: 350,
//                         height: 60,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: admissionFee,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'Admission Fee',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color: Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//                               ),
//                               hintText: 'Please Enter Admission Fee',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color: Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Color(0xFF8B97A2),
//                                 fontWeight: FontWeight.w500,
//                                 fontSize: 13
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 10,),
//                     Expanded(
//                       child: Container(
//                         width: 350,
//                         height: 60,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: universityFee,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'University Fee',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color:Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               hintText: 'Please Enter University Fee',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color: Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Color(0xFF8B97A2),
//                                 fontWeight: FontWeight.w500,
//                                 fontSize: 12
//
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 10,),
//                     Expanded(
//                       child: Container(
//                         width: 350,
//                         height: 60,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: tuitionFee,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'Tuition Fee',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color:Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               hintText: 'Please Enter Tuition Fee',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color: Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Color(0xFF8B97A2),
//                                 fontWeight: FontWeight.w500,
//                                 fontSize: 12
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 10,),
//                     Expanded(
//                       child: Container(
//                         width: 350,
//                         height: 60,
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius:
//                           BorderRadius.circular(8),
//                           border: Border.all(
//                             color: Color(0xFFE6E6E6),
//                           ),
//                         ),
//                         child: Padding(
//                           padding: EdgeInsets.fromLTRB(
//                               16, 0, 0, 0),
//                           child: TextFormField(
//                             controller: convacationFee,
//                             obscureText: false,
//                             decoration: InputDecoration(
//                               labelText: 'Convocation Fee',
//                               labelStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color:Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               hintText: 'Please Enter Convocation Fee',
//                               hintStyle: FlutterFlowTheme
//                                   .bodyText2
//                                   .override(
//                                   fontFamily: 'Montserrat',
//                                   color: Colors.black,
//                                   fontWeight: FontWeight.w500,
//                                   fontSize: 12
//
//                               ),
//                               enabledBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                               focusedBorder:
//                               UnderlineInputBorder(
//                                 borderSide: BorderSide(
//                                   color: Colors.transparent,
//                                   width: 1,
//                                 ),
//                                 borderRadius:
//                                 const BorderRadius.only(
//                                   topLeft:
//                                   Radius.circular(4.0),
//                                   topRight:
//                                   Radius.circular(4.0),
//                                 ),
//                               ),
//                             ),
//                             style: FlutterFlowTheme.bodyText2
//                                 .override(
//                                 fontFamily: 'Montserrat',
//                                 color: Color(0xFF8B97A2),
//                                 fontWeight: FontWeight.w500,
//                                 fontSize: 12
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//
//               //FINISH
//               Padding(
//                 padding: EdgeInsetsDirectional.fromSTEB(0, 24, 0, 44),
//                 child: FFButtonWidget(
//                   onPressed: () async {
//                     if(firstName.text!=''&&lastName.text!=''&&mobile.text!=''&&email.text!=''&&uploadedFileUrl!=''&&
//                         dob!=''&& address.text!=''&&place.text!=''&&selectedClass!=''&&selectedIntake!='' &&
//                         admissionFee.text!=''&&universityFee!=''){
//
//                       bool pressed= await alert(context, 'Register As Student...');
//                       if(pressed){
//
//                         DocumentSnapshot doc =
//                         await FirebaseFirestore
//                             .instance
//                             .collection('settings')
//                             .doc(currentbranchId)
//                             .get();
//                         FirebaseFirestore.instance
//                             .collection('settings')
//                             .doc(currentbranchId)
//                             .update({
//                           'studentId': FieldValue.increment(1),
//                         });
//                         int studentId =
//                         doc.get('studentId');
//                         studentId++;
//
//                         List tuitionFeeList=[];
//                         if(tuitionFee.text!='') {
//                           tuitionFeeList.add({
//                             'date': DateTime.now(),
//                             'amount': double.tryParse(tuitionFee.text ?? 0),
//                             'modeOfPayment':radioval,
//                             'userId':currentUserUid
//                           });
//                         }
//
//                         List paymentList=[];
//                         paymentList.add({
//                           'admissionFee':double.tryParse(admissionFee.text),
//                           'universityFee':double.tryParse(universityFee.text),
//                           'tuitionFee':tuitionFeeList,
//                           'convocationFee':double.tryParse(convacationFee.text)??0,
//                         });
//
//                         List list =[
//                           {
//                             'name':'Personal Details',
//                             'completed':false,
//                           },
//                           {
//                             'name':'Fee Details',
//                             'completed':false,
//                           },
//                           {
//                             'name':'Classes',
//                             'completed':false,
//                           },
//                           {
//                             'name':'Documents',
//                             'completed':false,
//                           },
//                         ];
//
//                         FirebaseFirestore.instance.collection('candidates')
//                             .doc(currentbranchShortName+studentId.toString())
//                             .set({
//                           'enquiryId':widget.eId,
//                           'form':list,
//                           'date':DateTime.now(),
//                           'status':0,
//                           'name':firstName.text,
//                           'lastName':lastName.text,
//                           'mobile':mobile.text,
//                           'countryCode':'IN',
//                           'phoneCode':'+91',
//                           'email':email.text,
//                           'dob':dob,
//                           'place':place.text,
//                           'educationalDetails':widget.educationalDetails??[],
//                           'address':address.text,
//                           'gender':'',
//                           'branchId':currentbranchId,
//                           'userId':currentUserUid,
//                           'currentStatus':'Registered',
//                           'search':setSearchParam(firstName.text+' '+mobile.text),
//                           'photo':uploadedFileUrl,
//                           'studentId':currentbranchShortName+studentId.toString(),
//                           'discount':0.0,
//                           'dueDate':DateTime.now(),
//                           'classId':selectedClass,
//                           'inTake':selectedIntake,
//                           'course':selectedCourse,
//                           'university':selectedUniversity,
//                           'documents':data,
//                           'currentYear':1,
//                           'feeDetails':paymentList,
//
//                         }).then((value) {
//
//                           if(widget.eId!=null){
//                             FirebaseFirestore.instance.collection('enquiry').doc(widget.eId).update({
//                               'status':1,
//                               'studentId':currentbranchShortName+studentId.toString(),
//                             });
//                           }
//
//                           List StudentList=[];
//                           StudentList.add(currentbranchShortName+studentId.toString());
//
//                           FirebaseFirestore.instance.collection('class')
//                               .doc(selectedClass)
//                               .update({
//                             'students':FieldValue.arrayUnion(StudentList),
//                           });
//
//                         });
//                         showUploadMessage(context, 'New Student Registered...');
//
//                         Navigator.pop(context);
//
//                       }
//
//                     }else{
//                       firstName.text==''?showUploadMessage(context, 'Please Enter First Name'):
//                       lastName.text==''?showUploadMessage(context, 'Plase Enter Last Place'):
//                       mobile.text==''?showUploadMessage(context, 'Please Enter Mobile Number'):
//                       email.text==''?showUploadMessage(context, 'Please Enter Email'):
//                       selectedClass==''?showUploadMessage(context, 'Please select class'):
//                       selectedIntake==''?showUploadMessage(context, 'Please select intake'):
//                       selectedUniversity==''?showUploadMessage(context, 'Please select university'):
//                       dob==null?showUploadMessage(context, 'Please select date of birth'):
//                       address.text==''?showUploadMessage(context, 'Please Enter Address'):
//                       place.text==''?showUploadMessage(context, 'Please Enter Place'):
//                       showUploadMessage(context, 'Please upload image');
//
//                     }
//
//                   },
//                   text: 'Register As Student',
//                   options: FFButtonOptions(
//                     width: 200,
//                     height: 50,
//                     color: Color(0xFF4B39EF),
//                     textStyle: FlutterFlowTheme.subtitle2.override(
//                       fontFamily: 'Lexend Deca',
//                       color: Colors.white,
//                       fontSize: 12,
//                       fontWeight: FontWeight.bold,
//                     ),
//                     elevation: 2,
//                     borderSide: BorderSide(
//                       color: Colors.transparent,
//                       width: 1,
//                     ),
//                     borderRadius: 10,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }