import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';
import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/core/routing/routing.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:mime_type/mime_type.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import '../bottom_bar/bottomBar.dart';
import '../core/common/showuploadmessage.dart';

Future uploadData(String path, Uint8List data) async {
  final storageRef = FirebaseStorage.instance.ref().child(path);
  final metadata = SettableMetadata(contentType: mime(path));
  final result = await storageRef.putData(data, metadata);
  return result.state == TaskState.success ? result.ref.getDownloadURL() : null;
}

class registerForm extends ConsumerStatefulWidget {

  final dynamic data;
  final String? course;
  final String? courseId;
  const registerForm({Key? key, this.data, this.course, this.courseId,})
      : super(key: key);

  @override
  ConsumerState<registerForm> createState() => _registerFormState();
}

class _registerFormState extends ConsumerState<registerForm> {
  UsersModel? user;
  TextEditingController firstName = TextEditingController();
  TextEditingController lastName = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController mobile = TextEditingController();
  TextEditingController place = TextEditingController();
  TextEditingController classController = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController university = TextEditingController();
  TextEditingController course = TextEditingController();
  TextEditingController classControlller = TextEditingController();
  TextEditingController intakeCtlr = TextEditingController();
  TextEditingController admissionFee = TextEditingController();
  TextEditingController universityFee = TextEditingController();
  TextEditingController tuitionFee = TextEditingController();
  TextEditingController convacationFee = TextEditingController();
  TextEditingController amount = TextEditingController();
  TextEditingController totalFee = TextEditingController();
  DateTime selectedDate = DateTime.now();
  DateTime currentDate = DateTime.now();

  String phoneCode = '+91';
  String countryCode = 'IN';

  selectDate(BuildContext context) async {
    final DateTime? selected = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1950),
      lastDate: DateTime(2050),
    );
    if (selected != null && selected != selectedDate) {
      setState(() {
        selectedDate = selected;
      });
    }
  }

  List Ug = ['Signature', 'SSLC', 'Plus two', 'Aadhaar/Passport'];
  List Pg = [
    'Signature',
    'SSLC',
    'Plus two',
    'Aadhaar/Passport',
    'Degree certificate',
    'Degree marksheet'
  ];
  List SSLC = [
    'Signature',
    '8 th marksheet/self attested certificate',
    'Aadhaar/Passport'
  ];
  List plusTwo = ['Signature', 'SSLC', 'Aadhaar/Passport'];

  List<String> classList = ['Select Batch'];

  getClass(String selectedUniversity, String selectedCourse) {
    print(UniversityNameToId[selectedUniversity]);
    print(selectedCourse);
    print('ddddddddd');
    print(CourseIdToType[selectedCourse]);
    FirebaseFirestore.instance
        .collection('class')
        .where('university', isEqualTo: UniversityNameToId[selectedUniversity])
        .where('course', isEqualTo: selectedCourse)
        .snapshots()
        .listen((event) {
      classList = [];
      for (var item in event.docs) {
        classList.add(item.get('name'));
        ClassIdToName[item.id] = item.get('name');
        ClassNameToId[item.get('name')] = item.id;
      }

      String courseName=CourseIdToName[selectedCourse];

      if(classList.isEmpty){
        Navigator.pop(context);
        showUploadMessage(context, 'No batch found for ${courseName}');
      }
      print(classList);
    });

    if (CourseIdToType[selectedCourse] == 'PG') {
      uploadDocument = Pg;
    } else if (CourseIdToType[selectedCourse] == 'UG') {
      uploadDocument = Ug;
    } else if (CourseIdToType[selectedCourse] == 'SSLC') {
      uploadDocument = SSLC;
    } else {
      uploadDocument = plusTwo;
    }


    setState(() {});
  }

  DateTime? dob;

  Map documents = {};
  String uploadedFileUrl = '';

  bool document = true;
  bool showUniversity = true;
  bool feeDetails = true;
  bool radioSelected1 = true;
  bool cash = false;
  bool bank = true;
  String radioval = 'Bank';
  bool radioSelected2 = true;
  bool male = false;
  bool female = false;
  bool other = false;
  String radioval2 = '';
  double convectionFee = 0;
  double addmissionFees = 0;
  double univFee = 0;
  double tuision = 0;
  double total = 0;
  final RoundedLoadingButtonController _btnController1 =
      RoundedLoadingButtonController();
  final RoundedLoadingButtonController _btnController2 =
      RoundedLoadingButtonController();
  setSearchParam(String caseNumber) {
    List<String> caseSearchList = <String>[];
    String temp = "";

    List<String> nameSplits = caseNumber.split(" ");
    for (int i = 0; i < nameSplits.length; i++) {
      String name = "";

      for (int k = i; k < nameSplits.length; k++) {
        name = name + nameSplits[k] + " ";
      }
      temp = "";

      for (int j = 0; j < name.length; j++) {
        temp = temp + name[j];
        caseSearchList.add(temp.toUpperCase());
      }
    }
    return caseSearchList;
  }

  List<String> intakes = ['Select Intake'];
  Map<String, dynamic> intakesId = {};
  String inTakeId = '';

  getIntakes() {
    FirebaseFirestore.instance
        .collection('intakes').where('available',isEqualTo: true)
        .snapshots()
        .listen((event) {
      intakes = [];
      for (DocumentSnapshot doc in event.docs) {
        intakes.add(doc.get('intakeName'));
        intakesId[doc.get('intakeName')] = doc.id;
      }

      if (mounted) {
        setState(() {});
      }
    });
  }

  Map<String, dynamic> universityId = {};

  getUniversity() {
    FirebaseFirestore.instance
        .collection('university')
        .snapshots()
        .listen((event) {
      for (DocumentSnapshot doc in event.docs) {
        universityId[doc.get('name')] = doc.id;
      }

      if (mounted) {
        setState(() {});
      }
    });
  }

  Map<String, dynamic> enquiryId = {};

  getEnguiry() {
    print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
    print(user);
    FirebaseFirestore.instance
        .collection('enquiry')
        .where('email', isEqualTo: user!.email)
        .snapshots()
        .listen((event) {
      if (event.docs.isNotEmpty) {
        enquiryId[event.docs[0].get('email')] = event.docs[0].id;
        print(enquiryId[user!.email]);
        print('+++++++++++++++++++++++++++++++++++++++++++');
      }

      if (mounted) {
        setState(() {});
      }
    });
  }

  PlatformFile? pickFile;
  String selected = '';
  Future selectFile(String name) async {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result == null) return;

    pickFile = result.files.first;
    selected = name + '0';
    String ext = '';
    final fileBytes = result.files.first.bytes;

    //showUploadMessage(context, 'Uploading...',showLoading: true);

    uploadFileToFireBase(name, fileBytes, ext);

    setState(() {});
  }

  UploadTask? uploadTask;
  List uploadDocument = [];
  Map data = {};
  Future uploadFileToFireBase(String name, fileBytes, String ext) async {
    uploadTask = FirebaseStorage.instance
        .ref('uploads/${DateTime.now().toString().substring(0, 10)}-$name.$ext')
        .putData(fileBytes);
    final snapshot = await uploadTask?.whenComplete(() {});
    final urlDownlod = await snapshot?.ref.getDownloadURL();
    data.addAll({
      '$name': urlDownlod,
    });

    selected = name + '1';
    showUploadMessage(context, '$name Uploaded Successfully...');
    setState(() {});
  }

  getFees() {
    convectionFee =
        double.parse(widget.data['feeList'][0]['convactionFee'].toString());
    addmissionFees =
        double.parse(widget.data['feeList'][0]['admissionFee'].toString());
    univFee =
        double.parse(widget.data['feeList'][0]['universityFee'].toString());
    tuision = double.parse(widget.data['feeList'][0]['tuitionFee'].toString());
    total = double.parse(widget.data['feeList'][0]['totalFee'].toString());
    setState(() {});
  }

  final _firebaseStorage = FirebaseStorage.instance;
  String imageUrl = "";
  TextEditingController subject = TextEditingController();
  TextEditingController discription = TextEditingController();

  File? file;
  int imageStatus = 0;
  pickGellary() async {
    final imgfile =
        await ImagePicker.platform.pickImage(source: ImageSource.gallery);
    file = File(imgfile!.path);
    file = File(imgfile.path);
    DocumentSnapshot id = await FirebaseFirestore.instance
        .collection('settings')
        .doc("O0juQP9oPBfxZveBeWzn")
        .get();
    id.reference.update({"image": FieldValue.increment(1)});
    var imageId = id['image'];
    imageStatus = 1;
    setState(() {});
    showUploadMessage(context, 'Uploading...', showLoading: true);
    //Upload to Firebase
    var snapshot = await _firebaseStorage
        .ref()
        .child('registerform/$imageId')
        .putFile(file!);
    var downloadUrl = await snapshot.ref.getDownloadURL();
    imageStatus = 2;
    showUploadMessage(
      context,
      'Success',
    );
    setState(() {
      imageUrl = downloadUrl;
    });
    if (mounted) {
      setState(() async {
        file = File(imgfile.path);
      });
    }
  }

  pickFiles() async {
    final imgfile =
        await ImagePicker.platform.pickImage(source: ImageSource.camera);
    file = File(imgfile!.path);
    file = File(imgfile.path);
    imageStatus = 1;
    setState(() {});
    DocumentSnapshot id = await FirebaseFirestore.instance
        .collection('settings')
        .doc("O0juQP9oPBfxZveBeWzn")
        .get();
    id.reference.update({"image": FieldValue.increment(1)});
    var imageId = id['image'];

    //Upload to Firebase
    var snapshot = await _firebaseStorage
        .ref()
        .child('registerform/$imageId')
        .putFile(file!);
    var downloadUrl = await snapshot.ref.getDownloadURL();
    imageStatus = 2;
    setState(() {
      imageUrl = downloadUrl;
    });
    if (mounted) {
      setState(() async {
        file = File(imgfile.path);
      });
    }
  }

  late QuerySnapshot student;
  checkEmail(String email) async {
    student = await FirebaseFirestore.instance
        .collection('candidates')
        .where('email', isEqualTo: email)
        .where('active', isEqualTo: true)
        .get();
    setState(() {});
  }

  @override
  void initState() {
    print(widget.data['duration']);
    print('1234567890');
    user=ref.read(userProvider);
    super.initState();
    _btnController1.stateStream.listen((value) {
      print(value);
    });
    _btnController2.stateStream.listen((value) {
      print(value);
    });
    _razorpay = Razorpay();
    _razorpay?.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay?.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay?.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    getIntakes();
    getFees();
    getEnguiry();
    getUniversity();
    getClass(widget.data['university'], widget.courseId!);
    firstName = TextEditingController(text: '');
    lastName = TextEditingController(text: '');
    email = TextEditingController(text:user!.email);
    mobile = TextEditingController(text: '');
    place = TextEditingController(text: '');
    classController = TextEditingController();
    address = TextEditingController();
    university = TextEditingController(text: widget.data['university']);
    course = TextEditingController(text: widget.course);
    classControlller = TextEditingController();
    intakeCtlr = TextEditingController();
    admissionFee =
        TextEditingController(text: addmissionFees.toStringAsFixed(1));
    universityFee = TextEditingController(text: univFee.toStringAsFixed(1));
    tuitionFee = TextEditingController(text: tuision.toStringAsFixed(2));
    convacationFee =
        TextEditingController(text: convectionFee.toStringAsFixed(1));
    totalFee = TextEditingController(text: total.toStringAsFixed(1));
    amount = TextEditingController(text: total.toStringAsFixed(1));
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
   //  DocumentSnapshot doc = await FirebaseFirestore.instance
   //      .collection('settings')
   //      .doc('O0juQP9oPBfxZveBeWzn')
   //      .get();
   //  FirebaseFirestore.instance
   //      .collection('settings')
   //      .doc('O0juQP9oPBfxZveBeWzn')
   //      .update({
   //    'studentId': FieldValue.increment(1),
   //  });
   //  int studentId = doc.get('studentId');
   //  studentId++;
   //
   //  List tuitionFeeList = [];
   //  if (tuitionFee?.text != '') {
   //    tuitionFeeList.add({
   //      'date': Timestamp.now(),
   //      'amount': double.tryParse(amount.text),
   //      'modeOfPayment': radioval,
   //      'paymentId': response.paymentId,
   //      'userId': currentUserId
   //    });
   //  }
   //
   //  List paymentList = [];
   //  paymentList.add({
   //    'admissionFee': double.tryParse(admissionFee.text),
   //    'universityFee': double.tryParse(universityFee.text),
   //    'currentYearTotalFee': double.tryParse(totalFee.text),
   //    'scholarship': 0,
   //    'paymentId': response.paymentId,
   //    'date': Timestamp.now(),
   //    'tuitionFee': tuitionFeeList,
   //    'convocationFee': double.tryParse(convacationFee.text) ?? 0,
   //  });
   //
   //  List list = [
   //    {
   //      'name': 'Personal Details',
   //      'completed': false,
   //    },
   //    {
   //      'name': 'Fee Details',
   //      'completed': false,
   //    },
   //    {
   //      'name': 'Classes',
   //      'completed': false,
   //    },
   //    {
   //      'name': 'Documents',
   //      'completed': false,
   //    },
   //  ];
   //
   // await FirebaseFirestore.instance
   //      .collection('candidates')
   //      .doc('LTS' + studentId.toString())
   //      .set({
   //    'enquiryId': enquiryId[currentUserEmail],
   //    'form': list,
   //    'date': DateTime.now(),
   //    'status': 0,
   //    'name': firstName.text,
   //    'lastName': lastName.text,
   //    'mobile': mobile.text,
   //    'countryCode': countryCode,
   //    'phoneCode': phoneCode,
   //    'email': email.text,
   //    'dob': selectedDate,
   //    'place': place.text,
   //    'educationalDetails': [],
   //    'address': address.text,
   //    'gender': radioval2,
   //    'branchId': 'O0juQP9oPBfxZveBeWzn',
   //    'userId': currentUserId,
   //    'currentStatus': 'Registered',
   //    'scholarship': '',
   //    'search': setSearchParam(firstName.text + ' ' + mobile.text),
   //    'photo': imageUrl,
   //    'studentId': 'LTS' + studentId.toString(),
   //    'discount': 0.0,
   //    'dueDate': DateTime.now(),
   //    'classId': ClassNameToId[classController?.text],
   //    'inTake': inTakeId,
   //    'course': widget.courseId,
   //    'university': universityId[widget.data['university']],
   //    'documents': data,
   //    'currentYear': 1,
   //    'courseDuration': widget.data['duration'],
   //    'feeDetails': paymentList,
   //    'verified': 0,
   //    'active': true,
   //  }).then((value) {
   //    if (enquiryId[currentUserEmail] != null) {
   //      FirebaseFirestore.instance
   //          .collection('enquiry')
   //          .doc(enquiryId[currentUserEmail])
   //          .update({
   //        'status': 1,
   //        'studentId': 'LTS' + studentId.toString(),
   //      });
   //    }
   //
   //    List StudentList = [];
   //    StudentList.add('LTS' + studentId.toString());
   //
   //    FirebaseFirestore.instance
   //        .collection('class')
   //        .doc(ClassNameToId[classController?.text])
   //        .update({
   //      'students': FieldValue.arrayUnion(['LTS' + studentId.toString()]),
   //    });
   //  });
   //  register_student(course.text,intakeCtlr.text,[email.text],firstName.text+lastName.text);
    showUploadMessage(context, 'New Student Registered...');
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
          builder: (context) => BottomBar(
                bIndex: 0,
              )),
      (b) => false,
    );
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(backgroundColor: Colors.red, msg: "Payment Failed");
    _btnController1.error();
    _btnController1.reset();
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: " + response.walletName!,
        toastLength: Toast.LENGTH_SHORT);
  }
  void register_student(
      String course,
      String intake,
      List emailList,
      String name)
  async {

    FirebaseFirestore.instance
        .collection('mail')
        .add({
      'date':DateTime.now(),
      'html':
      '<body>'
          '<p>Hi <var>$name</var></p>'
          '<p>Your admission for <var>$course</var> for the academic year <var>$intake</var> with Live To Smile Digital Academy is successfully registered.</p>'
          '<p></p>'
          '<p>Lets do it together.</p>'
          '<p>Coordinator-<var>$course</var></p>'
          '<p></p>'
          '</body>',
      'emailList':emailList,
      'status':'Registration successful'
    });

    // "<body><p>Hi <var>"+name+"</var></p><p>Your admission for <var>"+course+"</var> for the academic year <var>"+intake+"</var> with Live To Smile Digital Academy is successfully registered.</p><p></p><p>Lets do it together.</p><p>Coordinator-<var>"+course+"</var></p><p></p></body>"

    print('eeee');
  }

  static const platform = const MethodChannel("razorpay_flutter");
  Razorpay? _razorpay;
  Future<void> generate_ODID() async {
    _btnController1.start();
    var orderOptions = {
      'amount': double.tryParse(amount.text == '' ? '0' : amount.text)! *100,
      // 'amount': 1 *
      //     100, // amount in the smallest currency unit
      'currency': "INR",
      'receipt': "order_rcptid_11"
    };
    print(1);
    final client = HttpClient();
    final request =
        await client.postUrl(Uri.parse('https://api.razorpay.com/v1/orders'));
    request.headers
        .set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
    print(2);
    String basicAuth = 'Basic ' +
        base64Encode(utf8.encode(
            '${'rzp_live_C190kQus1hA6p6'}:${'OUikvDm9CsPAJq6LjYaGCIOa'}'));
    print(3);
    request.headers.set(HttpHeaders.authorizationHeader, basicAuth);
    request.add(utf8.encode(json.encode(orderOptions)));
    print(4);
    final response = await request.close();
    print(5);
    response.transform(utf8.decoder).listen((contents) async {
      print(6);

      String orderId = contents.split(',')[0].split(":")[1];
      orderId = orderId.substring(1, orderId.length - 1);
      print(orderId + contents);
      print('orderId+contents');
      print(response.reasonPhrase.toString());
      print(12);
      print(response.certificate.toString());
      print(13);
      print(response.connectionInfo);
      Fluttertoast.showToast(
          msg: "Generating Fee Payments",
          backgroundColor: Colors.green,
          toastLength: Toast.LENGTH_SHORT);
      Map<String, dynamic> checkoutOptions = {
        'key': 'rzp_live_C190kQus1hA6p6',
        // 'amount': 1 * 100,
        'amount': double.tryParse(amount.text == '' ? '0' : amount.text)! * 100,
        'name': 'Live to Smile',
        'order_id': orderId,
        'timeout': 600,
        'description': 'Course purchase fee',
        'prefill': {
          'contact': '${mobile.text}',
          'email': '${user!.email}'
        },
        'external': {
          'wallets': ['paytm']
        }
      };
      print(7);
      // DocumentSnapshot doc = await FirebaseFirestore.instance
      //     .collection('settings')
      //     .doc('O0juQP9oPBfxZveBeWzn')
      //     .get();
      // FirebaseFirestore.instance
      //     .collection('settings')
      //     .doc('O0juQP9oPBfxZveBeWzn')
      //     .update({
      //   'studentId': FieldValue.increment(1),
      // });
      // int studentId = doc.get('studentId');
      // studentId++;
      List tuitionFeeList = [];
      int studentId=0;
      if (tuitionFee?.text != '') {
        tuitionFeeList.add({
          'date': Timestamp.now(),
          'amount': double.tryParse(amount.text),
          'modeOfPayment': radioval,
          'paymentId': "",
          'userId': currentUserId
        });
      }

      List paymentList = [];
      paymentList.add({
        'admissionFee': double.tryParse(admissionFee.text),
        'universityFee': double.tryParse(universityFee.text),
        'currentYearTotalFee': double.tryParse(totalFee.text),
        'scholarship': 0,
        'paymentId': "",
        'date': Timestamp.now(),
        'tuitionFee': tuitionFeeList,
        'convocationFee': double.tryParse(convacationFee.text) ?? 0,
      });

      List list = [
        {
          'name': 'Personal Details',
          'completed': false,
        },
        {
          'name': 'Fee Details',
          'completed': false,
        },
        {
          'name': 'Classes',
          'completed': false,
        },
        {
          'name': 'Documents',
          'completed': false,
        },
      ];

      await FirebaseFirestore.instance
          .collection('pendingCandidates')
          .doc(orderId)
          .set({
        'enquiryId': enquiryId[user!.email],
        'form': list,
        'date': DateTime.now(),
        'status': 0,
        'name': firstName.text,
        'lastName': lastName.text,
        'mobile': mobile.text,
        'countryCode': countryCode,
        'phoneCode': phoneCode,
        'email': email.text,
        'dob': selectedDate,
        'place': place.text,
        'educationalDetails': [],
        'address': address.text,
        'gender': radioval2,
        'branchId': 'O0juQP9oPBfxZveBeWzn',
        'userId': currentUserId,
        'currentStatus': 'Registered',
        'scholarship': '',
        'search': setSearchParam(firstName.text + ' ' + mobile.text),
        'photo': imageUrl,
        'studentId': 'LTS' + studentId.toString(),
        'discount': 0.0,
        'dueDate': DateTime.now(),
        'classId': ClassNameToId[classController?.text],
        'inTake': inTakeId,
        'course': widget.courseId,
        'university': universityId[widget.data['university']],
        'documents': data,
        'currentYear': 1,
        "classDoc":ClassNameToId[classController?.text],
        "enquiryDoc":enquiryId[user!.email]??'',
        'courseDuration': widget.data['duration'],
        'feeDetails': paymentList,
        'verified': 0,
        'active': true,
        'emailC':course.text,
        'emailI':intakeCtlr.text,
        'emailN':firstName.text+lastName.text,
      });
      //     .then((value) {
      //   if (enquiryId[currentUserEmail] != null) {
      //     FirebaseFirestore.instance
      //         .collection('enquiry')
      //         .doc(enquiryId[currentUserEmail])
      //         .update({
      //       'status': 1,
      //       'studentId': 'LTS' + studentId.toString(),
      //     });
      //   }
      //
      //   List StudentList = [];
      //   StudentList.add('LTS' + studentId.toString());
      //
      //   FirebaseFirestore.instance
      //       .collection('class')
      //       .doc(ClassNameToId[classController?.text])
      //       .update({
      //     'students': FieldValue.arrayUnion(['LTS' + studentId.toString()]),
      //   });
      // });
      // register_student(course.text,intakeCtlr.text,[email.text],firstName.text+lastName.text);
      try {
        _razorpay?.open(checkoutOptions);
      } catch (e) {
        print('testttttttttttttttt');
        print(e.toString());
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.grey.shade200,
        elevation: 0,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: Icon(
              Icons.arrow_back,
              color: Colors.black,
            )),
        title: Text(
          'Registration Form',
          style: GoogleFonts.lexend(
              fontWeight: FontWeight.w500,
              fontSize: w * 0.04,
              color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: classList.isEmpty?Center(child: CircularProgressIndicator()): SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 15, right: 15, top: 15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              imageUrl == ''
                  ? InkWell(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text("Image"),
                            content: Container(
                              height: MediaQuery.of(context).size.height * 0.15,
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton(
                                    onPressed: () {
                                      pickGellary();
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.03,
                                      width: MediaQuery.of(context).size.width *
                                          0.2,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        color: Colors.blueGrey,
                                      ),
                                      child: Center(
                                        child: Text(
                                          "Gallery",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 18),
                                        ),
                                      ),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () async {
                                      pickFiles();
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.03,
                                      width: MediaQuery.of(context).size.width *
                                          0.2,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        color: Colors.blueGrey,
                                      ),
                                      child: Center(
                                        child: Text("Camera",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 18)),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      child: Container(
                        width: w * 0.5,
                        height: w * 0.5,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white,
                            border: Border.all(color: Color(0xffD8D8D8))),
                        child: Stack(
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                SvgPicture.asset(
                                  'assets/icons/photo.svg',
                                  color: Color(0xffD8D8D8),
                                ),
                                SizedBox(
                                  height: w * 0.02,
                                ),
                                Center(
                                  child: Text(
                                    'Upload photo',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w400,
                                        fontSize: w * 0.03,
                                        color: Color(0xffD8D8D8)),
                                  ),
                                ),
                              ],
                            ),
                            imageStatus == 1
                                ? Center(
                                    child: CircularProgressIndicator(
                                    color: Colors.black,
                                  ))
                                : Container(),
                          ],
                        ),
                      ),
                    )
                  : Container(
                      width: w * 0.5,
                      height: w * 0.5,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Color(0xffD8D8D8)),
                          image: DecorationImage(
                              image: CachedNetworkImageProvider(imageUrl),
                              fit: BoxFit.cover)),
                    ),
              // imageUrl==''? InkWell(
              //   onTap: () {
              //
              //     showDialog(
              //       context: context,
              //       builder: (ctx) => AlertDialog(
              //         title: const Text("Image"),
              //         content: Container(
              //           height: MediaQuery.of(context).size.height*0.15,
              //           child: Column(
              //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //             children: [
              //               TextButton(
              //                 onPressed: () {
              //                   pickGellary();
              //                   Navigator.pop(context);
              //                 },
              //                 child: Container(
              //                   height: MediaQuery.of(context).size.height * 0.03,
              //                   width: MediaQuery.of(context).size.width * 0.2,
              //                   decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),color:Colors.blueGrey,),
              //                   child: Center(
              //                     child: Text(
              //                       "Gallery",
              //                       style: TextStyle( color:Colors.white, fontSize: 18),
              //                     ),
              //                   ),
              //                 ),
              //               ),
              //               TextButton(
              //                 onPressed: () async {
              //                   pickFiles();
              //                   Navigator.pop(context);
              //                 },
              //                 child: Container(
              //                   height: MediaQuery.of(context).size.height * 0.03,
              //                   width: MediaQuery.of(context).size.width * 0.2,
              //                   decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color:Colors.blueGrey,),
              //                   child: Center(
              //                     child: Text("Camera",
              //                         style: TextStyle( color:Colors.white, fontSize: 18)),
              //                   ),
              //                 ),
              //               ),
              //             ],
              //           ),
              //         ),
              //       ),
              //     );
              //   },
              //   child: Container(
              //     height: MediaQuery.of(context).size.height*0.07,
              //     decoration: BoxDecoration(
              //       color: primary,
              //       borderRadius: BorderRadius.circular(8),
              //     ),
              //     child: Center(
              //       child: Text(
              //         'Upload Image',
              //         style: TextStyle(
              //             color: Colors.black, fontSize: 18),
              //       ),
              //     ),
              //   ),
              // ):CachedNetworkImage(imageUrl: imageUrl,),
              SizedBox(
                height: w * .03,
              ),

              Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Color(0xFFE6E6E6),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: w * .028),
                  child: TextFormField(
                    controller: firstName,
                    style: GoogleFonts.poppins(
                        color: Colors.black, fontSize: w * .039),
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      hintText: "First name",
                      hintStyle: GoogleFonts.poppins(
                          color: Colors.black, fontSize: w * .039),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: w * .03,
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Color(0xFFE6E6E6),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: w * .028),
                  child: TextFormField(
                    controller: lastName,
                    style: GoogleFonts.poppins(
                        color: Colors.black, fontSize: w * .039),
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      hintText: "Last name",
                      hintStyle: GoogleFonts.poppins(
                          color: Colors.black, fontSize: w * .039),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: w * .03,
              ),

              Container(
                // height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Color(0xFFE6E6E6),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: w * .028),
                  child: TextFormField(
                    controller: email,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    validator: (email) {
                      if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w]{2,4}')
                          .hasMatch(email!)) {
                        return "Email not valid";
                      } else if (student != null && student.docs.isNotEmpty) {
                        return "Email already registered with us";
                      } else {
                        return null;
                      }
                    },
                    onChanged: (text) {
                      checkEmail(text);
                    },
                    style: GoogleFonts.poppins(
                        color: Colors.black, fontSize: w * .039),
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      hintText: "Email",
                      hintStyle: GoogleFonts.poppins(
                          color: Colors.black, fontSize: w * .039),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: w * .03,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Male'),
                  SizedBox(
                    width: 5,
                  ),
                  Radio(
                    activeColor: Colors.yellow,
                    fillColor: MaterialStateProperty.all(Colors.black),
                    overlayColor: MaterialStateProperty.all(Colors.grey[200]),
                    focusColor: Colors.green,
                    value: male,
                    onChanged: (bool? value) {
                      setState(() {
                        value = true;
                        male = value!;
                        other = false;
                        female = false;
                        radioval2 = 'Male';
                        print(radioval2);
                        radioSelected2 = value!;
                      });
                    },
                    groupValue: radioSelected2,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text('Female'),
                  SizedBox(
                    width: 5,
                  ),
                  Radio(
                    activeColor: Colors.yellow,
                    fillColor: MaterialStateProperty.all(Colors.black),
                    overlayColor: MaterialStateProperty.all(Colors.grey[200]),
                    focusColor: Colors.green,
                    value: female,
                    onChanged: (bool? value) {
                      value = true;
                      setState(() {
                        radioval2 = 'Female';
                        print(radioval2);
                        female = value!;
                        male = false;
                        other = false;
                        radioSelected2 = value;
                      });
                    },
                    groupValue: radioSelected2,
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text('other'),
                  SizedBox(
                    width: 5,
                  ),
                  Radio(
                    activeColor: Colors.yellow,
                    fillColor: MaterialStateProperty.all(Colors.black),
                    overlayColor: MaterialStateProperty.all(Colors.grey[200]),
                    focusColor: Colors.green,
                    value: other,
                    onChanged: (bool? value) {
                      value = true;
                      setState(() {
                        radioval2 = 'Other';
                        print(radioval2);
                        other = value!;
                        male = false;
                        female = false;
                        radioSelected2 = value;
                      });
                    },
                    groupValue: radioSelected2,
                  ),
                ],
              ),

              SizedBox(
                height: w * .03,
              ),

              InkWell(
                onTap: () {
                  selectDate(context);
                },
                child: Container(
                  height: h * .06,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: Color(0xFFE6E6E6),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: w * .47,
                        child: Padding(
                          padding: EdgeInsets.only(left: w * .028),
                          child: Text(
                            selectedDate.millisecond != currentDate.millisecond
                                ? '${selectedDate.day} | ${selectedDate.month} | ${selectedDate.year}'
                                : 'Date | Month | Year',
                            style: GoogleFonts.lexend(
                              fontWeight: FontWeight.w500,
                              fontSize: w * .034,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: w * .03,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Color(0xFFE6E6E6),
                  ),
                ),
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.only(left: w * .028),
                    child: IntlPhoneField(
                      controller: mobile,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        // focusedBorder: InputBorder.none,
                        hintText: "Phone number",
                        hintStyle: GoogleFonts.poppins(
                            color: Color(0xffBBC5CD), fontSize: w * .039),
                      ),
                      initialCountryCode: countryCode,
                      onChanged: (phone) {
                        phoneCode = phone.countryCode;
                        countryCode = phone.countryISOCode;
                        log(countryCode + '****');
                        log(phoneCode + '****');
                        setState(() {});
                      },
                    ),
                    // TextFormField(
                    //   controller: mobile,
                    //   style: GoogleFonts.poppins(
                    //       color: Colors.black,
                    //       fontSize: w*.039),
                    //   keyboardType: TextInputType.number,
                    //   decoration:   InputDecoration(
                    //     border: InputBorder.none,
                    //     focusedBorder: InputBorder.none,
                    //     hintText: "Mobile number",
                    //     hintStyle: GoogleFonts.poppins(
                    //         color:Colors.black,
                    //         fontSize: w*.039),
                    //
                    //
                    //   ),
                    // ),
                  ),
                ),
              ),
              SizedBox(
                height: w * .03,
              ),
              Container(
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Color(0xFFE6E6E6),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: w * .028),
                  child: TextFormField(
                    controller: address,
                    style: GoogleFonts.poppins(
                        color: Colors.black, fontSize: w * .039),
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      hintText: "Address",
                      hintStyle: GoogleFonts.poppins(
                          color: Colors.black, fontSize: w * .039),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: w * .03,
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: Color(0xFFE6E6E6),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(left: w * .028),
                  child: TextFormField(
                    controller: place,
                    style: GoogleFonts.poppins(
                        color: Colors.black, fontSize: w * .039),
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      hintText: "Place",
                      hintStyle: GoogleFonts.poppins(
                          color: Colors.black, fontSize: w * .039),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: w * .05,
              ),
              InkWell(
                onTap: () {
                  showUniversity = !showUniversity;

                  setState(() {});
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'University',
                      style: GoogleFonts.poppins(
                        color: Colors.grey,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.black,
                    )
                  ],
                ),
              ),

              showUniversity == true
                  ? Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: university,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "University",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: course,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Course",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),

                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: const Color(0xffFFFFFF),
                              border: Border.all(
                                  color: const Color(0xffEAEAEA), width: 2),
                            ),
                            child: CustomDropdown.search(
                              controller: intakeCtlr,
                              items: intakes,
                              hintText: "Select Intake",
                              // suggestions: intakes,
                              // hint: 'Choose the In takes',
                              // searchStyle: TextStyle(
                              //   fontSize: 15,
                              //   color: Colors.black,
                              // ),
                              // maxSuggestionsInViewPort: 3,
                              // suggestionState: SuggestionState.enabled,
                              // searchInputDecoration: InputDecoration(
                              //   focusedBorder: OutlineInputBorder(
                              //     borderSide: BorderSide(
                              //       color: Colors.black,
                              //     ),
                              //   ),
                              // ),
                              onChanged: (x) {
                                inTakeId = intakesId[x];

                                print(inTakeId);
                                setState(() {});
                              },
                            ),
                          ),

                          // Container(
                          //   decoration: BoxDecoration(
                          //     borderRadius: BorderRadius.circular(10),
                          //     color: const Color(0xffFFFFFF),
                          //     border: Border.all(
                          //         color: const Color(0xffEAEAEA), width: 2),
                          //   ),
                          //   child: SearchField(
                          //     controller: intakeCtlr,
                          //     suggestions: intakes,
                          //     hint: 'Choose the In takes',
                          //     searchStyle: TextStyle(
                          //       fontSize: 15,
                          //       color: Colors.black,
                          //     ),
                          //     maxSuggestionsInViewPort: 3,
                          //     suggestionState: SuggestionState.enabled,
                          //     searchInputDecoration: InputDecoration(
                          //       focusedBorder: OutlineInputBorder(
                          //         borderSide: BorderSide(
                          //           color: Colors.black,
                          //         ),
                          //       ),
                          //     ),
                          //     onTap: (x) {
                          //       inTakeId = intakesId[x];
                          //
                          //       print(inTakeId);
                          //       setState(() {});
                          //     },
                          //   ),
                          // ),
                          SizedBox(
                            height: w * .03,
                          ),
                          classList.isNotEmpty?
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: const Color(0xffFFFFFF),
                              border: Border.all(
                                  color: const Color(0xffEAEAEA), width: 2),
                            ),
                            child: CustomDropdown.search(
                              controller: classController,
                              items: classList,
                              hintText: "Select Batch",
                              onChanged: (x) {
                                setState(() {});
                              },
                            ),
                            // child: SearchField(
                            //   controller: classController,
                            //   suggestions: classList,
                            //   hint: 'Choose the Class',
                            //   searchStyle: TextStyle(
                            //     fontSize: 15,
                            //     color: Colors.black,
                            //   ),
                            //   maxSuggestionsInViewPort: 3,
                            //   suggestionState: SuggestionState.enabled,
                            //   searchInputDecoration: InputDecoration(
                            //     focusedBorder: OutlineInputBorder(
                            //       borderSide: BorderSide(
                            //         color: Colors.black,
                            //       ),
                            //     ),
                            //   ),
                            //   onTap: (x) {
                            //     setState(() {});
                            //   },
                            // ),
                          )
                          :Container(
                            height: 50,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: const Color(0xffFFFFFF),
                              border: Border.all(
                                  color: const Color(0xffEAEAEA), width: 2),
                            ),
                            child: Center(
                                child: Text('No batch found for the selected course',
                                style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),)
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                        ],
                      ),
                    )
                  : Container(
                      height: w * .02,
                    ),

              InkWell(
                onTap: () {
                  document = !document;

                  setState(() {});
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Documents',
                      style: GoogleFonts.poppins(
                        color: Colors.grey,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.black,
                    )
                  ],
                ),
              ),

              document == true
                  ? Container(
                      width: w,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          // SizedBox(
                          //   child:DataTable(
                          //     horizontalMargin: 30,
                          //     columnSpacing: 30,
                          //     columns: [
                          //       DataColumn(
                          //         label: Text(
                          //           "Document Name",
                          //           style: TextStyle(
                          //               fontWeight: FontWeight.bold, fontSize: 15),
                          //         ),
                          //       ),
                          //       DataColumn(
                          //         label:  Text(
                          //           "upload",
                          //           style: TextStyle(
                          //               fontWeight: FontWeight.bold, fontSize: 15),
                          //         ),
                          //       ),
                          //
                          //     ],
                          //     rows: List.generate(
                          //       uploadDocument.length,
                          //           (index) {
                          //         var docName = uploadDocument[index];
                          //         print(data.keys.toList());
                          //
                          //
                          //         return DataRow(
                          //           color: index.isOdd
                          //               ? MaterialStateProperty.all(Colors
                          //               .blueGrey.shade50
                          //               .withOpacity(0.7))
                          //               : MaterialStateProperty.all(
                          //               Colors.blueGrey.shade50),
                          //           cells: [
                          //             DataCell(SelectableText(
                          //               docName,
                          //               style: GoogleFonts.poppins(
                          //                 color: Colors.black,
                          //                 fontSize: 11,
                          //                 fontWeight: FontWeight.bold,
                          //               ),
                          //             )),
                          //             DataCell( Padding(
                          //               padding: EdgeInsetsDirectional.fromSTEB(0, 0, 8, 0),
                          //               child:
                          //               InkWell(
                          //                 onTap: () async {
                          //                   showUploadMessage(context, 'please upload ${docName}');
                          //                     selectFile(docName.toUpperCase());
                          //                     setState(() {
                          //
                          //                     });
                          //
                          //                 },
                          //                 child: Container(
                          //                   height: 40,
                          //                   width: 100,
                          //                   decoration: BoxDecoration(
                          //                     borderRadius: BorderRadius.circular(10),
                          //                     color: data.keys.toList().contains(docName.toString().toUpperCase())? Color(0xFF4B39EF):Colors.teal,
                          //                   ),
                          //                   child: Center(
                          //                     child: Text(
                          //                         data.keys.toList().contains(docName.toString().toUpperCase())?'edit':'Upload'  ,
                          //                     style: GoogleFonts.poppins( color: Colors.white,
                          //                 fontSize: 12,
                          //                 fontWeight: FontWeight.bold,),),
                          //                   ),
                          //                 ),
                          //               ),
                          //
                          //             )),
                          //
                          //           ],
                          //         );
                          //       },
                          //     ),
                          //   ),
                          // ),

                          SizedBox(
                            child: GridView.builder(
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                      childAspectRatio: 1,
                                      crossAxisCount: 3,
                                      crossAxisSpacing: 5,
                                      mainAxisSpacing: 10),
                              itemCount: uploadDocument.length,
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  onTap: () {
                                    selectFile(
                                        uploadDocument[index].toUpperCase());
                                    setState(() {});
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Colors.white,
                                        image: data.keys.toList().contains(
                                                uploadDocument[index]
                                                    .toString()
                                                    .toUpperCase())
                                            ? DecorationImage(
                                                image:
                                                    CachedNetworkImageProvider(
                                                        data[uploadDocument[
                                                                index]
                                                            .toUpperCase()]))
                                            : null,
                                        border: Border.all(
                                            color: Color(0xffD8D8D8))),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: data.keys.toList().contains(
                                                uploadDocument[index]
                                                    .toString()
                                                    .toUpperCase())
                                            ? Colors.black.withOpacity(0.5)
                                            : Colors.black.withOpacity(0),
                                      ),
                                      child: Stack(
                                        children: [
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.stretch,
                                            children: [
                                              SvgPicture.asset(
                                                'assets/icons/photo.svg',
                                                color: Color(0xffD8D8D8),
                                              ),
                                              SizedBox(
                                                height: w * 0.02,
                                              ),
                                              Center(
                                                child: Text(
                                                  uploadDocument[index],
                                                  style: GoogleFonts.lexend(
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize: w * 0.03,
                                                      color: data.keys
                                                              .toList()
                                                              .contains(
                                                                  uploadDocument[
                                                                          index]
                                                                      .toString()
                                                                      .toUpperCase())
                                                          ? Colors.white
                                                          : Colors
                                                              .grey.shade500),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          ),
                                          selected ==
                                                  '${uploadDocument[index].toString().toUpperCase()}0'
                                              ? Center(
                                                  child:
                                                      CircularProgressIndicator(
                                                  color: Colors.black,
                                                ))
                                              : Container()
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),

                          SizedBox(
                            height: w * .03,
                          ),
                        ],
                      ),
                    )
                  : Container(
                      height: w * .02,
                    ),

              InkWell(
                onTap: () {
                  print(feeDetails);
                  feeDetails = !feeDetails;

                  setState(() {});
                  print(feeDetails);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Fee Details',
                      style: GoogleFonts.poppins(
                        color: Colors.grey,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.black,
                    )
                  ],
                ),
              ),
              feeDetails == true
                  ? Container(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Admission Fees'),
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: admissionFee,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Admission Fees",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                          Text('University Fees'),
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: universityFee,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "University Fees",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                          Text('Convocation Fees'),
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: convacationFee,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Convocation Fees",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                          Text(
                              'Tuition Fees  ( ₹${tuision.toStringAsFixed(2)} )'),
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: tuitionFee,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.numberWithOptions(),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Tuition Fees",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(w * .01),
                            child: Text(
                              'Minimum ₹${(tuision * 50 / 100).toStringAsFixed(2)} (50% of tuition fee) will pay',
                              style: GoogleFonts.lexend(fontSize: 12),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                          Text('Total Fees'),
                          Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Color(0xFFE6E6E6),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(left: w * .028),
                              child: TextFormField(
                                controller: totalFee,
                                enableInteractiveSelection: false,
                                enabled: false,
                                style: GoogleFonts.poppins(
                                    color: Colors.black, fontSize: w * .039),
                                keyboardType: TextInputType.name,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  hintText: "Total Fees",
                                  hintStyle: GoogleFonts.poppins(
                                      color: Colors.black, fontSize: w * .039),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: w * .03,
                          ),
                        ],
                      ),
                    )
                  : Container(
                      height: w * .03,
                    ),

              RoundedLoadingButton(
                successIcon: Icons.check,
                failedIcon: Icons.close,
                valueColor: Colors.black,
                color: Color(0xffFEDE00),
                child: Text('Register and Pay\n₹${(total.toStringAsFixed(2))}',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.lexend(
                        color: Colors.black, fontWeight: FontWeight.bold)),
                controller: _btnController1,
                onPressed: () async {
                  if (firstName.text != '' &&
                      lastName.text != '' &&
                      mobile.text != '' &&
                      email.text != '' &&
                      imageUrl != '' &&
                      selectedDate != '' &&
                      address?.text != '' &&
                      place?.text != '' &&
                      inTakeId != '' &&
                      admissionFee?.text != '' &&
                      universityFee != '' &&
                      radioval2 != '') {
                    await addPayments();
                    _btnController1.reset();
                  } else {
                    print(dob);
                    _btnController1.reset();

                    firstName.text == ''
                        ? Fluttertoast.showToast(
                            msg: 'Please Enter First Name',
                            backgroundColor: Colors.red,
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER)
                        : lastName.text == ''
                            ? Fluttertoast.showToast(
                                msg: 'Please Enter Last Name',
                                backgroundColor: Colors.red,
                                toastLength: Toast.LENGTH_LONG,
                                gravity: ToastGravity.CENTER)
                            : mobile.text == ''
                                ? Fluttertoast.showToast(
                                    msg: 'Please Enter Mobile Number',
                                    backgroundColor: Colors.red,
                                    toastLength: Toast.LENGTH_LONG,
                                    gravity: ToastGravity.CENTER)
                                : email.text == ''
                                    ? Fluttertoast.showToast(
                                        msg: 'Please Enter Email',
                                        backgroundColor: Colors.red,
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER)
                                    : course.text == ''
                                        ? Fluttertoast.showToast(
                                            msg: 'Please Select Class',
                                            backgroundColor: Colors.red,
                                            toastLength: Toast.LENGTH_LONG,
                                            gravity: ToastGravity.CENTER)
                                        : inTakeId == ''
                                            ? Fluttertoast.showToast(
                                                msg: 'Please Select Intake',
                                                backgroundColor: Colors.red,
                                                toastLength: Toast.LENGTH_LONG,
                                                gravity: ToastGravity.CENTER)
                                            : selectedDate == null
                                                ? Fluttertoast.showToast(
                                                    msg:
                                                        'Please Select Date of Birth',
                                                    backgroundColor: Colors.red,
                                                    toastLength:
                                                        Toast.LENGTH_LONG,
                                                    gravity:
                                                        ToastGravity.CENTER)
                                                : address.text == ''
                                                    ? Fluttertoast.showToast(
                                                        msg:
                                                            'Please Enter Address',
                                                        backgroundColor:
                                                            Colors.red,
                                                        toastLength:
                                                            Toast.LENGTH_LONG,
                                                        gravity:
                                                            ToastGravity.CENTER)
                                                    : place.text == ''
                                                        ? Fluttertoast.showToast(
                                                            msg:
                                                                'Please Enter Place',
                                                            backgroundColor:
                                                                Colors.red,
                                                            toastLength: Toast
                                                                .LENGTH_LONG,
                                                            gravity:
                                                                ToastGravity
                                                                    .CENTER)
                                                        : radioval2 == ''
                                                            ? Fluttertoast.showToast(
                                                                msg:
                                                                    'Please Choose Gender',
                                                                backgroundColor:
                                                                    Colors.red,
                                                                toastLength: Toast
                                                                    .LENGTH_LONG,
                                                                gravity: ToastGravity
                                                                    .CENTER)
                                                            : Fluttertoast.showToast(
                                                                msg:
                                                                    'Please Upload Image',
                                                                backgroundColor:
                                                                    Colors.red,
                                                                toastLength: Toast.LENGTH_LONG,
                                                                gravity: ToastGravity.CENTER);
                  }
                },
              ),
              Container(
                height: w * .03,
              ),
            ],
          ),
        ),
      ),
    );
  }

  addPayments() {
    return showModalBottomSheet(
        backgroundColor: Colors.transparent,
        context: context,
        isScrollControlled: true,
        builder: (context) => StatefulBuilder(
              builder: (context, setState) {
                return Padding(
                  padding: MediaQuery.of(context).viewInsets,
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.3,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          topRight: Radius.circular(50),
                        )),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(15),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    'Pay course fee and get admission',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    margin: EdgeInsets.only(right: 10),
                                    height: 20,
                                    width: 20,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.red),
                                    child: Center(
                                        child: Text(
                                      "X",
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                          fontSize: 12),
                                    )),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(child: SizedBox()),
                          Container(
                            width: double.infinity,
                            child: Center(
                              child: TextFormField(
                                controller: amount,
                                keyboardType: TextInputType.numberWithOptions(),
                                onChanged: (value) {
                                  setState(() {});
                                },
                                maxLines: 1,
                                style: GoogleFonts.lexend(
                                    textStyle: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black)),
                                decoration: InputDecoration(
                                  fillColor: Colors.green.withOpacity(0.3),
                                  iconColor: Colors.black,
                                  hintStyle: GoogleFonts.lexend(
                                      textStyle: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.normal,
                                          color:
                                              Colors.black.withOpacity(0.250))),
                                  hintText: 'Enter amount here',
                                  prefixIcon: Icon(Icons.currency_rupee),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(9),
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              42, 172, 146, 0.0))),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(9),
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              42, 172, 146, 0.0))),
                                  filled: true,
                                  // border: OutlineInputBorder(
                                  //     borderRadius: BorderRadius.circular(20),
                                  //     borderSide: BorderSide(color: Colors.yellow)),
                                ),
                              ),
                            ),
                          ),
                          Expanded(child: SizedBox()),
                          RoundedLoadingButton(
                            successIcon: Icons.check,
                            failedIcon: Icons.close,
                            valueColor: Colors.black,
                            color: Color(0xffFEDE00),
                            child: Text(
                                'Pay Now\n₹${amount.text == '' ? '0' : amount.text}',
                                textAlign: TextAlign.center,
                                style: GoogleFonts.lexend(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold)),
                            controller: _btnController2,
                            onPressed: () async {
                              FocusManager.instance.primaryFocus?.unfocus();
                              if (amount.text != '') {
                                if (double.tryParse(amount.text == ''
                                        ? '0'
                                        : amount.text)! >=
                                    1000) {
                                  await generate_ODID();

                                  Navigator.pop(context);
                                } else {
                                  // showUploadMessage(context, 'Minimum amount is ₹1000');
                                  Fluttertoast.showToast(
                                      msg: "Minimum amount is ₹1000",
                                      backgroundColor: Colors.red,
                                      toastLength: Toast.LENGTH_SHORT);
                                  _btnController2.reset();
                                }
                              } else {
                                //showUploadMessage(context, 'Please enter fee amount');
                                Fluttertoast.showToast(
                                    msg: "Please enter fee amount",
                                    backgroundColor: Colors.red,
                                    toastLength: Toast.LENGTH_SHORT);
                                _btnController2.reset();
                              }
                            },
                          ),
                          Expanded(child: SizedBox()),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ));
  }
}
