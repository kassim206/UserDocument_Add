import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../feature/Splash/screen/splash_screen.dart';
import '../../splash/Splash.dart';

var userData;
//var currentUserName ;
//var currentUserImage ;
// var currentUserEmail ;
//var currentUserPhone ;
// var CurrentUserClassId;
// var CurrentUserAddress;
// var CurrentUserDob;
// var CurrentUserJoined;
// var CurrentUserPlace;
// var CurrentUserYear;
// var CurrentUserCourse ;
// var CurrentUserUniversity ;
int currentUserStatus=0;

// int verified = 0;
var currentUserId;

final authStreamProvider =
    StreamProvider((ref) => FirebaseAuth.instance.authStateChanges());
// final currentUserImageProvider = StateProvider((ref) => '');
// final currentUserPhoneProvider = StateProvider((ref) => '');
// final currentUserNameProvider = StateProvider((ref) => '');

class Routing extends ConsumerWidget {
  const Routing({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStreamProvider);
    return authState.when(data: (userData) {
      final currentUserId = userData?.uid;
      print(currentUserId);
      print('======================');
      return Splash();
    }, error: (error, stackTrace) {
      return const Center(child: Text('Something Went Wrong !'));
    }, loading: () {
      return const Center(child: CircularProgressIndicator());
    });
  }
}
