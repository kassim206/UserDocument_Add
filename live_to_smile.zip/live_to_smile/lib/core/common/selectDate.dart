import 'package:flutter/material.dart';


selectDate(context, DateTime selectedDate) async {
  final DateTime? selected = await showDatePicker(
    context: context,
    initialDate: selectedDate,
    firstDate: DateTime(1950),
    lastDate: DateTime(2050),
  );
  if (selected != null && selected != selectedDate) {
    selectedDate = selected;
    return selectedDate;
  }
}