import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

showSnackbar(String msg, BuildContext context) {
  final snackBar = SnackBar(
    content: Text(msg),
    backgroundColor: Colors.black,
    behavior: SnackBarBehavior.floating,
    elevation: 50,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}
