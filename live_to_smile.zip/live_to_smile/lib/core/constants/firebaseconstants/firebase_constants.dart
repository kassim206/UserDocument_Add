

class FirebaseConstants{
  static const userCollection = "users";
  static const settingsCollection = "settings";
  static const enquiryCollection = "enquiry";
  static const notificationsCollection = "notifications";
  static const candidatesCollection = "candidates";
  static const classCollection = "class";
  static const chatCollection = "chat";
  static const sessionsCollection = "sessions";
  // static const registerFormCollection = "";

}
