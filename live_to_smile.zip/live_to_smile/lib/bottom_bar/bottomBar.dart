import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/feature/AnnounceNotification/screens/announceMain.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:live_to_smile/profile/profile.dart';
import '../core/routing/routing.dart';
import '../feature/classRoom/screen/class_screen.dart';
import '../feature/homepage/screen/home_page.dart';

var h;
var w;

Color primary = Color(0xffFFEC6E);
Color secondary = Color(0xffB4B4B4);
Color white = Color(0xffffffff);
Color back = Color(0xffF4F4F4);
Color darkT = Color(0xff898989);
//String studentId = '';

// final studentIdProvider = StateProvider((ref) => '');

Map currentCourse = {};

Map<String, dynamic> CourseNameToId = {};
Map<String, dynamic> CourseIdToName = {};
Map<String, dynamic> CourseIdToType = {};
Map<String, dynamic> CourseIdToDuration = {};

Map<String, dynamic> ClassNameToId = {};
Map<String, dynamic> ClassIdToName = {};
Map<String, dynamic> classMap = {};
List<String> classes = [];
List<String> tutor = [];
Map<String, dynamic> tutorMap = {};
List tutors = [];

Map<String, dynamic> InTakeNameToId = {};
Map<String, dynamic> InTakeIdToName = {};
List<String> inTakes = ['Select Intakes'];
List<String> universityCourses = ['Select University'];

Map<String, dynamic> UniversityNameToId = {};
Map<String, dynamic> UniversityIdToName = {};
List<String> universityList = [];

class BottomBar extends ConsumerStatefulWidget {
  final bIndex;

  const BottomBar({
    key,
    this.bIndex,
  }) : super(key: key);

  @override
  ConsumerState<BottomBar> createState() => _BottomBarState();
}

class _BottomBarState extends ConsumerState<BottomBar> {
  int selectedIndex = 0;
  String? categoryId;
  List courseList = [];

  UsersModel? user;

  Map<String, dynamic> courseName = {};
  // getClasses() {
  //   FirebaseFirestore.instance.collection('class').snapshots().listen((event) {
  //     classes = [];
  //     for (var data in event.docs) {
  //       classMap[data.id] = data.data();
  //       ClassNameToId[data.get('name')] = data.id;
  //       ClassIdToName[data.id] = data.get('name');
  //       if (data.get('available') == true) {
  //         classes.add(data['name']);
  //       }
  //     }
  //   });
  // }

  getTutor() {
    FirebaseFirestore.instance
        .collection('admin_users')
        .snapshots()
        .listen((event) {
      classes = [];
      for (var data in event.docs) {
        tutorMap[data.id] = data.data();
        tutor.add(data['display_name']);
      }
    });
  }

  // getUniversity() {
  //   FirebaseFirestore.instance
  //       .collection('university')
  //       .snapshots()
  //       .listen((event) {
  //     universityList.clear();
  //     for (var university in event.docs) {
  //       universityList.add(university['name']);
  //       UniversityNameToId[university['name']] = university.id;
  //       UniversityIdToName[university.id] = university.get('name');
  //     }
  //     if (mounted) {
  //       setState(() {});
  //     }
  //   });
  // }

  getSelectedInTake() {
    FirebaseFirestore.instance
        .collection("intakes")
        .where('available', isEqualTo: true)
        .snapshots()
        .listen((event) {
      inTakes = [];
      for (DocumentSnapshot doc in event.docs) {
        InTakeNameToId[doc.get('intakeName')] = doc.id;
        InTakeIdToName[doc.id] = doc.get('intakeName');
        inTakes.add(doc.get('intakeName'));
        // InTakeNameToId[(dateTimeFormat('MMMM yyyy', doc['intake'].toDate())).toString()]=doc.id;
        // InTakeIdToName[doc.id]=(dateTimeFormat('MMMM yyyy', doc['intake'].toDate())).toString();
        // inTakes.add((dateTimeFormat('MMMM yyyy', doc['intake'].toDate())).toString());
        // print(courses);
      }
    });
  }

  getUser() async {
    //
    // final currentUserImage = ref.read(currentUserImageProvider.notifier);
    // final currentUserName=ref.read(currentUserNameProvider.notifier);
    DocumentSnapshot data = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUserId)
        .get();

    user = UsersModel.fromMap(data.data() as Map<String,dynamic>);

    print("2222222222222222233333333333333334444444444444 $currentUserId");
    print("3333333333333333333333333333333 ${user!.email}");
    // currentUserName.state = data.get('display_name');
    // currentUserImage.state = data.get('photo_url');
    // currentUserEmail = data.get('email');

    getStudent();
    ref.read(userProvider.notifier).update(
        (state) => UsersModel.fromMap(data.data() as Map<String, dynamic>));


    if (mounted) {
      setState(() {});
    }

    // FirebaseFirestore.instance.collection('users')
    //     .doc(currentUserId).snapshots().listen((event) async {
    //   currentUserName=event.get('display_name');
    //   currentUserImage=event.get('photo_url');
    //   currentUserEmail=event.get('email');
    //
    //  await Future.delayed(Duration(milliseconds: 50), () {
    //
    //   });
    //   getStudent();
    //    if(mounted){
    //      setState(() {
    //
    //      });
    //    }
    //
    //
    // });
  }

  // getStudentsNotifications() async {
  //   // Timestamp.now().microsecondsSinceEpoch
  //
  //   while (user!.uid == "") {
  //     await Future.delayed(Duration(seconds: 1));
  //   }
  //
  //   FirebaseFirestore.instance
  //       .collection('notifications')
  //       .where('type', isNotEqualTo: 'Tutors')
  //       .snapshots()
  //       .listen((event) {
  //     notifications = [];
  //     var data = event.docs;
  //     data.sort((a, b) => b['date']
  //         .microsecondsSinceEpoch
  //         .compareTo(a['date'].microsecondsSinceEpoch));
  //
  //     for (dynamic item in data) {
  //       List ids = item['list'];
  //       if (ids.contains(user!.uid)) {
  //         notifications.add(item);
  //       }
  //     }
  //
  //     if (mounted) {
  //       setState(() {});
  //     }
  //   });
  // }

  // getAllCourses() {
  //   FirebaseFirestore.instance.collection('course').snapshots().listen((event) {
  //     for (var item in event.docs) {
  //       CourseNameToId[item.get('name')] = item.id;
  //       CourseIdToName[item.id] = item.get('name');
  //       CourseIdToType[item.id] = item.get('courseType');
  //     }
  //   });
  // }

  late StreamSubscription a;

  // getCourses() {
  //   FirebaseFirestore.instance
  //       .collection('university')
  //       .snapshots()
  //       .listen((event) {
  //     for (DocumentSnapshot data in event.docs) {
  //       if (data.get('courseList').length != 0) {
  //         for (var doc in data.get('courseList')) {
  //           courseList.add({
  //             'university': data['name'],
  //             'available': doc['available'],
  //             'courseId': doc['courseId'],
  //             'duration': doc['duration'],
  //             'totalFee': doc['totalFee'],
  //             'feeList': doc['feeList'],
  //             'eligibility': doc['eligibility'],
  //           });
  //         }
  //       }
  //     }
  //     if (mounted) {
  //       setState(() {});
  //     }
  //   });
  // }

  getCourseName() {
    FirebaseFirestore.instance.collection('course').snapshots().listen((event) {
      for (DocumentSnapshot doc in event.docs) {
        courseName[doc.id] = doc.get('name');
      }
    });
  }

  getStudent() async {
    // final student = ref.read(studentIdProvider.notifier);
    // final currentUserImage = ref.read(currentUserImageProvider.notifier);
    // final currentUserName = ref.read(currentUserNameProvider.notifier);
    // final currentUserPhone = ref.read(currentUserPhoneProvider.notifier);

    a = FirebaseFirestore.instance
        .collection('candidates')
        .where('email', isEqualTo: user!.email)
        .where('status', isEqualTo: 0)
        .snapshots()
        .listen((event) async {
      try {
        List datas = event.docs;
        if (event.docs.isNotEmpty && datas.length != 0) {
          candidatesModel = CandidatesModel.fromMap(event.docs[0].data());

          //
          // currentUserName.state = '${event.docs[0]['name']} ${event.docs[0]['lastName']}';
          // student.state = event.docs[0]['studentId'];
          setState(() {
            studentId = event.docs[0]['studentId'];
            // CurrentUserClassId = event.docs[0]['classId'];
            // CurrentUserAddress = event.docs[0]['address'];
            // CurrentUserDob = event.docs[0]['dob'];
            // CurrentUserJoined = event.docs[0]['date'];
            // CurrentUserPlace = event.docs[0]['place'];
            // CurrentUserYear = event.docs[0]['currentYear'];
            // CurrentUserCourse = event.docs[0]['course'];
            // CurrentUserUniversity = event.docs[0]['university'];
            // currentUserImage.state = event.docs[0]['photo'];
            // currentUserPhone.state= event.docs[0]['mobile'];
            // currentUserStatus = int.parse(event.docs[0]['verified']);
          });
        } else {}
      } catch (e) {}

      if (mounted) {
        setState(() {});
      }
    });
  }

  bool _isLoading = true;
  @override
  void initState() {
    //print('######################%%%%%%%%%%%${ref.read(userProvider)!.email} ');
    user = ref.read(userProvider);
    getUser();
    // getUniversity();
    // getCourses();
    getCourseName();
    // getAllCourses();
    // getClasses();
    getTutor();
    // getStudentsNotifications();
    selectedIndex = widget.bIndex ?? 0;
    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        _isLoading = false;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    a.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider);
    // //final student = ref.watch(studentIdProvider);
    // final currentUserName = ref.read(currentUserNameProvider.notifier);

    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return _isLoading
        ? Scaffold(
            body: Center(
                child: CircularProgressIndicator(
              color: primary,
            )),
          )
        :
        // (studentId!=''&&studentId!=null&&verified==1)?
        Scaffold(
            backgroundColor: back,
            body: (user == null ||
                    user.display_name == '' ||
                    user.display_name == 'null')
                ? Center(child: CircularProgressIndicator())
                : Stack(
                    children: [
                      selectedIndex == 0
                          ? HomePage()
                          : selectedIndex == 1
                              ? classScreen()
                              : selectedIndex == 2
                                  ? AnnounceMain()
                                  : Profile(),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: EdgeInsets.only(bottom: w * 0.05),
                          child: Container(
                            height: w * 0.17,
                            width: w * 0.9,
                            decoration: BoxDecoration(
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(w * 0.2),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.shade400,
                                  offset: const Offset(
                                    0.0,
                                    3.0,
                                  ),
                                  blurRadius: 20.0,
                                  spreadRadius: -2.0,
                                ), //BoxShadow
                                //BoxShadow
                              ],
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(
                                right: w * 0.01,
                                left: w * 0.01,
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Bounce(
                                        duration: Duration(milliseconds: 110),
                                        onPressed: () {
                                          setState(() {
                                            selectedIndex = 0;
                                          });
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                            SvgPicture.asset(
                                              selectedIndex == 0
                                                  ? 'assets/icons/Vector.svg'
                                                  : 'assets/icons/home.svg',
                                              height: w * 0.06,
                                              color: selectedIndex == 0
                                                  ? primary
                                                  : secondary,
                                            ),
                                            Expanded(child: SizedBox()),
                                            Center(
                                              child: Text(
                                                'Featured',
                                                style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w * 0.025,
                                                  color: selectedIndex == 0
                                                      ? primary
                                                      : secondary,
                                                ),
                                              ),
                                            ),
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                          ],
                                        )),
                                  ),
                                  Expanded(
                                    child: Bounce(
                                        duration: Duration(milliseconds: 110),
                                        onPressed: () {
                                          try {
                                            List classes = upComing;
                                            nextClass = upComing.length == 0
                                                ? completedClass[0]
                                                : upComing[0];
                                          } catch (e) {}
                                          setState(() {
                                            selectedIndex = 1;
                                          });
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                            SvgPicture.asset(
                                              selectedIndex == 1
                                                  ? 'assets/icons/classroom2.svg'
                                                  : 'assets/icons/classroom.svg',
                                              height: w * 0.06,
                                              color: selectedIndex == 1
                                                  ? primary
                                                  : secondary,
                                            ),
                                            Expanded(child: SizedBox()),
                                            Center(
                                              child: Text(
                                                'Classroom',
                                                style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w * 0.025,
                                                  color: selectedIndex == 1
                                                      ? primary
                                                      : secondary,
                                                ),
                                              ),
                                            ),
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                          ],
                                        )),
                                  ),
                                  Expanded(
                                    child: Bounce(
                                        duration: Duration(milliseconds: 110),
                                        onPressed: () {
                                          setState(() {
                                            selectedIndex = 2;
                                          });
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                            SvgPicture.asset(
                                              selectedIndex == 2
                                                  ? 'assets/icons/activeNoti.svg'
                                                  : 'assets/icons/announce.svg',
                                              height: w * 0.06,
                                              color: selectedIndex == 2
                                                  ? primary
                                                  : secondary,
                                            ),
                                            Expanded(child: SizedBox()),
                                            Center(
                                              child: Text(
                                                'Announce',
                                                style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w * 0.025,
                                                  color: selectedIndex == 2
                                                      ? primary
                                                      : secondary,
                                                ),
                                              ),
                                            ),
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                          ],
                                        )),
                                  ),
                                  Expanded(
                                    child: Bounce(
                                        duration: Duration(milliseconds: 110),
                                        onPressed: () {
                                          setState(() {
                                            selectedIndex = 3;
                                          });
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                            SvgPicture.asset(
                                              selectedIndex == 3
                                                  ? 'assets/icons/profile2.svg'
                                                  : 'assets/icons/profile.svg',
                                              height: w * 0.06,
                                              color: selectedIndex == 3
                                                  ? primary
                                                  : secondary,
                                            ),
                                            Expanded(child: SizedBox()),
                                            Center(
                                              child: Text(
                                                'Profile',
                                                style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w * 0.025,
                                                  color: selectedIndex == 3
                                                      ? primary
                                                      : secondary,
                                                ),
                                              ),
                                            ),
                                            Expanded(child: SizedBox()),
                                            Expanded(child: SizedBox()),
                                          ],
                                        )),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
          );
  }
}
