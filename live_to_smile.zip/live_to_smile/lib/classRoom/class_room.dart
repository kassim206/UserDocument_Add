// //@dart=2.9
// import 'dart:async';
// import 'dart:io';
// import 'package:intl/intl.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:draggable_home/draggable_home.dart';
// import 'package:flutter/foundation.dart';
// //import 'package:flick_video_player/flick_video_player.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bounce/flutter_bounce.dart';
// import 'package:flutter_svg/svg.dart';
// // import 'package:flutter_zoom_sdk/zoom_options.dart';
// // import 'package:flutter_zoom_sdk/zoom_view.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:live_to_smile/chat/chat_model.dart';
// import 'package:live_to_smile/homePage/home_page.dart';
// import 'package:live_to_smile/homePage/routing.dart';
// import 'package:live_to_smile/session/session.dart';
// //import 'package:video_player/video_player.dart';
//
// import '../bottom_bar/bottomBar.dart';
// import '../flutter_flow/flutter_flow.dart';
//
// List students=[
//   'https://img.freepik.com/free-photo/happy-young-female-student-holding-notebooks-from-courses-smiling-camera-standing-spring-clothes-against-blue-background_1258-70161.jpg?w=2000',
//   'https://img.freepik.com/premium-photo/teenager-student-girl-purple-holding-imaginary-palm-insert-ad_1368-107362.jpg?w=2000',
//   'https://as2.ftcdn.net/v2/jpg/02/69/98/95/1000_F_269989565_ldpNv1BAwrCzsmjvhOMXwYtyhZDKGQrr.jpg',
// ];
// List sessions=[
//   {
//     'name':'Photoshop Tutorial',
//     'duration':'05:15:23 mins',
//     'teacher':'by Suhasini Teacher'
//   },
//   {
//     'name':'How to use erase tool',
//     'duration':'22:15:00 mins',
//     'teacher':'by Suhasini Teacher'
//   },
//   {
//     'name':'How to use erase tool',
//     'duration':'22:15:00 mins',
//     'teacher':'by Suhasini Teacher'
//   },
//   {
//     'name':'How to use erase tool',
//     'duration':'22:15:00 mins',
//     'teacher':'by Suhasini Teacher'
//   },
//   {
//     'name':'How to use erase tool',
//     'duration':'22:15:00 mins',
//     'teacher':'by Suhasini Teacher'
//   },
//   {
//     'name':'How to use erase tool',
//     'duration':'22:15:00 mins',
//     'teacher':'by Suhasini Teacher'
//   }
//
// ];
//
// class ClassRoom extends StatefulWidget {
//   const ClassRoom({Key key,}) : super(key: key);
//
//   @override
//   State<ClassRoom> createState() => _ClassRoomState();
// }
//
// class _ClassRoomState extends State<ClassRoom> {
//   int selectedIndex=0;
//   //FlickManager flickManager;
//    TextEditingController meetingIdController=TextEditingController(text: '8402973253');
//    TextEditingController meetingPasswordController=TextEditingController(text: 'smile@1123');
//    Timer timer;
//    List onGoing=[];
//   getMeetings(){
//     FirebaseFirestore.instance.collection('zoomClass').where('batch',isEqualTo: CurrentUserClassId).orderBy('scheduled',descending: false).where('start',isEqualTo: true).snapshots().listen((event) {
//       onGoing=event.docs;
//       print(onGoing.toString());
//       print(onGoing.length.toString());
//       if(mounted){
//         setState(() {
//
//         });
//       }
//
//     });
//   }
// // joinMeeting(BuildContext context) {
// //   bool _isMeetingEnded(String status) {
// //     var result = false;
// //
// //     if (Platform.isAndroid) {
// //       result = status == "MEETING_STATUS_DISCONNECTING" ||
// //           status == "MEETING_STATUS_FAILED";
// //     } else {
// //       result = status == "MEETING_STATUS_IDLE";
// //     }
// //
// //     return result;
// //   }
// //
// //   if (meetingIdController.text.isNotEmpty &&
// //       meetingPasswordController.text.isNotEmpty) {
// //     ZoomOptions zoomOptions = ZoomOptions(
// //       // screenShare: true,
// //
// //       // showMeetingHeader: true,
// //       domain: "zoom.us",
// //       appKey: "6vsVXmO0S5Ns50C5cp6KMf4sE4I1v6kEBYHa", //API KEY FROM ZOOM
// //       appSecret:
// //       "QNky9FiCqJtwjkg8WRKfjZwx5dbPfx6KfYcF", //API SECRET FROM ZOOM
// //     );
// //     var meetingOptions = ZoomMeetingOptions(
// //         displayName: currentUserName,
// //         userId: studentId,
// //
// //         /// pass username for join meeting only --- Any name eg:- EVILRATT.
// //         meetingId: meetingIdController.text,
// //
// //         /// pass meeting id for join meeting only
// //         meetingPassword: meetingPasswordController.text,
// //
// //         /// pass meeting password for join meeting only
// //         disableDialIn: "true",
// //         disableDrive: "true",
// //         disableInvite: "true",
// //         disableShare: "true",
// //         disableTitlebar: "false",
// //         viewOptions: "true",
// //         noAudio: "false",
// //         noDisconnectAudio: "false");
// //
// //     var zoom = ZoomView();
// //     zoom.initZoom(zoomOptions).then((results) {
// //       if (results[0] == 0) {
// //         zoom.onMeetingStatus().listen((status) {
// //           if (kDebugMode) {
// //             print(
// //                 "[Meeting Status Stream] : " + status[0] + " - " + status[1]);
// //           }
// //           if (_isMeetingEnded(status[0])) {
// //             if (kDebugMode) {
// //               print("[Meeting Status] :- Ended");
// //             }
// //             timer.cancel();
// //           }
// //         });
// //         if (kDebugMode) {
// //           print("listen on event channel");
// //         }
// //         zoom.joinMeeting(meetingOptions).then((joinMeetingResult) {
// //           timer = Timer.periodic(const Duration(seconds: 2), (timer) {
// //             zoom.meetingStatus(meetingOptions.meetingId).then((status) {
// //               if (kDebugMode) {
// //                 print("[Meeting Status Polling] : " +
// //                     status[0] +
// //                     " - " +
// //                     status[1]);
// //               }
// //             });
// //           });
// //         });
// //       }
// //     }).catchError((error) {
// //       if (kDebugMode) {
// //         print("[Error Generated] : " + error);
// //       }
// //     });
// //   } else {
// //     if (meetingIdController.text.isEmpty) {
// //       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
// //         content: Text("Enter a valid meeting id to continue."),
// //       ));
// //     } else if (meetingPasswordController.text.isEmpty) {
// //       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
// //         content: Text("Enter a meeting password to start."),
// //       ));
// //     }
// //   }
// // }
// List classMates=[];
// getClassRoom(){
//   FirebaseFirestore.instance.collection('class').doc(CurrentUserClassId).snapshots().listen((event) {
//     classMates=event.get('students');
//     if(mounted){
//         setState(() {});
//       }
//     });
// }
//   Duration TotalMinuts;
//   DateTime inTime;
//   int count=1;
//
//   counter(DateTime time) async {
//
//     for(int i=count;i>0;i--){
//
//       await Future.delayed(const Duration(seconds: 1));
//       TotalMinuts=time.difference(DateTime.now());
//     }
//
//     if(mounted){
//       setState((){});
//     }
//     counter(time);
//
//
//   }
//   @override
//   void initState() {
//   getClassRoom();
//   getMeetings();
//   print(CurrentUserClassId);
//   print('-------------------------------------------------');
//     // flickManager = FlickManager(
//     //
//     //   videoPlayerController:
//     //   VideoPlayerController.network("https://firebasestorage.googleapis.com/v0/b/movieflix-baeb9.appspot.com/o/users%2FiF0TtLy7QuaZFuDOGVyb1MD4Vez2%2Fuploads%2F1656669364993000.mp4?alt=media&token=325fb835-6b36-433b-af64-d5eea24ca50d",
//     //   videoPlayerOptions: VideoPlayerOptions(
//     //
//     //   )
//     // ));
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//   DateTime date=nextClass['scheduled'].toDate();
//   String time=formattedTime(date).toString();
//   counter(date);
//     return WillPopScope(
//       onWillPop: (){
//         Navigator.pushAndRemoveUntil(
//           context,
//           MaterialPageRoute(
//               builder: (context) => BottomBar(bIndex: 0,)),
//               (b) => false,
//         );
//       },
//       child: DraggableHome(
//         headerExpandedHeight: 0.52,
//         curvedBodyRadius: 0,
//
//         title: Text('${ClassIdToName[CurrentUserClassId]}',style: GoogleFonts.lexend(
//             fontWeight: FontWeight.w500,
//             fontSize: w*0.045,color: Colors.black
//         ),),
//
//         centerTitle: false,
//         actions: [
//
//           SizedBox(width: w*0.05,),
//           Center(
//             child: InkWell(
//               onTap: (){
//                 // FirebaseFirestore.instance.collection('meetings').add({
//                 //   "createdDate":FieldValue.serverTimestamp(),
//                 //   "date":Timestamp.fromDate(DateTime(2022,11,3,18,0,0,0,0)),
//                 //   'class':CurrentUserClassId,
//                 //   "course":'C101',
//                 //   "university":'fECbKHamJZjlR0g0dtKw',
//                 //   "comments":'',
//                 //   "start":false,
//                 //   'status':0,
//                 //   'tutor':'T101',
//                 //   'desc':'Class about design structure'
//                 // });
//               },
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: Color(0xff343434),
//                   borderRadius: BorderRadius.circular(w*0.02),
//                   boxShadow: [
//                     BoxShadow(
//                       color:Colors.grey.shade300,
//                       offset: const Offset(
//                         5.0,
//                         2.0,
//                       ),
//                       blurRadius: 10.0,
//                       spreadRadius: -2.0,
//                     ), //BoxShadow
//                     //BoxShadow
//                   ],
//                 ),
//                 child: Padding(
//                   padding:  EdgeInsets.fromLTRB(
//                     w*0.03,
//                     w*0.01,
//                     w*0.03,
//                     w*0.01,
//                   ),
//                   child: Text('16 Classes',style: GoogleFonts.lexend(
//                       fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.white
//                   ),),
//                 ),
//               ),
//             ),
//           ),
//           SizedBox(width: w*0.05,)
//         ],
//         headerWidget: headerWidget(context),
//         //headerBottomBar: headerBottomBarWidget(),
//
//         body: [
//           ListView(
//             padding:  EdgeInsets.only(
//                 left: w*0.05,
//                 right: w*0.05,
//                 top: w*0.025
//             ),
//             shrinkWrap: true,
//             physics: NeverScrollableScrollPhysics(),
//             children: [
//               DefaultTabController(
//                 length: 3,
//                 child: Column(
//                   children: [
//                     Container(
//                       height: w*0.12,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(10)
//                       ),
//                       child:  Padding(
//                         padding:  EdgeInsets.all(w*0.015),
//                         child: TabBar(
//                           labelStyle: GoogleFonts.lexend(
//                             fontSize: w*0.025,color: Colors.white,fontWeight: FontWeight.w500
//                           ),
//                           onTap: (int index){
//                             setState(() {
//                               selectedIndex=index;
//                             });
//                           },
//                           unselectedLabelStyle: GoogleFonts.lexend(
//                               fontSize: w*0.025,
//                           ),
//                           unselectedLabelColor:darkT ,
//                           indicator: BoxDecoration(
//                             color: Color(0xff343434),
//                             borderRadius: BorderRadius.circular(10)
//                           ),
//                           tabs: [
//                             Tab(
//                               text: 'Last Sessions',
//                             ),
//                             Tab(
//                               text: 'First Sessions',
//                             ),
//                             Tab(
//                               text: 'Not played',
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                    selectedIndex==0? Container(
//                       child: ListView.builder(
//                         itemCount: sessions.length,
//                         padding: EdgeInsets.only(
//                           top: w*0.03
//                         ),
//                         shrinkWrap: true,
//                         reverse: true,
//                         physics: NeverScrollableScrollPhysics(),
//                         itemBuilder: (context,index){
//                           return Padding(
//                             padding:  EdgeInsets.only(bottom: w*0.03),
//                             child: Bounce(
//                               duration: Duration(milliseconds: 110),
//                               onPressed: (){
//                                 Navigator.push(context, MaterialPageRoute(builder: (context)=>Session()));
//                               },
//                               child: Container(
//                                 decoration: BoxDecoration(
//                                   color: Colors.white,
//                                   borderRadius: BorderRadius.circular(15)
//                                 ),
//                                 child: Row(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Expanded(
//                                       child: Padding(
//                                         padding:  EdgeInsets.all(w*0.05),
//                                         child: Row(
//                                           children: [
//                                             CircleAvatar(
//                                               backgroundColor: back,
//                                               radius: w*0.08,
//                                               backgroundImage: AssetImage('assets/icons/vplay.png'),
//                                             ),
//                                             SizedBox(width: w*0.05,),
//                                             Column(
//                                               crossAxisAlignment: CrossAxisAlignment.start,
//                                               children: [
//                                                 Text(sessions[index]['name'],style: GoogleFonts.lexend(
//                                                     fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.black
//                                                 ),),
//                                                 SizedBox(height: w*0.005,),
//                                                 Text(sessions[index]['duration'],style: GoogleFonts.lexend(
//                                                     fontWeight: FontWeight.w500,fontSize: w*0.025,color: Color(0xffFA2B3A)
//                                                 ),),
//                                                 SizedBox(height: w*0.01,),
//                                                 Padding(
//                                                   padding:  EdgeInsets.only(
//                                                     left: w*0.003,
//                                                   ),
//                                                   child: Text(sessions[index]['teacher'],style: GoogleFonts.lexend(
//                                                       fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                                                   ),),
//                                                 ),
//                                               ],
//                                             )
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                     Container(
//                                       height: w*0.08,
//                                       width: w*0.1,
//                                       decoration: BoxDecoration(
//                                         color: Color(0xffFEDE00),
//                                         borderRadius: BorderRadius.only(
//                                           topRight: Radius.circular(15)
//                                         )
//                                       ),
//                                       child: Center(child: Text(index+1<10?'#0${index+1}':'#${index+1}',style: GoogleFonts.lexend(
//                                         fontWeight: FontWeight.w500,fontSize: w*0.025
//                                       ),)),
//                                     )
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           );
//                         },
//                       ),
//                     ):selectedIndex==1?
//                    Container(
//                      child: ListView.builder(
//                        itemCount: sessions.length,
//                        padding: EdgeInsets.only(
//                            top: w*0.03
//                        ),
//                        shrinkWrap: true,
//                        physics: NeverScrollableScrollPhysics(),
//                        itemBuilder: (context,index){
//                          return Padding(
//                            padding:  EdgeInsets.only(bottom: w*0.03),
//                            child: Container(
//                              decoration: BoxDecoration(
//                                  color: Colors.white,
//                                  borderRadius: BorderRadius.circular(15)
//                              ),
//                              child: Row(
//                                crossAxisAlignment: CrossAxisAlignment.start,
//                                children: [
//                                  Expanded(
//                                    child: Padding(
//                                      padding:  EdgeInsets.all(w*0.05),
//                                      child: Row(
//                                        children: [
//                                          CircleAvatar(
//                                            backgroundColor: back,
//                                            radius: w*0.08,
//                                            backgroundImage: AssetImage('assets/icons/vplay.png'),
//                                          ),
//                                          SizedBox(width: w*0.05,),
//                                          Column(
//                                            crossAxisAlignment: CrossAxisAlignment.start,
//                                            children: [
//                                              Text(sessions[index]['name'],style: GoogleFonts.lexend(
//                                                  fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.black
//                                              ),),
//                                              SizedBox(height: w*0.005,),
//                                              Text(sessions[index]['duration'],style: GoogleFonts.lexend(
//                                                  fontWeight: FontWeight.w500,fontSize: w*0.025,color: Color(0xffFA2B3A)
//                                              ),),
//                                              SizedBox(height: w*0.01,),
//                                              Padding(
//                                                padding:  EdgeInsets.only(
//                                                  left: w*0.003,
//                                                ),
//                                                child: Text(sessions[index]['teacher'],style: GoogleFonts.lexend(
//                                                    fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                                                ),),
//                                              ),
//                                            ],
//                                          )
//                                        ],
//                                      ),
//                                    ),
//                                  ),
//                                  Container(
//                                    height: w*0.08,
//                                    width: w*0.1,
//                                    decoration: BoxDecoration(
//                                        color: Color(0xffFEDE00),
//                                        borderRadius: BorderRadius.only(
//                                            topRight: Radius.circular(15)
//                                        )
//                                    ),
//                                    child: Center(child: Text(index+1<10?'#0${index+1}':'#${index+1}',style: GoogleFonts.lexend(
//                                        fontWeight: FontWeight.w500,fontSize: w*0.025
//                                    ),)),
//                                  )
//                                ],
//                              ),
//                            ),
//                          );
//                        },
//                      ),
//                    ):
//                    Padding(
//                      padding:  EdgeInsets.only(
//                        top: h*0.2,
//                        bottom: h*0.3,
//                      ),
//                      child: Column(
//                        mainAxisAlignment: MainAxisAlignment.center,
//                        children: [
//                          Padding(
//                            padding:  EdgeInsets.only(
//                              left: w*0.15,
//                              right: w*0.15,
//                              bottom: w*0.075,
//                            ),
//                            child: Image.asset('assets/icons/empty.png'),
//                          ),
//                          Text('No sessions here',style: GoogleFonts.lexend(
//                            fontSize: w*0.04,color: darkT,fontWeight: FontWeight.w400
//                          ),)
//                        ],
//                      ),
//                    )
//                   ],
//                 ),
//               )
//             ],
//           ),
//           SizedBox(height:w*0.25)
//         ],
//         fullyStretchable: false,
//         alwaysShowTitle: true,
//         alwaysShowLeadingAndAction: true,
//
//         backgroundColor: back,
//         appBarColor: back,
//       ),
//     );
//   }
//
//   Row headerBottomBarWidget() {
//     return Row(
//       mainAxisSize: MainAxisSize.max,
//       mainAxisAlignment: MainAxisAlignment.end,
//       crossAxisAlignment: CrossAxisAlignment.center,
//       children: const [
//         Icon(
//           Icons.settings,
//           color: Colors.white,
//         ),
//       ],
//     );
//   }
//
//   Widget headerWidget(BuildContext context) {
//     DateTime date=nextClass['scheduled'].toDate();
//     String time=formattedTime(date).toString();
//     return Container(
//       decoration: BoxDecoration(
//
//       ),
//       child: Padding(
//         padding:  EdgeInsets.only(
//           left: w*0.05,
//           right: w*0.05,
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Expanded(child: SizedBox()),
//             // Container(
//             //   height: w*0.5,
//             //   width: w*0.9,
//             //   decoration: BoxDecoration(
//             //     color: Colors.white
//             //   ),
//             // ),
//             Stack(
//               children: [
//                 // ClipRRect(
//                 //   borderRadius: BorderRadius.circular(10),
//                 //   child: FlickVideoPlayer(
//                 //       flickManager: flickManager
//                 //   ),
//                 // ),
//                 Bounce(
//                   onPressed: (){
//                    if(onGoing.length!=0){
//                      // joinMeeting(context);
//                    }
//
//                   },
//                   duration: Duration(milliseconds: 100),
//                   child: Container(
//                     height: w*0.53,
//                     width: w*0.9,
//
//                     child: Stack(
//                       children: [
//                         Center(child: Padding(
//                           padding: const EdgeInsets.all(20),
//                           child: Image.asset('assets/icons/logo.png'),
//                         )),
//                         Container(
//                           decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(10),
//                             color: Colors.black.withOpacity(0.8)
//                           ),
//                           child: Center(
//                             child: CircleAvatar(
//                               backgroundColor: primary.withOpacity(0.5),
//                               radius: w*0.08,
//                               child: Icon(Icons.play_arrow,color: Colors.white,size: 30,),
//                             ),
//
//                           ),
//                         ),
//                       ],
//                     ),
//
//                   ),
//                 ),
//
//                 Align(
//                   alignment: Alignment.topLeft,
//                   child: Padding(
//                     padding:  EdgeInsets.only(
//                       left: w*0.03,
//                       top: w*0.03,
//                     ),
//                     child:nextClass['start']==false?Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text('Starts in:',
//                           style:  GoogleFonts.poppins(fontSize: 14,fontWeight:FontWeight.w500,color: Colors.white),
//                           textAlign: TextAlign.left,
//                         ),
//                         TotalMinuts==null?Text(""
//                             .toString(),
//                           style: GoogleFonts.poppins(fontSize: 14,fontWeight:FontWeight.bold,color: Colors.redAccent),
//                           textAlign: TextAlign.left,
//                         ): Text("${TotalMinuts.inDays<1?'':TotalMinuts.inDays}${TotalMinuts.inDays<1?'':':'}${TotalMinuts.inHours.remainder(24)}:${TotalMinuts.inMinutes.remainder(60)}"
//                             ":${TotalMinuts.inSeconds.remainder(60)}"
//                             .toString(),
//                           style: GoogleFonts.poppins(fontSize: 14,fontWeight:FontWeight.bold,color: Colors.redAccent),
//                           textAlign: TextAlign.left,
//                         ),
//                       ],
//                     ): Image.asset('assets/icons/live.png',height: w*0.05,),
//                   ),
//                 )
//               ],
//             ),
//             // ClipRRect(
//             //   borderRadius: BorderRadius.circular(10),
//             //   child: FlutterFlowVideoPlayer(
//             //     path:'https://firebasestorage.googleapis.com/v0/b/movieflix-baeb9.appspot.com/o/users%2FiF0TtLy7QuaZFuDOGVyb1MD4Vez2%2Fuploads%2F1656669364993000.mp4?alt=media&token=325fb835-6b36-433b-af64-d5eea24ca50d',
//             //     videoType: VideoType.network,
//             //     autoPlay:true,
//             //     looping: true,
//             //     showControls: true,
//             //     allowFullScreen: true,
//             //     allowPlaybackSpeedMenu: false,
//             //   ),
//             // ),
//             SizedBox(
//               height: w*0.03,
//             ),
//             Padding(
//               padding:  EdgeInsets.only(
//                 left: w*0.025,
//                 right: w*0.025,
//               ),
//               child: Row(
//                 children: [
//                   Expanded(child: Row(
//                     children: [
//                       CircleAvatar(
//                         radius: w*0.04,
//                         backgroundImage:NetworkImage(tutorMap[nextClass['tutor']]['image']) ,
//                         backgroundColor: Colors.white,
//                       ),
//                       SizedBox(width: w*0.025,),
//
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text('Session by',style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.black
//                           ),),
//                           Text(tutorMap[nextClass['tutor']]['name'],style: GoogleFonts.lexend(
//                               fontWeight: FontWeight.w500,fontSize: w*0.028,color: Color(0xffFA2B3A)
//                           ),)
//                         ],
//                       )
//                     ],
//                   )),
//                   Padding(
//                     padding:  EdgeInsets.only(
//                         left: w*0.003,
//                     ),
//                     child: Text('${(date.toString().substring(0,10)==DateTime.now().toString().substring(0,10))?
//                     'Today':(date.toString().substring(0,10)==DateTime.now().add(Duration(days: 1)).toString().substring(0,10))?
//                     'Tomorrow':DateFormat("MMM dd yyyy").format(date)}  $time',style: GoogleFonts.lexend(
//                         fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                     ),),
//                   ),
//                 ],
//               ),
//             ),
//             SizedBox(
//               height: w*0.05,
//             ),
//             Padding(
//               padding:  EdgeInsets.only(
//                 left: w*0.025,
//                 right: w*0.025,
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(nextClass['name'],style: GoogleFonts.lexend(
//                       fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.black
//                   ),),
//                   Text('Created in ${DateFormat("MMM dd yyyy").format(nextClass['date'].toDate())}',style: GoogleFonts.lexend(
//                       fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                   ),)
//                 ],
//               ),
//             ),
//             SizedBox(
//               height: w*0.05,
//             ),
//             Padding(
//               padding:  EdgeInsets.only(
//                 left: w*0.025,
//                 right: w*0.025,
//               ),
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text('Your Classmates',style: GoogleFonts.lexend(
//                             fontWeight: FontWeight.w500,fontSize: w*0.035,color: Colors.black
//                         ),),
//                         Text('${classMates.length} Students here!',style: GoogleFonts.lexend(
//                             fontWeight: FontWeight.w400,fontSize: w*0.025,color: darkT
//                         ),)
//                       ],
//                     ),
//                   ),
//                   Expanded(
//                     child: Row(
//
//                       children: [
//                       classMates.length==0?Container():  Container(
//                             height: w*0.08,
//                             child: Stack(
//                               children:List.generate(classMates.length>4?4:classMates.length, (index) => Padding(
//                                 padding:  EdgeInsets.only(
//                                   left: w*0.07*index
//                                 ),
//                                 child:index==3?CircleAvatar(
//                                   radius: w*0.04,backgroundColor:Color(0xffD9D9D9),
//                                   child: Text('+'+(classMates.length-3).toString(),style: GoogleFonts.lexend(
//                                     fontSize: w*0.02,color: Colors.black
//                                   ),),
//                                 ): StreamBuilder<DocumentSnapshot>(
//                                   stream: FirebaseFirestore.instance.collection('candidates').doc(classMates[index]).snapshots(),
//                                   builder: (context, snapshot) {
//                                     if(!snapshot.hasData){
//                                       return CircleAvatar(
//                                         radius: w*0.04,backgroundColor:Color(0xffD9D9D9),
//
//                                       );
//                                     }
//                                     var data=snapshot.data;
//                                     return CircleAvatar(
//                                       radius: w*0.04,backgroundColor:Color(0xffD9D9D9),
//                                       backgroundImage: NetworkImage(data['photo']),
//                                     );
//                                   }
//                                 ),
//                               )),
//                             )),
//                         Expanded(child: SizedBox()),
//                         Bounce(
//                           onPressed: (){
//                             Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatScreen()));
//                           },
//                           duration: Duration(milliseconds: 100),
//                           child: Container(
//                             height: w*0.08,
//                             width: w*0.1,
//                             decoration: BoxDecoration(
//                               color: Color(0xff343434),
//                               borderRadius: BorderRadius.circular(10)
//                             ),
//                             child: Padding(
//                               padding:  EdgeInsets.all(w*0.01),
//                               child: SvgPicture.asset('assets/icons/message.svg'),
//                             ),
//                           ),
//                         )
//                       ],
//                     )
//                   ),
//                 ],
//               ),
//             ),
//             SizedBox(
//               height: w*0.03,
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
