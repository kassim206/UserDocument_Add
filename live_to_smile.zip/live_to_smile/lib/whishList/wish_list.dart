import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';

List wishList=[
  {
    'thumb':'https://s2.research.com/wp-content/uploads/2021/12/15084155/pedagogy-in-educatiion-1200x600.jpg',
  },
  {
    'thumb':'https://internationalteacherstraining.com/blog/wp-content/uploads/2017/07/20.03.2020-10-Essential-Needs-for-Teacher-Training-728x370.jpg',
  },
  {
    'thumb':'https://mebhocam.com/wp-content/uploads/2022/04/new_teacher.jpeg',
  },
  {
    'thumb':'http://www.educationnext.org/wp-content/uploads/2020/03/ednext-sept19-blog-hess-teacher.png',
  },
  {
    'thumb':'https://expatguideturkey.com/wp-content/uploads/2021/05/conditions-of-employing-a-foreign-teacher-780x470.jpg',
  },
];

class WishList extends StatefulWidget {
  const WishList({Key? key}) : super(key: key);

  @override
  State<WishList> createState() => _WishListState();
}

class _WishListState extends State<WishList> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
              builder: (context) => BottomBar(bIndex: 0,)),
              (b) => false,
        );
         return Future.value(true);

      },
      child: Scaffold(
        backgroundColor: back,
        appBar: AppBar(
          backgroundColor: back,
          foregroundColor: Colors.black,
          automaticallyImplyLeading: false,
          elevation: 0,
          title: Text("Wishlist",style: GoogleFonts.lexend(
              fontWeight: FontWeight.w500,
              fontSize: w*0.045,color: Colors.black
          ),),

        ),
        body: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              ListView.builder(
                itemCount: wishList.length,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                padding: EdgeInsets.only(
                    left:w*0.05,
                    right:w*0.05,
                    top:w*0.05,
                ),
                itemBuilder: (context,index){
                  return Padding(
                    padding:  EdgeInsets.only(
                      bottom: w*0.05
                    ),
                    child: Bounce(
                      onPressed: (){
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => BottomBar(bIndex: 1,)),
                              (b) => false,
                        );
                      },
                      duration: Duration(milliseconds: 100),
                      child: Container(
                        height: w*0.5,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                            image: NetworkImage(wishList[index]['thumb']),
                            fit: BoxFit.cover
                          )
                        ),
                        child: Container(
                          decoration: BoxDecoration(

                              borderRadius: BorderRadius.circular(20),
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment(0, 1),
                              colors: <Color>[
                                Colors.black.withOpacity(0.3),
                                Colors.black.withOpacity(0.3),
                                Colors.black.withOpacity(0.4),
                                Colors.black.withOpacity(0.5),
                                Colors.black.withOpacity(0.7),
                                Colors.black.withOpacity(0.8),
                                Colors.black.withOpacity(0.9),

                              ], // Gradient from https://learnui.design/tools/gradient-generator.html
                              tileMode: TileMode.mirror,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: w*0.08,
                                  width: w*0.1,
                                  decoration: BoxDecoration(
                                      color: Color(0xffFEDE00),
                                      borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(20)
                                      )
                                  ),
                                  child: Center(child: Text(index+1<10?'#0${index+1}':'#${index+1}',style: GoogleFonts.lexend(
                                      fontWeight: FontWeight.w500,fontSize: w*0.025
                                  ),)),
                                ),
                              ),
                              SvgPicture.asset('assets/icons/whiteP.svg'),
                              Padding(
                                padding:  EdgeInsets.only(
                                  left: w*0.05,
                                  right: w*0.05,
                                  bottom: w*0.05
                                ),
                                child: Row(
                                  children: [
                                    Expanded(child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: w*0.04,
                                          backgroundImage:NetworkImage('https://mebhocam.com/wp-content/uploads/2022/04/new_teacher.jpeg') ,
                                          backgroundColor: Colors.white,
                                        ),
                                        SizedBox(width: w*0.025,),

                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text('Recent Session by',style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.white
                                            ),),
                                            Text('Suhasini Teacher',style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w500,fontSize: w*0.028,color: Colors.white
                                            ),)
                                          ],
                                        )
                                      ],
                                    )),
                                    Padding(
                                      padding:  EdgeInsets.only(
                                        left: w*0.003,
                                      ),
                                      child: SvgPicture.asset('assets/icons/wishlist2.svg',color: Colors.white,)
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
              SizedBox(height:w*0.25)
            ],
          ),
        ),
      ),
    );
  }
}
