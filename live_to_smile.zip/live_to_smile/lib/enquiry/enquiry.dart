class Enquiry{
  int status;
  DateTime date;
  String name;
  String place;
  String mobile;
  String email;
  DateTime dob;
  String additionalInfo;
  List educationalDetails;
  String courses;
  String userId;
  String branchId;
  String userEmail;
  List search;
  bool check;
  String university;
  String enquiryId;
  String phoneCode;
  String countryCode;

  Enquiry({
    this.enquiryId='',
    required this.status,
    required this.date,
    required this.name,
    required this.place,
    required this.mobile,
    required this.email,
    required this.dob,
    required this.additionalInfo,
    required this.educationalDetails,
    required this.courses,
    required this.userId,
    required this.branchId,
    required this.userEmail,
    required this.search,
    required this.check,
    required this.university,
    required this.phoneCode,
    required this.countryCode,

  });

  // static void createEnquiry(Enquiry details)async{
  //   final docUser=FirebaseFirestore.instance.collection('enquiry').doc();
  //   details.enquiryId=docUser.id;
  //
  //   final json=details.toJson();
  //   await docUser.set(json);
  // }


  Map<String,dynamic> toJson() => {
    'enquiryId':enquiryId,
    'status':status,
    'date':date,
    'name':name,
    'place':place,
    'mobile':mobile,
    'email':email,
    'dob':dob,
    'additionalInfo':additionalInfo,
    'educationalDetails':educationalDetails,
    'courses':courses,
    'userId':userId,
    'branchId':branchId,
    'userEmail':userEmail,
    'search':search,
    'check':check,
    'university':university,
    'countryCode':countryCode,
    'phoneCode':phoneCode,


  };

  factory Enquiry.fromJson(Map<String,dynamic>json)=> Enquiry(
    enquiryId: json['enquiryId'],
    status: json['status'],
    date: json['date'],
    name: json['name'],
    place: json['place'],
    mobile: json['mobile'],
    email: json['email'],
    dob: json['dob'],
    additionalInfo: json['additionalInfo'],
    educationalDetails: json['educationalDetails'],
    courses: json['courses'],
    userId: json['userId'],
    branchId: json['branchId'],
    userEmail: json['userEmail'],
    search: json['search'],
    check: json['check'],
    university: json['university'],
    countryCode:json['countryCode'],
    phoneCode:json['phoneCode'],


  );

}