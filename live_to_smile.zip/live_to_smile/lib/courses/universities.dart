//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bounce/flutter_bounce.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:live_to_smile/courses/uniCourses.dart';
//
// import '../bottom_bar/bottomBar.dart';
//
// class Universities extends StatefulWidget {
//   const Universities({ Key? key}) : super(key: key);
//
//   @override
//   State<Universities> createState() => _UniversitiesState();
// }
//
// class _UniversitiesState extends State<Universities> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey.shade200,
//       appBar: AppBar(
//         elevation: 0,
//         backgroundColor: Colors.grey.shade200,
//         foregroundColor: Colors.black,
//         title: Text("Available Universities",style: GoogleFonts.lexend(
//             fontWeight: FontWeight.w500,
//             fontSize: w*0.045,color: Colors.black
//         ),),
//
//         centerTitle: false,
//
//       ),
//       body: StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance.collection('university').where('available',isEqualTo: true).snapshots(),
//         builder: (context, snapshot) {
//           if(!snapshot.hasData){
//             return Center(child: CircularProgressIndicator());
//           }
//           List data=snapshot.data!.docs;
//           return ListView.builder(
//             itemCount: data.length,
//             padding: EdgeInsets.all(w*0.05),
//             itemBuilder: (context,index){
//               return  Padding(
//                 padding: const EdgeInsets.only(bottom: 10),
//                 child: Bounce(
//                   onPressed: (){
//                     Navigator.push(context, MaterialPageRoute(builder: (context)=>UniCourses(data: data[index],)));
//                   },
//                   duration: Duration(milliseconds: 100),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(10)
//                     ),
//                     child: Padding(
//                       padding:  EdgeInsets.all(w*0.05),
//                       child: Row(
//                         children: [
//                           SvgPicture.asset('assets/icons/univer.svg',height: w*0.1,color: Colors.red,),
//                           SizedBox(width: w*0.05,),
//                           Expanded(child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.stretch,
//                             children: [
//                               Text(data[index]['name'],style: GoogleFonts.lexend(
//                                 fontWeight: FontWeight.w600,fontSize: w*0.035
//                               ),),
//                               SizedBox(height: w*0.02,),
//                               Text(data[index]['courseList'].length.toString()+' Courses',style: GoogleFonts.lexend(
//                                   fontWeight: FontWeight.w600,fontSize: w*0.03,color: Colors.grey.shade600
//                               ),)
//                             ],
//                           ))
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               );
//             },
//           );
//         }
//       ),
//     );
//   }
// }
