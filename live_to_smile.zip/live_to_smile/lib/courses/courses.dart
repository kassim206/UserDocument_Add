//
// import 'dart:developer';
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:google_fonts/google_fonts.dart';
//
// import '../bottom_bar/bottomBar.dart';
// import '../homePage/courseView.dart';
//
// class Courses extends StatefulWidget {
//   const Courses({ Key? key}) : super(key: key);
//
//   @override
//   State<Courses> createState() => _CoursesState();
// }
//
// class _CoursesState extends State<Courses> {
//   List courseList=[];
//   Map<String, dynamic> courseName = {};
//   getCourses()  {
//
//     FirebaseFirestore.instance.collection('university').where('available',isEqualTo: true).snapshots().listen((event) {
//
//       for(DocumentSnapshot data in event.docs){
//
//
//         if(data.get('courseList').length!=0){
//           for (var doc in data.get('courseList')) {
//             List feeList=doc['feeList'];
//             print('object');
//             log('object');
//             print(doc);
//             courseList.add({
//               'university':data['name'],
//               'available':doc['available'],
//               'courseId':doc['courseId'],
//               'duration':feeList.length,
//               'totalFee':doc['totalFee'],
//               'feeList':doc['feeList'],
//               'eligibility':doc['eligibility'],
//               'monthOrYear':doc['monthOrYear'],
//               'classDuration':doc['duration']
//
//             });
//             print(doc);
//           }
//         }
//
//
//       }
//       if (mounted) {
//         setState(() {
//
//         });
//       }
//     });
//
//
//
//   }
//
//   getCourseName() {
//     FirebaseFirestore.instance
//         .collection('course').snapshots().listen((event){
//       for(DocumentSnapshot doc in event.docs){
//         courseName[doc.id]=doc.get('name');
//       }
//       if(mounted){
//         setState(() {});
//       }
//
//     });
//   }
//
//   @override
//   void initState() {
//     getCourses();
//     getCourseName();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return  Scaffold(
//       backgroundColor: Colors.grey.shade200,
//       appBar: AppBar(
//         elevation: 0,
//         backgroundColor: Colors.grey.shade200,
//         foregroundColor: Colors.black,
//         title: Text("Available Courses",style: GoogleFonts.lexend(
//             fontWeight: FontWeight.w500,
//             fontSize: w*0.045,color: Colors.black
//         ),),
//
//         centerTitle: false,
//
//       ),
//
//       body: ListView.builder(
//           shrinkWrap: true,
//           padding: EdgeInsets.all(w*0.05),
//           itemCount: courseList.length,
//           itemBuilder: (context, index) {
//
//             final course=courseList[index];
//             return Padding(
//               padding: const EdgeInsets.only(bottom: 10),
//               child: Container(
//
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//
//                   borderRadius: BorderRadius.circular(20),
//
//
//                 ),
//                 child: Padding(
//                   padding:  EdgeInsets.all(w*0.05),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.stretch,
//                     mainAxisAlignment: MainAxisAlignment.spaceAround,
//                     children: [
//
//                       Text('${courseName[course['courseId']]}',
//                         style:  GoogleFonts.lexend(fontWeight: FontWeight.bold,fontSize: w*0.045),),
//                       SizedBox(height: 5,),
//                       Container(
//                         child: Row(
//                           children: [
//                             SvgPicture.asset('assets/icons/duration.svg',height: w*0.03,),
//                             SizedBox(width: 5,),
//                             Text('${course['classDuration']} ${course['monthOrYear']}',
//                               style:  GoogleFonts.lexend(fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.grey.shade700),),
//                           ],
//                         ),
//                       ),
//                       SizedBox(height: 5,),
//                       Container(
//                         child: Row(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             SvgPicture.asset('assets/icons/univer.svg',height: w*0.03,),
//                             SizedBox(width: 5,),
//                             Expanded(
//                               child: Text('Eligibility : ${course['eligibility']}',
//                                 style:  GoogleFonts.lexend(fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.grey.shade700),),
//                             ),
//                           ],
//                         ),
//                       ),
//                       SizedBox(height: 5,),
//                       Row(
//                         children: [
//                           SvgPicture.asset('assets/icons/univercity.svg',height: w*0.03,),
//                           SizedBox(width: 5,),
//                           Text(course['university'],style:  GoogleFonts.lexend(fontWeight: FontWeight.w500,fontSize: w*0.03,color: Colors.grey.shade700),),
//                         ],
//                       ),
//                       SizedBox(height: 10,),
//                       Row(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text('₹ ${course['totalFee'].toStringAsFixed(1)}',
//                             style:  GoogleFonts.lexend(fontWeight: FontWeight.w700,fontSize: w*0.045,color: Colors.red),),
//                           InkWell(
//                             onTap: (){
//                               Navigator.push(context, MaterialPageRoute(builder: (context)=>coursesView(
//                                 data:course,
//                                 course:courseName[course['courseId']],
//                                 courseId:course['courseId'],
//                               )));
//                             },
//                             child: Container(
//                               height: w*.1,
//                               width: w*.3,
//                               decoration: BoxDecoration(
//                                 color: primary,
//                                 borderRadius: BorderRadius.circular(10),
//
//                               ),
//                               child: Center(child: Text('View',style:  GoogleFonts.lexend(fontWeight: FontWeight.bold,fontSize: w*0.05,color: Colors.black),)),
//
//                             ),
//                           ),
//
//                         ],
//                       ),
//                     ],
//
//                   ),
//                 ),
//               ),
//             );
//
//           }
//       ),
//     );
//   }
// }
