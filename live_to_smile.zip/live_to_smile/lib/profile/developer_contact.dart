
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:url_launcher/url_launcher.dart';

import '../main.dart';



class SupportContact extends StatefulWidget {
  const SupportContact({Key? key}) : super(key: key);

  @override
  _SupportContactState createState() => _SupportContactState();
}

class _SupportContactState extends State<SupportContact> {
  late Future<void> _launche;
  Future<void>_makeCall(String url) async {
    if(await canLaunch(url)){
      await launch(url);
    }
    else{
      throw 'Could not call$url';
    }
  }
  String? number;
  String? email;
  String? wNumber;
  getSettings(){
    FirebaseFirestore.instance.collection('branch').doc('O0juQP9oPBfxZveBeWzn').snapshots().listen((event) {
      number=event.get('phone');
      email=event.get('email');
      wNumber=event.get('wNumber');
      if(mounted){
        setState(() {

        });
      }
    });
  }

  @override
  void initState() {
    getSettings();

    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primary,
        foregroundColor: Colors.black,

        elevation: 0,
        title: Text('Help & Support',style: GoogleFonts.lexend(
            fontWeight: FontWeight.w700,fontSize: 12
        ),),
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          color: primary,
            image: DecorationImage(
                image: AssetImage('assets/icons/splash_back.png'),
                fit: BoxFit.fill
            )
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(child: SizedBox()),
            Image.asset('assets/icons/logo.png',height: MediaQuery.of(context).size.height*0.2,),
            Expanded(child: SizedBox()),

            Expanded(child: SizedBox()),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                    onTap: (){
                      _launche=_makeCall('tel:+91${number}');
                    },

                    child: SvgPicture.asset('assets/icons/call.svg',color: Colors.black)),
                SizedBox(width: 10,),
                InkWell(
                    onTap: (){
                      String encodeQueryParameters(Map<String, String> params) {
                        return params.entries
                            .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
                            .join('&');
                      }
                      final Uri emailLaunchUri = Uri(
                        scheme: 'mailto',
                        path: '${email}',
                        query: encodeQueryParameters(<String, String>{
                          'subject': 'Support Request Mail',
                          'body':"type your request here"
                        }),
                      );

                      launch(emailLaunchUri.toString());
                    },
                    child: SvgPicture.asset('assets/icons/message2.svg',color: Colors.black,)),
                SizedBox(width: 10,),
                InkWell(
                  onTap: (){
                    _launche=_makeCall('https://wa.me/<91${wNumber}>');
                  },
                  child: Container(
                    height: 55,width: 55,
                    decoration: BoxDecoration(
                      color: primary,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.black,width: 5)
                    ),
                    child:Image.asset('assets/icons/whatsapp-logo-png-2259.png',color: Colors.black,)
                  ),
                ),
              ],
            ),
            Expanded(child: SizedBox()),
            Expanded(child: SizedBox()),

            SizedBox(height: 20,),
          ],
        ),
      ),
    );
  }
}
