import 'dart:developer';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';

import '../bottom_bar/bottomBar.dart';
import '../core/common/showuploadmessage.dart';
import '../core/routing/routing.dart';

class EditProfile extends ConsumerStatefulWidget {
  const EditProfile({Key? key}) : super(key: key);

  @override
  ConsumerState<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends ConsumerState<EditProfile> {
  UsersModel? user;
  List Ug = ['Signature', 'SSLC', 'Plus two', 'Aadhaar/Passport'];
  List Pg = [
    'Signature',
    'SSLC',
    'Plus two',
    'Aadhaar/Passport',
    'Degree certificate',
    'Degree marksheet'
  ];
  List SSLC = [
    'Signature',
    '8 th marksheet/self attested certificate',
    'Aadhaar/Passport'
  ];
  List plusTwo = ['Signature', 'SSLC', 'Aadhaar/Passport'];

  PlatformFile? pickFile;
  String selected = '';
  Future selectFile(String name) async {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result == null) return;

    pickFile = result.files.first;
    selected = name + '0';
    String ext = '';
    final fileBytes = result.files.first.bytes;

    //showUploadMessage(context, 'Uploading...',showLoading: true);

    uploadFileToFireBase(name, fileBytes, ext);

    setState(() {});
  }

  UploadTask? uploadTask;
  List uploadDocument = [];
  Map <String, dynamic> data = {};
  Map <String, dynamic> preData = {};
  Future uploadFileToFireBase(String name, fileBytes, String ext) async {
    uploadTask = FirebaseStorage.instance
        .ref('uploads/${DateTime.now().toString().substring(0, 10)}-$name.$ext')
        .putData(fileBytes);
    final snapshot = await uploadTask?.whenComplete(() {});
    final urlDownlod = await snapshot?.ref.getDownloadURL();
    print(urlDownlod);
    print('******************');

    data.addAll({
      '$name': urlDownlod,
    });
    print(data.keys.toList().toString());
    print('        SUCCESS           ');
    selected = name + '1';
    showUploadMessage(context, '$name Uploaded Successfully...');
    setState(() {});
  }

  getCourseType() {
    if (CourseIdToType[candidatesModel!.course] == 'PG') {
      uploadDocument = Pg;
    }
    else if (CourseIdToType[candidatesModel!.course] == 'UG') {
      uploadDocument = Ug;
    }
    else if (CourseIdToType[candidatesModel!.course] == 'SSLC') {
      uploadDocument = SSLC;
    }
    else {
      uploadDocument = plusTwo;
    }
  }
  final _firebaseStorage = FirebaseStorage.instance;
  String imageUrl = "";
  File? file;
  int imageStatus = 0;
  pickGellary() async {
    final imgfile =
    await ImagePicker.platform.pickImage(source: ImageSource.gallery);
    file = File(imgfile!.path);
    file = File(imgfile.path);
    DocumentSnapshot id = await FirebaseFirestore.instance
        .collection('settings')
        .doc("O0juQP9oPBfxZveBeWzn")
        .get();
    id.reference.update({"image": FieldValue.increment(1)});
    var imageId = id['image'];
    imageStatus = 1;
    setState(() {});
    showUploadMessage(context, 'Uploading...', showLoading: true);
    //Upload to Firebase
    var snapshot = await _firebaseStorage
        .ref()
        .child('registerform/$imageId')
        .putFile(file!);
    var downloadUrl = await snapshot.ref.getDownloadURL();
    imageStatus = 2;
    showUploadMessage(
      context,
      'Success',
    );
    imageUrl = downloadUrl;
    file = File(imgfile.path);
    if (mounted) {

      setState(()  {

      });
    }
  }
  TextEditingController? name;
  TextEditingController? lastName;
  String? preName;
  String? preLastName;
  String? preImageUrl;
  bool loading =true;
  getCandidate() async {

    DocumentSnapshot student=await FirebaseFirestore.instance
        .collection('candidates').doc(user!.uid).get();

    if(student.exists){
      name=TextEditingController(text: student.get('name'));
      preName=student.get('name');
      preLastName=student.get('lastName');
      lastName=TextEditingController(text: student.get('lastName'));
      imageUrl=student.get('photo');
      preImageUrl=student.get('photo');
      data=student.get('documents');
      preData=student.get('documents');
    }
    if(mounted) {
      setState(() {
        loading=false;
      });
    }
  }
  pickFiles() async {
    final imgfile =
    await ImagePicker.platform.pickImage(source: ImageSource.camera);
    file = File(imgfile!.path);
    file = File(imgfile.path);
    imageStatus = 1;
    setState(() {});
    DocumentSnapshot id = await FirebaseFirestore.instance
        .collection('settings')
        .doc("O0juQP9oPBfxZveBeWzn")
        .get();
    id.reference.update({"image": FieldValue.increment(1)});
    var imageId = id['image'];

    //Upload to Firebase
    var snapshot = await _firebaseStorage
        .ref()
        .child('registerform/$imageId')
        .putFile(file!);
    var downloadUrl = await snapshot.ref.getDownloadURL();
    imageStatus = 2;
    setState(() {
      imageUrl = downloadUrl;
    });
    if (mounted) {
      setState(() async {
        file = File(imgfile!.path);
      });
    }
  }

  @override
  void initState() {
    user=ref.read(userProvider);
    getCandidate();
    getCourseType();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return loading?Scaffold(
      body: Center(child: CircularProgressIndicator(),),
    ): Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey.shade200,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.black),
        title: Text(
          'Edit profile',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
      ),
      body: Padding(
        padding:  EdgeInsets.all(w*0.075),
        child: SingleChildScrollView(
          child: Column(
            children: [


              Container(
                width: MediaQuery.of(context).size.width*0.4,
                height: MediaQuery.of(context).size.width*0.4,
                child: Stack(
                  children: [
                    data!["photo"]==""?
                    CircleAvatar(
                        backgroundImage:AssetImage('assets/icons/profile.svg')):
                    CircleAvatar(
                      backgroundImage: CachedNetworkImageProvider(data?['photo']??""),
                      maxRadius: MediaQuery.of(context).size.width*0.2,
                      backgroundColor: primary,

                      // child: (currentUserImage==null||currentUserImage=='')&&imageUrl==''
                      //     ? SvgPicture.asset('assets/icons/profile.svg')
                      //     :CachedNetworkImage(imageUrl:imageUrl!=''?imageUrl:currentUserImage),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: InkWell(
                        onTap: (){
                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: const Text("Image"),
                              content: Container(
                                height: MediaQuery.of(context).size.height * 0.15,
                                child: Column(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [
                                    TextButton(
                                      onPressed: () {
                                        pickGellary();
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        height:
                                        MediaQuery.of(context).size.height *
                                            0.03,
                                        width: MediaQuery.of(context).size.width *
                                            0.2,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(8),
                                          color: Colors.blueGrey,
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Gallery",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 18),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      onPressed: () async {
                                        pickFiles();
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        height:
                                        MediaQuery.of(context).size.height *
                                            0.03,
                                        width: MediaQuery.of(context).size.width *
                                            0.2,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(8),
                                          color: Colors.blueGrey,
                                        ),
                                        child: Center(
                                          child: Text("Camera",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 18)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                        child: Container(
                          height: w*0.1,
                          width: w*0.1,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.grey.shade300
                          ),
                          child: Icon(Icons.edit,color: Colors.black,
                            size: w*0.06,),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: w*0.05,),

              TextFormField(
                controller: name,
                keyboardType: TextInputType.name,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    hintText: "Enter first name",
                    labelText: "First name"
                ),
              ),
              SizedBox(height: w*0.05,),
              TextFormField(
                controller: lastName,
                keyboardType: TextInputType.name,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    hintText: "Enter last name",
                    labelText: "Last name"
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 30, 0, 30),
                child: SizedBox(
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        childAspectRatio: 1,
                        crossAxisCount: 3,
                        crossAxisSpacing: 5,
                        mainAxisSpacing: 10),
                    itemCount: uploadDocument.length,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          selectFile(uploadDocument[index].toUpperCase());
                          setState(() {});
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              image: data.keys.toList().contains(
                                  uploadDocument[index]
                                      .toString()
                                      .toUpperCase())
                                  ? DecorationImage(
                                  image: CachedNetworkImageProvider(data[
                                  uploadDocument[index].toUpperCase()]))
                                  : null,
                              border: Border.all(color: Color(0xffD8D8D8))),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: data.keys.toList().contains(
                                  uploadDocument[index]
                                      .toString()
                                      .toUpperCase())
                                  ? Colors.black.withOpacity(0.4)
                                  : Colors.black.withOpacity(0),
                            ),
                            child: Stack(
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    data.keys.toList().contains(
                                        uploadDocument[index]
                                            .toString()
                                            .toUpperCase())? Container(): SvgPicture.asset(
                                      'assets/icons/photo.svg',
                                      color: Color(0xffD8D8D8),
                                    ),
                                    SizedBox(
                                      height: w * 0.02,
                                    ),
                                    Center(
                                      child: Text(
                                        uploadDocument[index],
                                        style: GoogleFonts.lexend(
                                            fontWeight: FontWeight.w400,
                                            fontSize: w * 0.03,
                                            color: data.keys.toList().contains(
                                                uploadDocument[index]
                                                    .toString()
                                                    .toUpperCase())
                                                ? Colors.white
                                                : Colors.grey.shade500),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ],
                                ),
                                selected ==
                                    '${uploadDocument[index].toString().toUpperCase()}0'
                                    ? Center(
                                    child: CircularProgressIndicator(
                                      color: Colors.black,
                                    ))
                                    : Container()
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                    onTap: () {

                      if(preName!=name?.text||preLastName!=lastName?.text||preImageUrl!=imageUrl||!mapEquals(preData, data)) {
                        if (data.length == uploadDocument.length) {
                          showDialog(
                            context: context,
                            builder: (ctx) =>
                                AlertDialog(
                                  title: const Text("Update Documents?"),
                                  actions: <Widget>[
                                    TextButton(
                                      onPressed: () {
                                        Navigator.of(ctx).pop();
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.all(14),
                                        child: const Text(
                                          "No",
                                          style: TextStyle(color: Colors.blue),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      onPressed: () {
                                        FirebaseFirestore.instance
                                            .collection('candidates')
                                            .doc(user!.uid)
                                            .update({
                                          'documents': data,
                                          'name': name?.text,
                                          'lastName': lastName?.text,
                                          'active': true,
                                          'verified': 0,
                                          'photo': imageUrl == ''
                                              ? user!.photo_url
                                              : imageUrl
                                        });
                                        Fluttertoast.showToast(
                                            msg: "Update request submitted",
                                            toastLength: Toast.LENGTH_LONG,
                                            gravity: ToastGravity.CENTER,
                                            timeInSecForIosWeb: 1,
                                            backgroundColor: Colors.green,
                                            textColor: Colors.white,
                                            fontSize: 16.0
                                        );
                                        Navigator.pushAndRemoveUntil(context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    BottomBar()), (
                                                route) => false);
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.all(14),
                                        child: const Text(
                                          "Yes",
                                          style: TextStyle(color: Colors.blue),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                          );
                        } else {
                          showUploadMessage(
                              context, 'Please upload all documents');
                        }
                      }else{
                        log('No changes');
                      }
                    },
                    child: Container(
                      height: 40,
                      width: w * 0.3,
                      decoration: BoxDecoration(
                        color:(preName!=name?.text||preLastName!=lastName?.text||preImageUrl!=imageUrl||!mapEquals(preData, data)) ? Colors.green:Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Text(
                          'Update',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              fontSize: 17),
                        ),
                      ),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
