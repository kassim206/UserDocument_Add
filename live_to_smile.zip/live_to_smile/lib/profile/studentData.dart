// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:intl/intl.dart';
// import 'package:live_to_smile/Models/user_model.dart';
// import '../bottom_bar/bottomBar.dart';
// import '../delete_account.dart';
// import '../core/routing/routing.dart';
// import '../feature/authentication/controller/auth_controller.dart';
//
// class StudentData extends ConsumerStatefulWidget {
//   const StudentData({Key? key}) : super(key: key);
//
//   @override
//   ConsumerState<StudentData> createState() => _StudentDataState();
// }
//
// class _StudentDataState extends ConsumerState<StudentData> {
//   UsersModel? user;
//   String course='';
//   String university='';
//   getCourses() async {
//     DocumentSnapshot data =await FirebaseFirestore.instance.collection('course').doc(CurrentUserCourse).get();
//     course=data.get('name');
//     if(mounted){
//
//       setState(() {
//
//       });
//     }
//   }
//   getUniversity() async {
//     DocumentSnapshot data =await FirebaseFirestore.instance.collection('university').doc(CurrentUserUniversity).get();
//     university=data.get('name');
//     if(mounted){
//       setState(() {
//
//       });
//     }
//   }
//
//   @override
//   void initState() {
//     user = ref.read(userProvider);
//
//     getCourses();
//     getUniversity();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // final studentId=ref.read(studentIdProvider);
//     // final currentUserImage=ref.read(currentUserImageProvider);
//     // final currentUserName=ref.read(currentUserNameProvider);
//     // final currentUserPhone=ref.read(currentUserPhoneProvider);
//
//     print(CurrentUserClassId);
//     print(CurrentUserClassId);
//     return Scaffold(
//       body: Column(
//         crossAxisAlignment: CrossAxisAlignment.stretch,
//         children: [
//           Expanded(
//             flex: 2,
//             child: Container(
//               decoration: BoxDecoration(
//                 image: DecorationImage(
//                     image: CachedNetworkImageProvider(user!.photo_url),fit: BoxFit.cover
//                 )
//               ),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: Colors.white.withOpacity(0.8)
//                 ),
//                 child: Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Padding(
//                         padding: const EdgeInsets.only(left: 10.0),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             InkWell(
//                                 onTap: (){
//                                   Navigator.pop(context);
//                                 },
//                                 child: Icon(Icons.arrow_back,color: Colors.black,size: 35,)),
//                             IconButton(onPressed: (){
//                               showDialog(context: context, builder: (buildContext){
//                                 return AlertDialog(
//                                   title: Text('Delete Account?'),
//                                   content: Text('Do you want to Delete Account'),
//                                   actions: [
//                                     TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Cancel')),
//                                     TextButton(onPressed: (){
//                                       Navigator.pop(context);
//
//                                       Navigator.push(context, MaterialPageRoute(builder: (context)=>DeleteAccount()));
//                                     }, child: Text('Ok')),
//                                   ],
//                                 );
//                               });
//                             }, icon: Icon(Icons.delete)) ,
//                           ],
//                         ),
//                       ),
//
//                       Container(
//                         height: w*0.3,
//                         width: w*0.3,
//                         child: Stack(
//                           children: [
//                             Container(
//                               height: w*0.3,
//                               width: w*0.3,
//                               child: Container(
//                                 decoration: BoxDecoration(
//                                     image: DecorationImage(
//                                         image: CachedNetworkImageProvider(user!.photo_url),fit: BoxFit.cover
//                                     ),
//                                     shape: BoxShape.circle
//                                 ),
//                               ),
//                             ),
//                             // Align(
//                             //   alignment: Alignment.bottomRight,
//                             //   child: Bounce(
//                             //     duration: Duration(milliseconds: 110),
//                             //     onPressed: (){
//                             //
//                             //     },
//                             //     child: Container(
//                             //       decoration: BoxDecoration(
//                             //         color: Colors.white,
//                             //         shape: BoxShape.circle,
//                             //         boxShadow: [BoxShadow(blurRadius: 2, color: Color(0xff343434).withOpacity(.10), spreadRadius: 2)],
//                             //       ),
//                             //       child: CircleAvatar(
//                             //         backgroundColor: Colors.white,
//                             //         radius: w*.04,
//                             //         child: SvgPicture.asset('assets/icons/edit.svg'),
//                             //
//                             //       ),
//                             //     ),
//                             //   ),
//                             // ),
//                           ],
//                         ),
//                       ),
//                       Center(
//                         child: Text(user!.display_name,style: GoogleFonts.lexend(
//                             fontSize: w*0.05,fontWeight: FontWeight.w500
//                         ),),
//                       ),
//                       SizedBox(height: w*0.01,),
//                       Center(
//                         child: Text(CurrentUserPlace??"",style: GoogleFonts.lexend(
//                             fontSize: w*0.04,fontWeight: FontWeight.w400
//                         ),),
//                       ),
//                       SizedBox(height: w*0.01,),
//                       Center(
//                         child: Text('Student ID : '+(user!.uid==null?'':'${user!.uid}'),style: GoogleFonts.lexend(
//                             fontSize: w*0.04,fontWeight: FontWeight.w400
//                         ),),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//           Expanded(
//             flex: 3,
//               child: Padding(
//                 padding:  EdgeInsets.all(w*0.05),
//                 child: SingleChildScrollView(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.stretch,
//                     children: [
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text('Course :',style: GoogleFonts.lexend(
//                                 fontSize: 16
//                               ),),
//                               SizedBox(height: w*0.01,),
//                               Text(course,style: GoogleFonts.lexend(
//                                   fontSize: 14,color: Colors.red
//                               ),),
//                             ],
//                           ),
//                           Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text('Year :',style: GoogleFonts.lexend(
//                                   fontSize: 16
//                               ),),
//                               SizedBox(height: w*0.01,),
//                               Text(CurrentUserYear==1?'1st Year':CurrentUserYear==2?'2nd Year':CurrentUserYear==3?'3rd Year':'${CurrentUserYear.toString()}th Year',style: GoogleFonts.lexend(
//                                   fontSize: 14,color: Colors.red
//                               ),),
//                             ],
//                           ),
//                         ],
//                       ),
//
//                      Divider(),
//                       Text('University :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text(university,style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end,),
//                       Divider(),
//                       Text('Class :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${ClassIdToName[CurrentUserClassId]}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       Divider(),
//                       Text('Subjects :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${classMap[CurrentUserClassId]['subject'].toString().substring(1,classMap[CurrentUserClassId]['subject'].toString().length-1)}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       Divider(),
//                       Text('Address :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${CurrentUserAddress}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       Divider(),
//                       Text('Date of birth :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${DateFormat("dd MMM yyyy").format(CurrentUserDob.toDate())}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       Divider(),
//                       Text('Joined date :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${DateFormat("dd MMM yyyy").format(CurrentUserJoined.toDate())}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       // Row(
//                       //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       //   children: [
//                       //     Column(
//                       //       crossAxisAlignment: CrossAxisAlignment.start,
//                       //       children: [
//                       //
//                       //       ],
//                       //     ),
//                       //     // Column(
//                       //     //   crossAxisAlignment: CrossAxisAlignment.start,
//                       //     //   children: [
//                       //     //     Text('Duration :',style: GoogleFonts.lexend(
//                       //     //         fontSize: 16
//                       //     //     ),),
//                       //     //     SizedBox(height: w*0.01,),
//                       //     //     Text(CurrentUserYear==1?'1st Year':CurrentUserYear==2?'2nd Year':CurrentUserYear==3?'3rd Year':'${CurrentUserYear.toString()}th Year',style: GoogleFonts.lexend(
//                       //     //         fontSize: 14,color: Colors.red
//                       //     //     ),),
//                       //     //   ],
//                       //     // ),
//                       //   ],
//                       // ),
//                       Divider(),
//                       Text('Phone number :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${user!.phoneNo}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       Divider(),
//                       Text('Email :',style: GoogleFonts.lexend(
//                           fontSize: 16
//                       ),),
//                       SizedBox(height: w*0.01,),
//                       Text('${user!.email}',style: GoogleFonts.lexend(
//                           fontSize: 14,color: Colors.red
//                       ),textAlign: TextAlign.end),
//                       Divider(),
//                     ],
//                   ),
//                 ),
//               )),
//
//         ],
//       ),
//     );
//   }
// }
