class ZoomAccModel{
  String aToken;
  String email;
  String old;
  String token;
  String token1;

//<editor-fold desc="Data Methods">
  ZoomAccModel({
    required this.aToken,
    required this.email,
    required this.old,
    required this.token,
    required this.token1,
  });


  ZoomAccModel copyWith({
    String? aToken,
    String? email,
    String? old,
    String? token,
    String? token1,
  }) {
    return ZoomAccModel(
      aToken: aToken ?? this.aToken,
      email: email ?? this.email,
      old: old ?? this.old,
      token: token ?? this.token,
      token1: token1 ?? this.token1,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'aToken': this.aToken,
      'email': this.email,
      'old': this.old,
      'token': this.token,
      'token1': this.token1,
    };
  }

  factory ZoomAccModel.fromMap(Map<String, dynamic> map) {
    return ZoomAccModel(
      aToken: map['aToken'] as String,
      email: map['email'] as String,
      old: map['old'] as String,
      token: map['token'] as String,
      token1: map['token1'] as String,
    );
  }

//</editor-fold>
}