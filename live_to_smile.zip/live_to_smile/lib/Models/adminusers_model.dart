class AdminUsersModel {
  bool available;
  String department;
  String display_name;
  String email;
  String image;
  String name;
  String password;
  String phone;
  String photo_url;
  String role;
  String tutorId;
  String userName;

//<editor-fold desc="Data Methods">
  AdminUsersModel({
    required this.available,
    required this.department,
    required this.display_name,
    required this.email,
    required this.image,
    required this.name,
    required this.password,
    required this.phone,
    required this.photo_url,
    required this.role,
    required this.tutorId,
    required this.userName,
  });

  AdminUsersModel copyWith({
    bool? available,
    String? department,
    String? display_name,
    String? email,
    String? image,
    String? name,
    String? password,
    String? phone,
    String? photo_url,
    String? role,
    String? tutorId,
    String? userName,
  }) {
    return AdminUsersModel(
      available: available ?? this.available,
      department: department ?? this.department,
      display_name: display_name ?? this.display_name,
      email: email ?? this.email,
      image: image ?? this.image,
      name: name ?? this.name,
      password: password ?? this.password,
      phone: phone ?? this.phone,
      photo_url: photo_url ?? this.photo_url,
      role: role ?? this.role,
      tutorId: tutorId ?? this.tutorId,
      userName: userName ?? this.userName,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'available': this.available,
      'department': this.department,
      'display_name': this.display_name,
      'email': this.email,
      'image': this.image,
      'name': this.name,
      'password': this.password,
      'phone': this.phone,
      'photo_url': this.photo_url,
      'role': this.role,
      'tutorId': this.tutorId,
      'userName': this.userName,
    };
  }

  factory AdminUsersModel.fromMap(Map<String, dynamic> map) {
    return AdminUsersModel(
      available: map['available'] as bool,
      department: map['department'] as String,
      display_name: map['display_name'] as String,
      email: map['email'] as String,
      image: map['image'] as String,
      name: map['name'] as String,
      password: map['password'] as String,
      phone: map['phone'] as String,
      photo_url: map['photo_url'] as String,
      role: map['role'] as String,
      tutorId: map['tutorId'] as String,
      userName: map['userName'] as String,
    );
  }

//</editor-fold>
}
