class ExpenseModel{
  String amount;
  String branchId;
  DateTime date;
  String particular;
  String user;

//<editor-fold desc="Data Methods">
  ExpenseModel({
    required this.amount,
    required this.branchId,
    required this.date,
    required this.particular,
    required this.user,
  });


  ExpenseModel copyWith({
    String? amount,
    String? branchId,
    DateTime? date,
    String? particular,
    String? user,
  }) {
    return ExpenseModel(
      amount: amount ?? this.amount,
      branchId: branchId ?? this.branchId,
      date: date ?? this.date,
      particular: particular ?? this.particular,
      user: user ?? this.user,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'amount': this.amount,
      'branchId': this.branchId,
      'date': this.date,
      'particular': this.particular,
      'user': this.user,
    };
  }

  factory ExpenseModel.fromMap(Map<String, dynamic> map) {
    return ExpenseModel(
      amount: map['amount'] as String,
      branchId: map['branchId'] as String,
      date: map['date'] as DateTime,
      particular: map['particular'] as String,
      user: map['user'] as String,
    );
  }

}

