class EnquiryModel{
  String additionalInfo;
  String branchId;
  bool check;
  String countryCode;
  String courses;
  DateTime date;
  DateTime dob;
  List educationalDetails;
  String email;
  String enquiryId;
  String mobile;
  String name;
  String phoneCode;
  String place;
  List search;
  int status;
  String university;
  String userEmail;
  String userId;

//<editor-fold desc="Data Methods">
  EnquiryModel({
   required this.additionalInfo,
    required this.branchId,
    required this.check,
    required this.countryCode,
    required this.courses,
    required this.date,
    required this.dob,
    required this.educationalDetails,
    required this.email,
    required this.enquiryId,
    required this.mobile,
    required this.name,
    required this.phoneCode,
    required this.place,
    required this.search,
    required this.status,
    required this.university,
    required this.userEmail,
    required this.userId,
  });

  EnquiryModel copyWith({
    String? additionalInfo,
    String? branchId,
    bool? check,
    String? countryCode,
    String? courses,
    DateTime? date,
    DateTime? dob,
    List? educationalDetails,
    String? email,
    String? enquiryId,
    String? mobile,
    String? name,
    String? phoneCode,
    String? place,
    List? search,
    int? status,
    String? university,
    String? userEmail,
    String? userId,
  }) {
    return EnquiryModel(
      additionalInfo: additionalInfo ?? this.additionalInfo,
      branchId: branchId ?? this.branchId,
      check: check ?? this.check,
      countryCode: countryCode ?? this.countryCode,
      courses: courses ?? this.courses,
      date: date ?? this.date,
      dob: dob ?? this.dob,
      educationalDetails: educationalDetails ?? this.educationalDetails,
      email: email ?? this.email,
      enquiryId: enquiryId ?? this.enquiryId,
      mobile: mobile ?? this.mobile,
      name: name ?? this.name,
      phoneCode: phoneCode ?? this.phoneCode,
      place: place ?? this.place,
      search: search ?? this.search,
      status: status ?? this.status,
      university: university ?? this.university,
      userEmail: userEmail ?? this.userEmail,
      userId: userId ?? this.userId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'additionalInfo': this.additionalInfo,
      'branchId': this.branchId,
      'check': this.check,
      'countryCode': this.countryCode,
      'courses': this.courses,
      'date': this.date,
      'dob': this.dob,
      'educationalDetails': this.educationalDetails,
      'email': this.email,
      'enquiryId': this.enquiryId,
      'mobile': this.mobile,
      'name': this.name,
      'phoneCode': this.phoneCode,
      'place': this.place,
      'search': this.search,
      'status': this.status,
      'university': this.university,
      'userEmail': this.userEmail,
      'userId': this.userId,
    };
  }

  factory EnquiryModel.fromMap(Map<String, dynamic> map) {
    return EnquiryModel(
      additionalInfo: map['additionalInfo'] as String,
      branchId: map['branchId'] as String,
      check: map['check'] as bool,
      countryCode: map['countryCode'] as String,
      courses: map['courses'] as String,
      date: map['date'] as DateTime,
      dob: map['dob'] as DateTime,
      educationalDetails: map['educationalDetails'] as List,
      email: map['email'] as String,
      enquiryId: map['enquiryId'] as String,
      mobile: map['mobile'] as String,
      name: map['name'] as String,
      phoneCode: map['phoneCode'] as String,
      place: map['place'] as String,
      search: map['search'] as List,
      status: map['status'] as int,
      university: map['university'] as String,
      userEmail: map['userEmail'] as String,
      userId: map['userId'] as String,
    );
  }

//</editor-fold>
}