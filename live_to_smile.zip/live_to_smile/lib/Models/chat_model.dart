class chatModel{
  String id;
  String msg;
  String name;
  String photo;
  DateTime time;
  int type;

//<editor-fold desc="Data Methods">
  chatModel({
    required this.id,
    required this.msg,
    required this.name,
    required this.photo,
    required this.time,
    required this.type,
  });

  chatModel copyWith({
    String? id,
    String? msg,
    String? name,
    String? photo,
    DateTime? time,
    int? type,
  }) {
    return chatModel(
      id: id ?? this.id,
      msg: msg ?? this.msg,
      name: name ?? this.name,
      photo: photo ?? this.photo,
      time: time ?? this.time,
      type: type ?? this.type,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': this.id,
      'msg': this.msg,
      'name': this.name,
      'photo': this.photo,
      'time': this.time,
      'type': this.type,
    };
  }

  factory chatModel.fromMap(Map<String, dynamic> map) {
    return chatModel(
      id: map['id'] as String,
      msg: map['msg'] as String,
      name: map['name'] as String,
      photo: map['photo'] as String,
      time: map['time'] as DateTime,
      type: map['type'] as int,
    );
  }

//</editor-fold>
}