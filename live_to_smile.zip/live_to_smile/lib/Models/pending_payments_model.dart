class PendingPayments{
  bool activate;
  String address;
  String branchId;
  String classId;
  String countryCode;
  String course;
  int courseDuration;
  String currentStatus;
  int currentYear;
  DateTime date;
  int discount;
  DateTime dob;
  Map documents;
  DateTime dueDate;
  String eAmount;
  String eCourse;
  DateTime eDate;
  String eIntake;
  String eName;
  String educationalDetails;
  String email;
  String enquiryId;
  List feeDetails;
  int feeIndex;
  List form;
  String gender;
  String inTake;
  String lastName;
  String mobile;
  String name;
  String phoneCode;
  String photo;
  String place;
  String search;
  int status;
  String studentId;
  String university;
  String userId;
  int verified;
  int yearIndex;

//<editor-fold desc="Data Methods">
  PendingPayments({
    required this.activate,
    required this.address,
    required this.branchId,
    required this.classId,
    required this.countryCode,
    required this.course,
    required this.courseDuration,
    required this.currentStatus,
    required this.currentYear,
    required this.date,
    required this.discount,
    required this.dob,
    required this.documents,
    required this.dueDate,
    required this.eAmount,
    required this.eCourse,
    required this.eDate,
    required this.eIntake,
    required this.eName,
    required this.educationalDetails,
    required this.email,
    required this.enquiryId,
    required this.feeDetails,
    required this.feeIndex,
    required this.form,
    required this.gender,
    required this.inTake,
    required this.lastName,
    required this.mobile,
    required this.name,
    required this.phoneCode,
    required this.photo,
    required this.place,
    required this.search,
    required this.status,
    required this.studentId,
    required this.university,
    required this.userId,
    required this.verified,
    required this.yearIndex,
  });
  
  PendingPayments copyWith({
    bool? activate,
    String? address,
    String? branchId,
    String? classId,
    String? countryCode,
    String? course,
    int? courseDuration,
    String? currentStatus,
    int? currentYear,
    DateTime? date,
    int? discount,
    DateTime? dob,
    Map? documents,
    DateTime? dueDate,
    String? eAmount,
    String? eCourse,
    DateTime? eDate,
    String? eIntake,
    String? eName,
    String? educationalDetails,
    String? email,
    String? enquiryId,
    List? feeDetails,
    int? feeIndex,
    List? form,
    String? gender,
    String? inTake,
    String? lastName,
    String? mobile,
    String? name,
    String? phoneCode,
    String? photo,
    String? place,
    String? search,
    int? status,
    String? studentId,
    String? university,
    String? userId,
    int? verified,
    int? yearIndex,
  }) {
    return PendingPayments(
      activate: activate ?? this.activate,
      address: address ?? this.address,
      branchId: branchId ?? this.branchId,
      classId: classId ?? this.classId,
      countryCode: countryCode ?? this.countryCode,
      course: course ?? this.course,
      courseDuration: courseDuration ?? this.courseDuration,
      currentStatus: currentStatus ?? this.currentStatus,
      currentYear: currentYear ?? this.currentYear,
      date: date ?? this.date,
      discount: discount ?? this.discount,
      dob: dob ?? this.dob,
      documents: documents ?? this.documents,
      dueDate: dueDate ?? this.dueDate,
      eAmount: eAmount ?? this.eAmount,
      eCourse: eCourse ?? this.eCourse,
      eDate: eDate ?? this.eDate,
      eIntake: eIntake ?? this.eIntake,
      eName: eName ?? this.eName,
      educationalDetails: educationalDetails ?? this.educationalDetails,
      email: email ?? this.email,
      enquiryId: enquiryId ?? this.enquiryId,
      feeDetails: feeDetails ?? this.feeDetails,
      feeIndex: feeIndex ?? this.feeIndex,
      form: form ?? this.form,
      gender: gender ?? this.gender,
      inTake: inTake ?? this.inTake,
      lastName: lastName ?? this.lastName,
      mobile: mobile ?? this.mobile,
      name: name ?? this.name,
      phoneCode: phoneCode ?? this.phoneCode,
      photo: photo ?? this.photo,
      place: place ?? this.place,
      search: search ?? this.search,
      status: status ?? this.status,
      studentId: studentId ?? this.studentId,
      university: university ?? this.university,
      userId: userId ?? this.userId,
      verified: verified ?? this.verified,
      yearIndex: yearIndex ?? this.yearIndex,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'activate': this.activate,
      'address': this.address,
      'branchId': this.branchId,
      'classId': this.classId,
      'countryCode': this.countryCode,
      'course': this.course,
      'courseDuration': this.courseDuration,
      'currentStatus': this.currentStatus,
      'currentYear': this.currentYear,
      'date': this.date,
      'discount': this.discount,
      'dob': this.dob,
      'documents': this.documents,
      'dueDate': this.dueDate,
      'eAmount': this.eAmount,
      'eCourse': this.eCourse,
      'eDate': this.eDate,
      'eIntake': this.eIntake,
      'eName': this.eName,
      'educationalDetails': this.educationalDetails,
      'email': this.email,
      'enquiryId': this.enquiryId,
      'feeDetails': this.feeDetails,
      'feeIndex': this.feeIndex,
      'form': this.form,
      'gender': this.gender,
      'inTake': this.inTake,
      'lastName': this.lastName,
      'mobile': this.mobile,
      'name': this.name,
      'phoneCode': this.phoneCode,
      'photo': this.photo,
      'place': this.place,
      'search': this.search,
      'status': this.status,
      'studentId': this.studentId,
      'university': this.university,
      'userId': this.userId,
      'verified': this.verified,
      'yearIndex': this.yearIndex,
    };
  }

  factory PendingPayments.fromMap(Map<String, dynamic> map) {
    return PendingPayments(
      activate: map['activate'] as bool,
      address: map['address'] as String,
      branchId: map['branchId'] as String,
      classId: map['classId'] as String,
      countryCode: map['countryCode'] as String,
      course: map['course'] as String,
      courseDuration: map['courseDuration'] as int,
      currentStatus: map['currentStatus'] as String,
      currentYear: map['currentYear'] as int,
      date: map['date'] as DateTime,
      discount: map['discount'] as int,
      dob: map['dob'] as DateTime,
      documents: map['documents'] as Map,
      dueDate: map['dueDate'] as DateTime,
      eAmount: map['eAmount'] as String,
      eCourse: map['eCourse'] as String,
      eDate: map['eDate'] as DateTime,
      eIntake: map['eIntake'] as String,
      eName: map['eName'] as String,
      educationalDetails: map['educationalDetails'] as String,
      email: map['email'] as String,
      enquiryId: map['enquiryId'] as String,
      feeDetails: map['feeDetails'] as List,
      feeIndex: map['feeIndex'] as int,
      form: map['form'] as List,
      gender: map['gender'] as String,
      inTake: map['inTake'] as String,
      lastName: map['lastName'] as String,
      mobile: map['mobile'] as String,
      name: map['name'] as String,
      phoneCode: map['phoneCode'] as String,
      photo: map['photo'] as String,
      place: map['place'] as String,
      search: map['search'] as String,
      status: map['status'] as int,
      studentId: map['studentId'] as String,
      university: map['university'] as String,
      userId: map['userId'] as String,
      verified: map['verified'] as int,
      yearIndex: map['yearIndex'] as int,
    );
  }

//</editor-fold>
}