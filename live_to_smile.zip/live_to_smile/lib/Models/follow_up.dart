class FollowUpModel{
  String branchId;
  DateTime date;
  bool done;
  String eId;
  String id;
  String name;
  DateTime next;
  int rating;
  String status;
  String userId;

//<editor-fold desc="Data Methods">
  FollowUpModel({
    required this.branchId,
    required this.date,
    required this.done,
    required this.eId,
    required this.id,
    required this.name,
    required this.next,
    required this.rating,
    required this.status,
    required this.userId,
  });


  FollowUpModel copyWith({
    String? branchId,
    DateTime? date,
    bool? done,
    String? eId,
    String? id,
    String? name,
    DateTime? next,
    int? rating,
    String? status,
    String? userId,
  }) {
    return FollowUpModel(
      branchId: branchId ?? this.branchId,
      date: date ?? this.date,
      done: done ?? this.done,
      eId: eId ?? this.eId,
      id: id ?? this.id,
      name: name ?? this.name,
      next: next ?? this.next,
      rating: rating ?? this.rating,
      status: status ?? this.status,
      userId: userId ?? this.userId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'branchId': this.branchId,
      'date': this.date,
      'done': this.done,
      'eId': this.eId,
      'id': this.id,
      'name': this.name,
      'next': this.next,
      'rating': this.rating,
      'status': this.status,
      'userId': this.userId,
    };
  }

  factory FollowUpModel.fromMap(Map<String, dynamic> map) {
    return FollowUpModel(
      branchId: map['branchId'] as String,
      date: map['date'] as DateTime,
      done: map['done'] as bool,
      eId: map['eId'] as String,
      id: map['id'] as String,
      name: map['name'] as String,
      next: map['next'] as DateTime,
      rating: map['rating'] as int,
      status: map['status'] as String,
      userId: map['userId'] as String,
    );
  }

//</editor-fold>
}