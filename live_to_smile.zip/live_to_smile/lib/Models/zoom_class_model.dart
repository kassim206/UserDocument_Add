class ZoomClassModel{
List attendance;
String batch;
String course;
DateTime date;
String description;
List documents;
String email;
String join_url;
int meetingId;
String name;
List notes;
List played;
DateTime scheduled;
List search;
bool start;
String start_url;
int status;
String subject;
String token;
String tutor;
String userId;
String zoomClsId;

//<editor-fold desc="Data Methods">
  ZoomClassModel({
    required this.attendance,
    required this.batch,
    required this.course,
    required this.date,
    required this.description,
    required this.documents,
    required this.email,
    required this.join_url,
    required this.meetingId,
    required this.name,
    required this.notes,
    required this.played,
    required this.scheduled,
    required this.search,
    required this.start,
    required this.start_url,
    required this.status,
    required this.subject,
    required this.token,
    required this.tutor,
    required this.userId,
    required this.zoomClsId,
  });
  
  ZoomClassModel copyWith({
    List? attendance,
    String? batch,
    String? course,
    DateTime? date,
    String? description,
    List? documents,
    String? email,
    String? join_url,
    int? meetingId,
    String? name,
    List? notes,
    List? played,
    DateTime? scheduled,
    List? search,
    bool? start,
    String? start_url,
    int? status,
    String? subject,
    String? token,
    String? tutor,
    String? userId,
    String? zoomClsId,
  }) {
    return ZoomClassModel(
      attendance: attendance ?? this.attendance,
      batch: batch ?? this.batch,
      course: course ?? this.course,
      date: date ?? this.date,
      description: description ?? this.description,
      documents: documents ?? this.documents,
      email: email ?? this.email,
      join_url: join_url ?? this.join_url,
      meetingId: meetingId ?? this.meetingId,
      name: name ?? this.name,
      notes: notes ?? this.notes,
      played: played ?? this.played,
      scheduled: scheduled ?? this.scheduled,
      search: search ?? this.search,
      start: start ?? this.start,
      start_url: start_url ?? this.start_url,
      status: status ?? this.status,
      subject: subject ?? this.subject,
      token: token ?? this.token,
      tutor: tutor ?? this.tutor,
      userId: userId ?? this.userId,
      zoomClsId: zoomClsId ?? this.zoomClsId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'attendance': this.attendance,
      'batch': this.batch,
      'course': this.course,
      'date': this.date,
      'description': this.description,
      'documents': this.documents,
      'email': this.email,
      'join_url': this.join_url,
      'meetingId': this.meetingId,
      'name': this.name,
      'notes': this.notes,
      'played': this.played,
      'scheduled': this.scheduled,
      'search': this.search,
      'start': this.start,
      'start_url': this.start_url,
      'status': this.status,
      'subject': this.subject,
      'token': this.token,
      'tutor': this.tutor,
      'userId': this.userId,
      'zoomClsId': this.zoomClsId,
    };
  }

  factory ZoomClassModel.fromMap(Map<String, dynamic> map) {
    return ZoomClassModel(
      attendance: map['attendance'] as List,
      batch: map['batch'] as String,
      course: map['course'] as String,
      date: map['date'] as DateTime,
      description: map['description'] as String,
      documents: map['documents'] as List,
      email: map['email'] as String,
      join_url: map['join_url'] as String,
      meetingId: map['meetingId'] as int,
      name: map['name'] as String,
      notes: map['notes'] as List,
      played: map['played'] as List,
      scheduled: map['scheduled'] as DateTime,
      search: map['search'] as List,
      start: map['start'] as bool,
      start_url: map['start_url'] as String,
      status: map['status'] as int,
      subject: map['subject'] as String,
      token: map['token'] as String,
      tutor: map['tutor'] as String,
      userId: map['userId'] as String,
      zoomClsId: map['zoomClsId'] as String,
    );
  }

//</editor-fold>
}