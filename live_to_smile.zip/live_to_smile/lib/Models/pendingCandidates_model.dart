class pendingCandidatesModel{
  bool active;
  String address;
  String branchId;
  String classDoc;
  String classId;
  String countryCode;
  String course;
  int courseDuration;
  String currentStatus;
  int currentYear;
  DateTime date;
  int discount;
  DateTime dob;
  Map<String, dynamic> documents;
  DateTime dueDate;
  List educationalDetails;
  String email;
  String emailC;
  String emailI;
  String emailN;
  String enquiryDoc;
  String? enquiryId;
  List feeDetails;
  List form;
  String gender;
  String inTake;
  String lastName;
  String mobile;
  String name;
  String phoneCode;
  String photo;
  String place;
  String scholarship;
  List search;
  int status;
  String studentId;
  String university;
  String userId;
  int verified;


//<editor-fold desc="Data Methods">


  pendingCandidatesModel({
    required this.active,
    required this.address,
    required this.branchId,
    required this.classDoc,
    required this.classId,
    required this.countryCode,
    required this.course,
    required this.courseDuration,
    required this.currentStatus,
    required this.currentYear,
    required this.date,
    required this.discount,
    required this.dob,
    required this.documents,
    required this.dueDate,
    required this.educationalDetails,
    required this.email,
    required this.emailC,
    required this.emailI,
    required this.emailN,
    required this.enquiryDoc,
    this.enquiryId,
    required this.feeDetails,
    required this.form,
    required this.gender,
    required this.inTake,
    required this.lastName,
    required this.mobile,
    required this.name,
    required this.phoneCode,
    required this.photo,
    required this.place,
    required this.scholarship,
    required this.search,
    required this.status,
    required this.studentId,
    required this.university,
    required this.userId,
    required this.verified,
  });

  pendingCandidatesModel copyWith({
    bool? active,
    String? address,
    String? branchId,
    String? classDoc,
    String? classId,
    String? countryCode,
    String? course,
    int? courseDuration,
    String? currentStatus,
    int? currentYear,
    DateTime? date,
    int? discount,
    DateTime? dob,
    Map<String, dynamic>? documents,
    DateTime? dueDate,
    List? educationalDetails,
    String? email,
    String? emailC,
    String? emailI,
    String? emailN,
    String? enquiryDoc,
    String? enquiryId,
    List? feeDetails,
    List? form,
    String? gender,
    String? inTake,
    String? lastName,
    String? mobile,
    String? name,
    String? phoneCode,
    String? photo,
    String? place,
    String? scholarship,
    List? search,
    int? status,
    String? studentId,
    String? university,
    String? userId,
    int? verified,
  }) {
    return pendingCandidatesModel(
      active: active ?? this.active,
      address: address ?? this.address,
      branchId: branchId ?? this.branchId,
      classDoc: classDoc ?? this.classDoc,
      classId: classId ?? this.classId,
      countryCode: countryCode ?? this.countryCode,
      course: course ?? this.course,
      courseDuration: courseDuration ?? this.courseDuration,
      currentStatus: currentStatus ?? this.currentStatus,
      currentYear: currentYear ?? this.currentYear,
      date: date ?? this.date,
      discount: discount ?? this.discount,
      dob: dob ?? this.dob,
      documents: documents ?? this.documents,
      dueDate: dueDate ?? this.dueDate,
      educationalDetails: educationalDetails ?? this.educationalDetails,
      email: email ?? this.email,
      emailC: emailC ?? this.emailC,
      emailI: emailI ?? this.emailI,
      emailN: emailN ?? this.emailN,
      enquiryDoc: enquiryDoc ?? this.enquiryDoc,
      enquiryId: enquiryId ?? this.enquiryId,
      feeDetails: feeDetails ?? this.feeDetails,
      form: form ?? this.form,
      gender: gender ?? this.gender,
      inTake: inTake ?? this.inTake,
      lastName: lastName ?? this.lastName,
      mobile: mobile ?? this.mobile,
      name: name ?? this.name,
      phoneCode: phoneCode ?? this.phoneCode,
      photo: photo ?? this.photo,
      place: place ?? this.place,
      scholarship: scholarship ?? this.scholarship,
      search: search ?? this.search,
      status: status ?? this.status,
      studentId: studentId ?? this.studentId,
      university: university ?? this.university,
      userId: userId ?? this.userId,
      verified: verified ?? this.verified,
    );
  }


  Map<String, dynamic> toMap() {
    return {
      'active': this.active,
      'address': this.address,
      'branchId': this.branchId,
      'classDoc': this.classDoc,
      'classId': this.classId,
      'countryCode': this.countryCode,
      'course': this.course,
      'courseDuration': this.courseDuration,
      'currentStatus': this.currentStatus,
      'currentYear': this.currentYear,
      'date': this.date,
      'discount': this.discount,
      'dob': this.dob,
      'documents': this.documents,
      'dueDate': this.dueDate,
      'educationalDetails': this.educationalDetails,
      'email': this.email,
      'emailC': this.emailC,
      'emailI': this.emailI,
      'emailN': this.emailN,
      'enquiryDoc': this.enquiryDoc,
      'enquiryId': this.enquiryId,
      'feeDetails': this.feeDetails,
      'form': this.form,
      'gender': this.gender,
      'inTake': this.inTake,
      'lastName': this.lastName,
      'mobile': this.mobile,
      'name': this.name,
      'phoneCode': this.phoneCode,
      'photo': this.photo,
      'place': this.place,
      'scholarship': this.scholarship,
      'search': this.search,
      'status': this.status,
      'studentId': this.studentId,
      'university': this.university,
      'userId': this.userId,
      'verified': this.verified,
    };
  }

  factory pendingCandidatesModel.fromMap(Map<String, dynamic> map) {
    return pendingCandidatesModel(
      active: map['active'] as bool,
      address: map['address'] as String,
      branchId: map['branchId'] as String,
      classDoc: map['classDoc'] as String,
      classId: map['classId'] as String,
      countryCode: map['countryCode'] as String,
      course: map['course'] as String,
      courseDuration: map['courseDuration'] as int,
      currentStatus: map['currentStatus'] as String,
      currentYear: map['currentYear'] as int,
      date: map['date'] as DateTime,
      discount: map['discount'] as int,
      dob: map['dob'] as DateTime,
      documents: map['documents'] as Map<String, dynamic>,
      dueDate: map['dueDate'] as DateTime,
      educationalDetails: map['educationalDetails'] as List,
      email: map['email'] as String,
      emailC: map['emailC'] as String,
      emailI: map['emailI'] as String,
      emailN: map['emailN'] as String,
      enquiryDoc: map['enquiryDoc'] as String,
      enquiryId: map['enquiryId'] as String,
      feeDetails: map['feeDetails'] as List,
      form: map['form'] as List,
      gender: map['gender'] as String,
      inTake: map['inTake'] as String,
      lastName: map['lastName'] as String,
      mobile: map['mobile'] as String,
      name: map['name'] as String,
      phoneCode: map['phoneCode'] as String,
      photo: map['photo'] as String,
      place: map['place'] as String,
      scholarship: map['scholarship'] as String,
      search: map['search'] as List,
      status: map['status'] as int,
      studentId: map['studentId'] as String,
      university: map['university'] as String,
      userId: map['userId'] as String,
      verified: map['verified'] as int,
    );
  }


//</editor-fold>
}