class classModel{
  bool available;
  String course;
  DateTime date;
  String description;
  String id;
  String inTake;
  String name;
  String university;
  List<String> students;
  List<String> subject;
  List<String> tutors;

//<editor-fold desc="Data Methods">
  classModel({
    required this.available,
    required this.course,
    required this.date,
    required this.description,
    required this.id,
    required this.inTake,
    required this.name,
    required this.university,
    required this.students,
    required this.subject,
    required this.tutors,
  });

  classModel copyWith({
    bool? available,
    String? course,
    DateTime? date,
    String? description,
    String? id,
    String? inTake,
    String? name,
    String? university,
    List<String>? students,
    List<String>? subject,
    List<String>? tutors,
  }) {
    return classModel(
      available: available ?? this.available,
      course: course ?? this.course,
      date: date ?? this.date,
      description: description ?? this.description,
      id: id ?? this.id,
      inTake: inTake ?? this.inTake,
      name: name ?? this.name,
      university: university ?? this.university,
      students: students ?? this.students,
      subject: subject ?? this.subject,
      tutors: tutors ?? this.tutors,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'available': this.available,
      'course': this.course,
      'date': this.date,
      'description': this.description,
      'id': this.id,
      'inTake': this.inTake,
      'name': this.name,
      'university': this.university,
      'students': this.students,
      'subject': this.subject,
      'tutors': this.tutors,
    };
  }

  factory classModel.fromMap(Map<String, dynamic> map) {
    return classModel(
      available: map['available'] as bool,
      course: map['course'] as String,
      date: map['date'] as DateTime,
      description: map['description'] as String,
      id: map['id'] as String,
      inTake: map['inTake'] as String,
      name: map['name'] as String,
      university: map['university'] as String,
      students: map['students'] as List<String>,
      subject: map['subject'] as List<String>,
      tutors: map['tutors'] as List<String>,
    );
  }

//</editor-fold>
}