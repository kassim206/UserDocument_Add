class ZoomClass1Model{
  List attendance;
  String batch;
  DateTime date;
  String join_url;
  int meetingId;
  String start_url;

//<editor-fold desc="Data Methods">
  ZoomClass1Model({
    required this.attendance,
    required this.batch,
    required this.date,
    required this.join_url,
    required this.meetingId,
    required this.start_url,
  });

  ZoomClass1Model copyWith({
    List? attendance,
    String? batch,
    DateTime? date,
    String? join_url,
    int? meetingId,
    String? start_url,
  }) {
    return ZoomClass1Model(
      attendance: attendance ?? this.attendance,
      batch: batch ?? this.batch,
      date: date ?? this.date,
      join_url: join_url ?? this.join_url,
      meetingId: meetingId ?? this.meetingId,
      start_url: start_url ?? this.start_url,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'attendance': this.attendance,
      'batch': this.batch,
      'date': this.date,
      'join_url': this.join_url,
      'meetingId': this.meetingId,
      'start_url': this.start_url,
    };
  }

  factory ZoomClass1Model.fromMap(Map<String, dynamic> map) {
    return ZoomClass1Model(
      attendance: map['attendance'] as List,
      batch: map['batch'] as String,
      date: map['date'] as DateTime,
      join_url: map['join_url'] as String,
      meetingId: map['meetingId'] as int,
      start_url: map['start_url'] as String,
    );
  }

//</editor-fold>
}