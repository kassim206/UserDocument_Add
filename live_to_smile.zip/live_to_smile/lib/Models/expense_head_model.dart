class ExpenseHeadModel{
  List<String> expenseHead;

//<editor-fold desc="Data Methods">
  ExpenseHeadModel({
    required this.expenseHead,
  });

  ExpenseHeadModel copyWith({
    List<String>? expenseHead,
  }) {
    return ExpenseHeadModel(
      expenseHead: expenseHead ?? this.expenseHead,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'expenseHead': this.expenseHead,
    };
  }

  factory ExpenseHeadModel.fromMap(Map<String, dynamic> map) {
    return ExpenseHeadModel(
      expenseHead: map['expenseHead'] as List<String>,
    );
  }

//</editor-fold>
}