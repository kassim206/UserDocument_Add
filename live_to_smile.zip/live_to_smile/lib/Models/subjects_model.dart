class subjectsModel{
  String name;

//<editor-fold desc="Data Methods">
  subjectsModel({
    required this.name,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is subjectsModel &&
          runtimeType == other.runtimeType &&
          name == other.name);

  @override
  int get hashCode => name.hashCode;

  @override
  String toString() {
    return 'subjectsModel{' + ' name: $name,' + '}';
  }

  subjectsModel copyWith({
    String? name,
  }) {
    return subjectsModel(
      name: name ?? this.name,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': this.name,
    };
  }

  factory subjectsModel.fromMap(Map<String, dynamic> map) {
    return subjectsModel(
      name: map['name'] as String,
    );
  }

//</editor-fold>
}