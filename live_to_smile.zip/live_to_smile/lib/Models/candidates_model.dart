CandidatesModel? candidatesModel;

class CandidatesModel {
  bool active;
  String adress;
  String branchId;
  String classId;
  String countrycode;
  String course;
  int courseDuration;
  String currentStatus;
  int currentYear;
  DateTime date;
  int discount;
  DateTime dob;
  Map documents;
  List educationalDetails;
  String email;
  String? enquiryId;
  List feeDetails;
  List form;
  String gender;
  String inTake;
  String lastName;
  String mobile;
  String name;
  String phoneCode;
  String photo;
  String place;

  int status;
  String studentId;
  String university;
  String userId;
  int verified;

//<editor-fold desc="Data Methods">
  CandidatesModel({
    required this.active,
    required this.adress,
    required this.branchId,
    required this.classId,
    required this.countrycode,
    required this.course,
    required this.courseDuration,
    required this.currentStatus,
    required this.currentYear,
    required this.date,
    required this.discount,
    required this.dob,
    required this.documents,
    required this.educationalDetails,
    required this.email,
    this.enquiryId,
    required this.feeDetails,
    required this.form,
    required this.gender,
    required this.inTake,
    required this.lastName,
    required this.mobile,
    required this.name,
    required this.phoneCode,
    required this.photo,
    required this.place,
    required this.status,
    required this.studentId,
    required this.university,
    required this.userId,
    required this.verified,
  });

  CandidatesModel copyWith({
    bool? active,
    String? adress,
    String? branchId,
    String? classId,
    String? countrycode,
    String? course,
    int? courseDuration,
    String? currentStatus,
    int? currentYear,
    DateTime? date,
    int? discount,
    DateTime? dob,
    Map? documents,
    List? educationalDetails,
    String? email,
    String? enquiryId,
    List? feeDetails,
    List? form,
    String? gender,
    String? inTake,
    String? lastName,
    String? mobile,
    String? name,
    String? phoneCode,
    String? photo,
    String? place,
    String? scholarship,
    int? status,
    String? studentId,
    String? university,
    String? userId,
    int? verified,
  }) {
    return CandidatesModel(
      active: active ?? this.active,
      adress: adress ?? this.adress,
      branchId: branchId ?? this.branchId,
      classId: classId ?? this.classId,
      countrycode: countrycode ?? this.countrycode,
      course: course ?? this.course,
      courseDuration: courseDuration ?? this.courseDuration,
      currentStatus: currentStatus ?? this.currentStatus,
      currentYear: currentYear ?? this.currentYear,
      date: date ?? this.date,
      discount: discount ?? this.discount,
      dob: dob ?? this.dob,
      documents: documents ?? this.documents,
      educationalDetails: educationalDetails ?? this.educationalDetails,
      email: email ?? this.email,
      enquiryId: enquiryId ?? this.enquiryId,
      feeDetails: feeDetails ?? this.feeDetails,
      form: form ?? this.form,
      gender: gender ?? this.gender,
      inTake: inTake ?? this.inTake,
      lastName: lastName ?? this.lastName,
      mobile: mobile ?? this.mobile,
      name: name ?? this.name,
      phoneCode: phoneCode ?? this.phoneCode,
      photo: photo ?? this.photo,
      place: place ?? this.place,
      status: status ?? this.status,
      studentId: studentId ?? this.studentId,
      university: university ?? this.university,
      userId: userId ?? this.userId,
      verified: verified ?? this.verified,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'active': this.active,
      'address': this.adress,
      'branchId': this.branchId,
      'classId': this.classId,
      'countryCode': this.countrycode,
      'course': this.course,
      'courseDuration': this.courseDuration,
      'currentStatus': this.currentStatus,
      'currentYear': this.currentYear,
      'date': this.date,
      'discount': this.discount,
      'dob': this.dob,
      'documents': this.documents,
      'educationalDetails': this.educationalDetails,
      'email': this.email,
      'enquiryId': this.enquiryId,
      'feeDetails': this.feeDetails,
      'form': this.form,
      'gender': this.gender,
      'inTake': this.inTake,
      'lastName': this.lastName,
      'mobile': this.mobile,
      'name': this.name,
      'phoneCode': this.phoneCode,
      'photo': this.photo,
      'place': this.place,
      'status': this.status,
      'studentId': this.studentId,
      'university': this.university,
      'userId': this.userId,
      'verified': this.verified,
    };
  }

  factory CandidatesModel.fromMap(Map<String, dynamic> map) {
    return CandidatesModel(
      active: map['active'] as bool,
      adress: map['address'] as String,
      branchId: map['branchId'] as String,
      classId: map['classId'] as String,
      countrycode: map['countryCode'] as String,
      course: map['course'] as String,
      courseDuration: map['courseDuration'] as int,
      currentStatus: map['currentStatus'] as String,
      currentYear: map['currentYear'] as int,
      date: map['date'].toDate() ?? DateTime.now(),
      discount: map['discount'] as int,
      dob: map['dob'].toDate() ?? DateTime.now(),
      documents: map['documents'] as Map,
      educationalDetails: map['educationalDetails'] as List,
      email: map['email'] as String,
      enquiryId: map['enquiryId'] as String,
      feeDetails: map['feeDetails'] as List,
      form: map['form'] as List,
      gender: map['gender'] as String,
      inTake: map['inTake'] as String,
      lastName: map['lastName'] as String,
      mobile: map['mobile'] as String,
      name: map['name'] as String,
      phoneCode: map['phoneCode'] as String,
      photo: map['photo'] as String,
      place: map['place'] as String,
      status: map['status'] as int,
      studentId: map['studentId'] as String,
      university: map['university'] as String,
      userId: map['userId'] as String,
      verified: map['verified'] as int,
    );
  }

//</editor-fold>
}
