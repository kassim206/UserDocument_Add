class TutorModel{
  bool available;
  String department;
  String email;
  String image;
  String name;
  String password;
  String phone;
  String tutorId;
  String userName;

//<editor-fold desc="Data Methods">
  TutorModel({
    required this.available,
    required this.department,
    required this.email,
    required this.image,
    required this.name,
    required this.password,
    required this.phone,
    required this.tutorId,
    required this.userName,
  });


  TutorModel copyWith({
    bool? available,
    String? department,
    String? email,
    String? image,
    String? name,
    String? password,
    String? phone,
    String? tutorId,
    String? userName,
  }) {
    return TutorModel(
      available: available ?? this.available,
      department: department ?? this.department,
      email: email ?? this.email,
      image: image ?? this.image,
      name: name ?? this.name,
      password: password ?? this.password,
      phone: phone ?? this.phone,
      tutorId: tutorId ?? this.tutorId,
      userName: userName ?? this.userName,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'available': this.available,
      'department': this.department,
      'email': this.email,
      'image': this.image,
      'name': this.name,
      'password': this.password,
      'phone': this.phone,
      'tutorId': this.tutorId,
      'userName': this.userName,
    };
  }

  factory TutorModel.fromMap(Map<String, dynamic> map) {
    return TutorModel(
      available: map['available'] as bool,
      department: map['department'] as String,
      email: map['email'] as String,
      image: map['image'] as String,
      name: map['name'] as String,
      password: map['password'] as String,
      phone: map['phone'] as String,
      tutorId: map['tutorId'] as String,
      userName: map['userName'] as String,
    );
  }

//</editor-fold>
}