import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationModel{
  Timestamp date;
  String id;
  List list;
  String message;
  String title;
  String type;
  String userId;
  List view;

//<editor-fold desc="Data Methods">
  NotificationModel({
    required this.date,
    required this.id,
    required this.list,
    required this.message,
    required this.title,
    required this.type,
    required this.userId,
    required this.view,
  });


  NotificationModel copyWith({
    Timestamp? date,
    String? id,
    List? list,
    String? message,
    String? title,
    String? type,
    String? userId,
    List? view,
  }) {
    return NotificationModel(
      date: date ?? this.date,
      id: id ?? this.id,
      list: list ?? this.list,
      message: message ?? this.message,
      title: title ?? this.title,
      type: type ?? this.type,
      userId: userId ?? this.userId,
      view: view ?? this.view,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'date': this.date,
      'id': this.id,
      'list': this.list,
      'message': this.message,
      'title': this.title,
      'type': this.type,
      'userId': this.userId,
      'view': this.view,
    };
  }

  factory NotificationModel.fromMap(Map<String, dynamic> map) {
    return NotificationModel(
      date: map['date'] as Timestamp,
      id: map['id'] as String,
      list: map['list'] as List,
      message: map['message'] as String,
      title: map['title'] as String,
      type: map['type'] as String,
      userId: map['userId'] as String,
      view: map['view'] as List,
    );
  }

//</editor-fold>
}