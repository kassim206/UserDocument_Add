

class BranchModel{
  String adress;
  String branchId;
  String email;
  String name;
  List search;
  String shortName;
  List staff;
  String wNumber;

//<editor-fold desc="Data Methods">
  BranchModel({
    required this.adress,
    required this.branchId,
    required this.email,
    required this.name,
    required this.search,
    required this.shortName,
    required this.staff,
    required this.wNumber,
  });



  BranchModel copyWith({
    String? adress,
    String? branchId,
    String? email,
    String? name,
    List? search,
    String? shortName,
    List? staff,
    String? wNumber,
  }) {
    return BranchModel(
      adress: adress ?? this.adress,
      branchId: branchId ?? this.branchId,
      email: email ?? this.email,
      name: name ?? this.name,
      search: search ?? this.search,
      shortName: shortName ?? this.shortName,
      staff: staff ?? this.staff,
      wNumber: wNumber ?? this.wNumber,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'adress': this.adress,
      'branchId': this.branchId,
      'email': this.email,
      'name': this.name,
      'search': this.search,
      'shortName': this.shortName,
      'staff': this.staff,
      'wNumber': this.wNumber,
    };
  }

  factory BranchModel.fromMap(Map<String, dynamic> map) {
    return BranchModel(
      adress: map['adress'] as String,
      branchId: map['branchId'] as String,
      email: map['email'] as String,
      name: map['name'] as String,
      search: map['search'] as List,
      shortName: map['shortName'] as String,
      staff: map['staff'] as List,
      wNumber: map['wNumber'] as String,
    );
  }

//</editor-fold>
}