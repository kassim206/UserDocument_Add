class mailModel{
  DateTime date;
  List<String> emailList;
  String html;
  String status;

//<editor-fold desc="Data Methods">
  mailModel({
    required this.date,
    required this.emailList,
    required this.html,
    required this.status,
  });

  mailModel copyWith({
    DateTime? date,
    List<String>? emailList,
    String? html,
    String? status,
  }) {
    return mailModel(
      date: date ?? this.date,
      emailList: emailList ?? this.emailList,
      html: html ?? this.html,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'date': this.date,
      'emailList': this.emailList,
      'html': this.html,
      'status': this.status,
    };
  }

  factory mailModel.fromMap(Map<String, dynamic> map) {
    return mailModel(
      date: map['date'] as DateTime,
      emailList: map['emailList'] as List<String>,
      html: map['html'] as String,
      status: map['status'] as String,
    );
  }

//</editor-fold>
}