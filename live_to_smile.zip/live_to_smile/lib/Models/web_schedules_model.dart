class webSchedulesDart{
  Map data;
  Map header;

//<editor-fold desc="Data Methods">
  webSchedulesDart({
    required this.data,
    required this.header,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is webSchedulesDart &&
          runtimeType == other.runtimeType &&
          data == other.data &&
          header == other.header);

  @override
  int get hashCode => data.hashCode ^ header.hashCode;

  @override
  String toString() {
    return 'webSchedulesDart{' + ' data: $data,' + ' header: $header,' + '}';
  }

  webSchedulesDart copyWith({
    Map? data,
    Map? header,
  }) {
    return webSchedulesDart(
      data: data ?? this.data,
      header: header ?? this.header,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'data': this.data,
      'header': this.header,
    };
  }

  factory webSchedulesDart.fromMap(Map<String, dynamic> map) {
    return webSchedulesDart(
      data: map['data'] as Map,
      header: map['header'] as Map,
    );
  }

//</editor-fold>
}