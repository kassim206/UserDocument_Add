class intakesModel{
  bool available;
  DateTime created_date;
  DateTime end;
  DateTime intake;
  String intakeId;
  String intakeName;
  String userEmail;
  String userId;

//<editor-fold desc="Data Methods">
  intakesModel({
    required this.available,
    required this.created_date,
    required this.end,
    required this.intake,
    required this.intakeId,
    required this.intakeName,
    required this.userEmail,
    required this.userId,
  });

  intakesModel copyWith({
    bool? available,
    DateTime? created_date,
    DateTime? end,
    DateTime? intake,
    String? intakeId,
    String? intakeName,
    String? userEmail,
    String? userId,
  }) {
    return intakesModel(
      available: available ?? this.available,
      created_date: created_date ?? this.created_date,
      end: end ?? this.end,
      intake: intake ?? this.intake,
      intakeId: intakeId ?? this.intakeId,
      intakeName: intakeName ?? this.intakeName,
      userEmail: userEmail ?? this.userEmail,
      userId: userId ?? this.userId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'available': this.available,
      'created_date': this.created_date,
      'end': this.end,
      'intake': this.intake,
      'intakeId': this.intakeId,
      'intakeName': this.intakeName,
      'userEmail': this.userEmail,
      'userId': this.userId,
    };
  }

  factory intakesModel.fromMap(Map<String, dynamic> map) {
    return intakesModel(
      available: map['available'] as bool,
      created_date: map['created_date'] as DateTime,
      end: map['end'] as DateTime,
      intake: map['intake'] as DateTime,
      intakeId: map['intakeId'] as String,
      intakeName: map['intakeName'] as String,
      userEmail: map['userEmail'] as String,
      userId: map['userId'] as String,
    );
  }

//</editor-fold>
}