class SettingsModel {
  int? batch;
  String? branchId;
  int? classNo;
  int? courseNo;
  bool? demo;
  List? department;
  String? email;
  int? enquiryId;
  int? image;
  String? number;
  int? orderNo;
  int? receptionNo;
  int? studentId;
  String? token;
  int? tutorNo;
  int? unversityNo;
  int? userId;
  String? version;
  String? versionERP;
  String? wNumber;

//<editor-fold desc="Data Methods">
  SettingsModel({
    this.batch,
    this.branchId,
    this.classNo,
    this.courseNo,
    this.demo,
    this.department,
    this.email,
    this.enquiryId,
    this.image,
    this.number,
    this.orderNo,
    this.receptionNo,
    this.studentId,
    this.token,
    this.tutorNo,
    this.unversityNo,
    this.userId,
    this.version,
    this.versionERP,
    this.wNumber,
  });

  SettingsModel copyWith({
    int? batch,
    String? branchId,
    int? classNo,
    int? courseNo,
    bool? demo,
    List? department,
    String? email,
    int? enquiryId,
    int? image,
    String? number,
    int? orderNo,
    int? receptionNo,
    int? studentId,
    String? token,
    int? tutorNo,
    int? unversityNo,
    int? userId,
    String? version,
    String? versionERP,
    String? wNumber,
  }) {
    return SettingsModel(
      batch: batch ?? this.batch,
      branchId: branchId ?? this.branchId,
      classNo: classNo ?? this.classNo,
      courseNo: courseNo ?? this.courseNo,
      demo: demo ?? this.demo,
      department: department ?? this.department,
      email: email ?? this.email,
      enquiryId: enquiryId ?? this.enquiryId,
      image: image ?? this.image,
      number: number ?? this.number,
      orderNo: orderNo ?? this.orderNo,
      receptionNo: receptionNo ?? this.receptionNo,
      studentId: studentId ?? this.studentId,
      token: token ?? this.token,
      tutorNo: tutorNo ?? this.tutorNo,
      unversityNo: unversityNo ?? this.unversityNo,
      userId: userId ?? this.userId,
      version: version ?? this.version,
      versionERP: versionERP ?? this.versionERP,
      wNumber: wNumber ?? this.wNumber,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'batch': this.batch,
      'branchId': this.branchId,
      'classNo': this.classNo,
      'courseNo': this.courseNo,
      'demo': this.demo,
      'department': this.department,
      'email': this.email,
      'enquiryId': this.enquiryId,
      'image': this.image,
      'number': this.number,
      'orderNo': this.orderNo,
      'receptionNo': this.receptionNo,
      'studentId': this.studentId,
      'token': this.token,
      'tutorNo': this.tutorNo,
      'unversityNo': this.unversityNo,
      'userId': this.userId,
      'version': this.version,
      'versionERP': this.versionERP,
      'wNumber': this.wNumber,
    };
  }

  factory SettingsModel.fromMap(Map<String, dynamic> map) {
    return SettingsModel(
      batch: map['batch'] as int,
      branchId: map['branchId'] as String,
      classNo: map['classNo'] as int,
      courseNo: map['courseNo'] as int,
      demo: map['demo'] as bool,
      department: map['department'] as List,
      email: map['email'] as String,
      enquiryId: map['enquiryId'] as int,
      image: map['image'] as int,
      number: map['number'] as String,
      orderNo: map['orderNo'] as int,
      receptionNo: map['receptionNo'] as int,
      studentId: map['studentId'] as int,
      token: map['token'] as String,
      tutorNo: map['tutorNo'] as int,
      unversityNo: map['unversityNo'] as int,
      userId: map['userId'] as int,
      version: map['version'] as String,
      versionERP: map['versionERP'] as String,
      wNumber: map['wNumber'] as String,
    );
  }

//</editor-fold>
}
