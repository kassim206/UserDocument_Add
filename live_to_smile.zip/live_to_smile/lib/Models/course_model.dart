class CourseType{
  String courseType;
  bool delete;
  String name;
  List search;

//<editor-fold desc="Data Methods">
  CourseType({
   required this.courseType,
    required this.delete,
    required this.name,
    required this.search,
  });



  CourseType copyWith({
    String? courseType,
    bool? delete,
    String? name,
    List? search,
  }) {
    return CourseType(
      courseType: courseType ?? this.courseType,
      delete: delete ?? this.delete,
      name: name ?? this.name,
      search: search ?? this.search,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'courseType': this.courseType,
      'delete': this.delete,
      'name': this.name,
      'search': this.search,
    };
  }

  factory CourseType.fromMap(Map<String, dynamic> map) {
    return CourseType(
      courseType: map['courseType'] as String,
      delete: map['delete'] as bool,
      name: map['name'] as String,
      search: map['search'] as List,
    );
  }

//</editor-fold>
}