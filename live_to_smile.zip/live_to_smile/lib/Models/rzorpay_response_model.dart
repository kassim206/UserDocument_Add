class RzorpayResponseModel{
  String account_id;
  List contains;
  int created_at;
  String entity;
  String event;
  Map payload;
  Map payment;
  Map acquirer_data;

//<editor-fold desc="Data Methods">
  RzorpayResponseModel({
    required this.account_id,
    required this.contains,
    required this.created_at,
    required this.entity,
    required this.event,
    required this.payload,
    required this.payment,
    required this.acquirer_data,
  });


  RzorpayResponseModel copyWith({
    String? account_id,
    List? contains,
    int? created_at,
    String? entity,
    String? event,
    Map? payload,
    Map? payment,
    Map? acquirer_data,
  }) {
    return RzorpayResponseModel(
      account_id: account_id ?? this.account_id,
      contains: contains ?? this.contains,
      created_at: created_at ?? this.created_at,
      entity: entity ?? this.entity,
      event: event ?? this.event,
      payload: payload ?? this.payload,
      payment: payment ?? this.payment,
      acquirer_data: acquirer_data ?? this.acquirer_data,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'account_id': this.account_id,
      'contains': this.contains,
      'created_at': this.created_at,
      'entity': this.entity,
      'event': this.event,
      'payload': this.payload,
      'payment': this.payment,
      'acquirer_data': this.acquirer_data,
    };
  }

  factory RzorpayResponseModel.fromMap(Map<String, dynamic> map) {
    return RzorpayResponseModel(
      account_id: map['account_id'] as String,
      contains: map['contains'] as List,
      created_at: map['created_at'] as int,
      entity: map['entity'] as String,
      event: map['event'] as String,
      payload: map['payload'] as Map,
      payment: map['payment'] as Map,
      acquirer_data: map['acquirer_data'] as Map,
    );
  }

//</editor-fold>
}