import 'package:cloud_firestore/cloud_firestore.dart';

class UsersModel{
  int? age;
  Timestamp created_time;
  String display_name;
  Timestamp? dob;
  String email;
  String password;
  String phoneNo;
  String photo_url;
  String uid;
  String userName;

//<editor-fold desc="Data Methods">
  UsersModel({
    this.age,
    required this.created_time,
    required this.display_name,
     this.dob,
    required this.email,
    required this.password,
    required this.phoneNo,
    required this.photo_url,
    required this.uid,
    required this.userName,
  });


  UsersModel copyWith({
    int? age,
    Timestamp? created_time,
    String? display_name,
    Timestamp? dob,
    String? email,
    String? password,
    String? phoneNo,
    String? photo_url,
    String? uid,
    String? userName,
  }) {
    return UsersModel(
      age: age ?? this.age,
      created_time: created_time ?? this.created_time,
      display_name: display_name ?? this.display_name,
      dob: dob ?? this.dob,
      email: email ?? this.email,
      password: password ?? this.password,
      phoneNo: phoneNo ?? this.phoneNo,
      photo_url: photo_url ?? this.photo_url,
      uid: uid ?? this.uid,
      userName: userName ?? this.userName,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'age': this.age,
      'created_time': this.created_time,
      'display_name': this.display_name,
      'dob': this.dob,
      'email': this.email,
      'password': this.password,
      'phoneNo': this.phoneNo,
      'photo_url': this.photo_url,
      'uid': this.uid,
      'userName': this.userName,
    };
  }

  factory UsersModel.fromMap(Map<String, dynamic> map) {
    print(map['age']);
    return UsersModel(
      age: int.tryParse(map['age'].toString()) ,
      created_time: map['created_time'] ??DateTime.now(),
      display_name: map['display_name'] ??DateTime.now(),
      dob: map['dob'] ??Timestamp.now(),
      email: map['email'] ??"",
      password: map['password'] ??"",
      phoneNo: map['phoneNo'] ??"",
      photo_url: map['photo_url'] ??"",
      uid: map['uid'] ??"",
      userName: map['userName'] ??"",
    );
  }

//</editor-fold>
}