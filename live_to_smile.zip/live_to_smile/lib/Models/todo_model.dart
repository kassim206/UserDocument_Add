class TodoModel{
  DateTime date;
  String eId;
  String email;
  String name;
  String phone;
  int status;
  String userId;

//<editor-fold desc="Data Methods">
  TodoModel({
    required this.date,
    required this.eId,
    required this.email,
    required this.name,
    required this.phone,
    required this.status,
    required this.userId,
  });

  TodoModel copyWith({
    DateTime? date,
    String? eId,
    String? email,
    String? name,
    String? phone,
    int? status,
    String? userId,
  }) {
    return TodoModel(
      date: date ?? this.date,
      eId: eId ?? this.eId,
      email: email ?? this.email,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      status: status ?? this.status,
      userId: userId ?? this.userId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'date': this.date,
      'eId': this.eId,
      'email': this.email,
      'name': this.name,
      'phone': this.phone,
      'status': this.status,
      'userId': this.userId,
    };
  }

  factory TodoModel.fromMap(Map<String, dynamic> map) {
    return TodoModel(
      date: map['date'] as DateTime,
      eId: map['eId'] as String,
      email: map['email'] as String,
      name: map['name'] as String,
      phone: map['phone'] as String,
      status: map['status'] as int,
      userId: map['userId'] as String,
    );
  }

//</editor-fold>
}