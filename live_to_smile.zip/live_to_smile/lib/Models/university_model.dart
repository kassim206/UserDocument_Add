class UniversityModel {
  String address;
  bool available;
  String banner;
  List courseList;
  List courses;
  String email;
  String logo;
  String name;
  List search;
  bool verify;
  String id;

//<editor-fold desc="Data Methods">
  UniversityModel({
    required this.address,
    required this.available,
    required this.banner,
    required this.courseList,
    required this.courses,
    required this.email,
    required this.logo,
    required this.name,
    required this.search,
    required this.verify,
    required this.id,
  });

  UniversityModel copyWith({
    String? address,
    bool? available,
    String? banner,
    List? courseList,
    List? courses,
    String? email,
    String? logo,
    String? name,
    List? search,
    bool? verify,
    String? id,
  }) {
    return UniversityModel(
      address: address ?? this.address,
      available: available ?? this.available,
      banner: banner ?? this.banner,
      courseList: courseList ?? this.courseList,
      courses: courses ?? this.courses,
      email: email ?? this.email,
      logo: logo ?? this.logo,
      name: name ?? this.name,
      search: search ?? this.search,
      verify: verify ?? this.verify,
      id: id??this.id,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'address': this.address,
      'available': this.available,
      'banner': this.banner,
      'courseList': this.courseList,
      'courses': this.courses,
      'email': this.email,
      'logo': this.logo,
      'name': this.name,
      'search': this.search,
      'verify': this.verify,
      "id":this.id,
    };
  }

  factory UniversityModel.fromMap(Map<String, dynamic> map) {
    return UniversityModel(
      address: map['address']  as String,
      available: map['available'] as bool,
      banner: map['banner']  as String,
      courseList: map['courseList'] as List,
      courses: map['courses'] as List,
      email: map['email'] as String,
      logo: map['logo']  as String,
      name: map['name'] as String,
      search: map['search'] as List,
      verify: map['verify'] as bool,
      id: map["id"] ??"",
    );
  }

//</editor-fold>
}
