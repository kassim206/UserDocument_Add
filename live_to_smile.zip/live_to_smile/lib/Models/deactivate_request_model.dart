import 'dart:core';
import 'dart:ffi';


class DeactivateRequest{
  String userId;
  String email;
  String phone;
  int status;
  DateTime? date;

//<editor-fold desc="Data Methods">
  DeactivateRequest({
    required this.userId,
    required this.email,
    required this.phone,
    required this.status,
     this.date,
  });

  DeactivateRequest copyWith({
    String? userId,
    String? email,
    String? phone,
    int? status,
    DateTime? date,
  }) {
    return DeactivateRequest(
      userId: userId ?? this.userId,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      status: status ?? this.status,
      date: date ?? this.date,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': this.userId,
      'email': this.email,
      'phone': this.phone,
      'status': this.status,
      'date': this.date,
    };
  }

  factory DeactivateRequest.fromMap(Map<String, dynamic> map) {
    return DeactivateRequest(
      userId: map['userId'] as String,
      email: map['email'] as String,
      phone: map['phone'] as String,
      status: map['status'] as int,
      date: map['date'] as DateTime,
    );
  }

//</editor-fold>
}