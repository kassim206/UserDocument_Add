
import 'package:flutter/material.dart';
import 'package:live_to_smile/feature/authentication/screen/login_screen.dart';
import 'package:routemaster/routemaster.dart';

import 'bottom_bar/bottomBar.dart';

final loggedOutRoute = RouteMap(routes: {
  '/': (_) => const MaterialPage(child:LoginPage()),
});



final loggedInRoute = RouteMap(routes: {
  '/home/': (_) =>  MaterialPage(child: BottomBar()),
});