import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:live_to_smile/Models/candidates_model.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/core/routing/routing.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:intl/intl.dart';
import '../bottom_bar/bottomBar.dart';
import '../feature/authentication/controller/auth_controller.dart';

class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  UsersModel? user;
  TextEditingController? msg;
  List students = [];
  List tutors = [];
  List chat = [];
  getChat() async {
    FirebaseFirestore.instance
        .collection('class')
        .doc(candidatesModel!.classId)
        .collection('chat')
        .orderBy('time', descending: false)
        .snapshots()
        .listen((event) async {
      chat = await event.docs;

      if (mounted) {
        setState(() {});
      }
    });
  }

  ItemScrollController _scrollController = ItemScrollController();
  final ItemPositionsListener itemPositionsListener =
      ItemPositionsListener.create();
  @override
  void initState() {
    user = ref.read(userProvider);

    getChat();
    msg = TextEditingController();
    students = classMap[candidatesModel!.classId]['students'];
    tutors = classMap[candidatesModel!.classId]['tutors'];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(
              w * 0.05,
              w * 0.05,
              w * 0.02,
              w * 0.05,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: darkT,
                    )),
                SizedBox(
                  width: w * 0.05,
                ),
                Expanded(
                  child: Text(
                    "${ClassIdToName[candidatesModel!.classId]}",
                    style: GoogleFonts.lexend(
                        fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ),
                SizedBox(
                  width: 5,
                ),
                InkWell(
                    onTap: () {
                      classMates();
                    },
                    child: Icon(Icons.more_horiz_outlined))
              ],
            ),
          ),
          chat.length == 0
              ? Expanded(child: Container())
              : Expanded(
                  child: ScrollablePositionedList.builder(
                  itemScrollController: _scrollController,
                  itemPositionsListener: itemPositionsListener,
                  padding: EdgeInsets.only(
                    left: w * 0.025,
                    right: w * 0.025,
                  ),
                  itemCount: chat.length,
                  itemBuilder: (context, index) {
                    DateTime date = chat[index]['time'] == null
                        ? DateTime.now()
                        : chat[index]['time'].toDate();
                    String time = formattedTime(date).toString();
                    return chat[index]['time'] == null
                        ? Container()
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              (index != 0 &&
                                      date.toString().substring(0, 10) !=
                                          chat[(index - 1)]['time']
                                              .toDate()
                                              .toString()
                                              .substring(0, 10))
                                  ? Center(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 5),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color:
                                                  Colors.green.withOpacity(0.5),
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                                top: 5,
                                                bottom: 5,
                                                left: 15,
                                                right: 15),
                                            child: Text(
                                              (date
                                                          .toString()
                                                          .substring(0, 10) ==
                                                      DateTime.now()
                                                          .toString()
                                                          .substring(0, 10))
                                                  ? 'Today'
                                                  : (date.toString().substring(
                                                              0, 10) ==
                                                          DateTime.now()
                                                              .add(Duration(
                                                                  days: -1))
                                                              .toString()
                                                              .substring(0, 10))
                                                      ? 'Yesterday'
                                                      : DateFormat(
                                                              "MMM dd yyyy")
                                                          .format(date),
                                              style: GoogleFonts.lexend(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12,
                                                color: Colors.grey.shade700,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  : index == 0
                                      ? Center(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 5),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.green
                                                      .withOpacity(0.5),
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Padding(
                                                padding: EdgeInsets.only(
                                                    top: 5,
                                                    bottom: 5,
                                                    left: 15,
                                                    right: 15),
                                                child: Text(
                                                  (date.toString().substring(
                                                              0, 10) ==
                                                          DateTime.now()
                                                              .toString()
                                                              .substring(0, 10))
                                                      ? 'Today'
                                                      : (date
                                                                  .toString()
                                                                  .substring(
                                                                      0, 10) ==
                                                              DateTime.now()
                                                                  .add(Duration(
                                                                      days: -1))
                                                                  .toString()
                                                                  .substring(
                                                                      0, 10))
                                                          ? 'Yesterday'
                                                          : DateFormat(
                                                                  "MMM dd yyyy")
                                                              .format(date),
                                                  style: GoogleFonts.lexend(
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 12,
                                                    color: Colors.grey.shade700,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ),
                                          ),
                                        )
                                      : Container(),
                              chat[index]['id'] == user!.uid
                                  ? Padding(
                                      padding: EdgeInsets.only(
                                          bottom: w * 0.03, left: w * 0.125),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                              child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.stretch,
                                            children: [
                                              SizedBox(
                                                height: w * 0.015,
                                              ),
                                              Container(
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    begin: Alignment.topLeft,
                                                    end: Alignment(1, 1),
                                                    colors: <Color>[
                                                      Colors.grey.shade500,
                                                      Colors.grey.shade700,
                                                    ], // Gradient from https://learnui.design/tools/gradient-generator.html
                                                    tileMode: TileMode.mirror,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(10),
                                                    bottomRight:
                                                        Radius.circular(10),
                                                    bottomLeft:
                                                        Radius.circular(10),
                                                  ),
                                                ),
                                                child: Padding(
                                                  padding:
                                                      EdgeInsets.all(w * 0.03),
                                                  child: Text(
                                                    chat[index]['msg'],
                                                    style: GoogleFonts.lexend(
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 14,
                                                        color: Colors.white),
                                                    textAlign: TextAlign.end,
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                height: w * 0.01,
                                              ),
                                              Text(
                                                time.toString(),
                                                style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12,
                                                  color: Colors.grey.shade700,
                                                ),
                                                textAlign: TextAlign.end,
                                              ),
                                            ],
                                          )),
                                          SizedBox(
                                            width: w * 0.025,
                                          ),
                                          chat[index]['photo'] == ""
                                              ? CircleAvatar(
                                                  radius: w * 0.05,
                                                  backgroundImage: AssetImage(
                                                      ('assets/icons/graduation.png')))
                                              : CircleAvatar(
                                                  backgroundImage:
                                                      CachedNetworkImageProvider(
                                                          chat[index]['photo']),
                                                )
                                        ],
                                      ),
                                    )
                                  : Padding(
                                      padding: EdgeInsets.only(
                                          bottom: w * 0.03, right: w * 0.125),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          chat[index]['photo'] == ""
                                              ? CircleAvatar(
                                                  backgroundImage: AssetImage(
                                                      ('assets/icons/graduation.png')))
                                              : CircleAvatar(
                                                  radius: w * 0.05,
                                                  backgroundImage:
                                                      CachedNetworkImageProvider(
                                                          chat[index]['photo']),
                                                ),
                                          SizedBox(
                                            width: w * 0.025,
                                          ),
                                          Expanded(
                                              child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.stretch,
                                            children: [
                                              Text(
                                                chat[index]['name'],
                                                style: GoogleFonts.lexend(
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 13),
                                              ),
                                              SizedBox(
                                                height: w * 0.015,
                                              ),
                                              Container(
                                                decoration: BoxDecoration(
                                                  //color:chat[index]['type']==1? primary.withOpacity(0.5):Colors.grey.shade200,
                                                  gradient: chat[index]
                                                              ['type'] ==
                                                          1
                                                      ? LinearGradient(
                                                          begin:
                                                              Alignment.topLeft,
                                                          end: Alignment(1, 1),
                                                          colors: <Color>[
                                                            Color(0xffFFEC6E),
                                                            Color(0xfffff6b8),
                                                          ], // Gradient from https://learnui.design/tools/gradient-generator.html
                                                          tileMode:
                                                              TileMode.mirror,
                                                        )
                                                      : LinearGradient(
                                                          begin:
                                                              Alignment.topLeft,
                                                          end: Alignment(1, 1),
                                                          colors: <Color>[
                                                            Colors
                                                                .grey.shade400,
                                                            Colors
                                                                .grey.shade100,
                                                          ], // Gradient from https://learnui.design/tools/gradient-generator.html
                                                          tileMode:
                                                              TileMode.mirror,
                                                        ),
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    topRight:
                                                        Radius.circular(10),
                                                    bottomRight:
                                                        Radius.circular(10),
                                                    bottomLeft:
                                                        Radius.circular(10),
                                                  ),
                                                ),
                                                child: Padding(
                                                  padding:
                                                      EdgeInsets.all(w * 0.03),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      // chat[index]['type']==1&&chat[index]['voice_clip']!=''?AudioPlayer(
                                                      //   source: ap.AudioSource.uri(Uri.tryParse(chat[index]['voice_clip'])), onDelete: null,message: true,
                                                      // ):Container(),
                                                      (chat[index]['type'] ==
                                                                  1 &&
                                                              chat[index][
                                                                      'media'] !=
                                                                  '' &&
                                                              chat[index][
                                                                      'voice_clip'] ==
                                                                  '')
                                                          ? CachedNetworkImage(
                                                              imageUrl:
                                                                  chat[index]
                                                                      ['media'])
                                                          : Container(),
                                                      (chat[index]['type'] ==
                                                                  1 &&
                                                              chat[index][
                                                                      'media'] !=
                                                                  '')
                                                          ? SizedBox(
                                                              height: 5,
                                                            )
                                                          : Container(),
                                                      chat[index]['type'] == 0
                                                          ? Text(
                                                              chat[index]
                                                                  ['msg'],
                                                              style: GoogleFonts.lexend(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  fontSize: 14,
                                                                  color: Colors
                                                                      .grey
                                                                      .shade900),
                                                            )
                                                          : chat[index]['type'] ==
                                                                      1 &&
                                                                  chat[index][
                                                                          'voice_clip'] ==
                                                                      ''
                                                              ? Text(
                                                                  chat[index]
                                                                      ['msg'],
                                                                  style: GoogleFonts.lexend(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                      fontSize:
                                                                          14,
                                                                      color: Colors
                                                                          .grey
                                                                          .shade900),
                                                                )
                                                              : Container(),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                height: w * 0.01,
                                              ),
                                              Text(
                                                time.toString(),
                                                style: GoogleFonts.lexend(
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 12,
                                                    color:
                                                        Colors.grey.shade700),
                                              ),
                                            ],
                                          ))
                                        ],
                                      ),
                                    )
                            ],
                          );
                  },
                )),
          Padding(
            padding: EdgeInsets.all(w * 0.05),
            child: Row(
              children: [
                Expanded(
                    child: Container(
                  height: w * 0.13,
                  child: Center(
                    child: TextFormField(
                      keyboardType: TextInputType.multiline,
                      textCapitalization: TextCapitalization.sentences,
                      controller: msg,
                      style: GoogleFonts.lexend(
                          fontSize: 14, color: Colors.grey.shade700),
                      cursorColor: Colors.grey.shade700,
                      decoration: InputDecoration(
                          filled: true,
                          hintText: 'Type here...',
                          hintStyle: GoogleFonts.lexend(
                              fontSize: 14, color: Colors.grey.shade600),
                          fillColor: Colors.grey.shade200,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide:
                                  BorderSide(color: Colors.transparent))),
                    ),
                  ),
                )),
                SizedBox(
                  width: w * 0.025,
                ),
                Bounce(
                  onPressed: () async {
                    FocusManager.instance.primaryFocus?.unfocus();
                    if (msg?.text != '') {
                      await FirebaseFirestore.instance
                          .collection('class')
                          .doc(candidatesModel!.classId)
                          .collection('chat')
                          .add({
                        'type': 0,
                        'name': user!.display_name,
                        'photo': user!.photo_url,
                        'msg': msg?.text,
                        'time': FieldValue.serverTimestamp(),
                        'id': user!.uid,
                      });
                    }
                    msg?.clear();

                    _scrollController.scrollTo(
                        index: chat.length - 1,
                        duration: Duration(seconds: 2),
                        curve: Curves.easeInOutCubic);
                  },
                  duration: Duration(milliseconds: 100),
                  child: Container(
                    height: w * 0.12,
                    width: w * 0.15,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment(0.8, 1),
                          colors: <Color>[
                            Color(0xffFFEC6E),
                            Color(0xffFEDE00),
                          ], // Gradient from https://learnui.design/tools/gradient-generator.html
                          tileMode: TileMode.mirror,
                        ),
                        borderRadius: BorderRadius.circular(30)),
                    child: Center(
                        child: SvgPicture.asset('assets/icons/send.svg')),
                  ),
                )
              ],
            ),
          )
        ],
      )),
    );
  }

  classMates() {
    // YoutubePlayerController _controllerZ;
    // _controllerZ = YoutubePlayerController(
    //
    //   initialVideoId:tutorials['PopUpVideoUrl'] ,
    //   flags: YoutubePlayerFlags(
    //     autoPlay: true,
    //     mute: false,
    //
    //   ),
    // );
    return showModalBottomSheet(
        backgroundColor: Colors.transparent,
        context: context,
        isScrollControlled: true,
        builder: (context) => StatefulBuilder(
              builder: (context, setState) {
                return Container(
                    height: MediaQuery.of(context).size.height * 0.8,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        )),
                    child: Padding(
                      padding: EdgeInsets.all(w * 0.05),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    'Class Members',
                                    style: GoogleFonts.lexend(
                                        fontWeight: FontWeight.w600,
                                        fontSize: w * 0.04),
                                  ),
                                  SizedBox(
                                    width: w * 0.05,
                                  ),
                                  CircleAvatar(
                                    backgroundColor: Colors.black,
                                    radius: w * 0.03,
                                    child: Text(
                                      (students.length + tutors.length)
                                          .toString(),
                                      style: GoogleFonts.lexend(
                                          fontWeight: FontWeight.w600,
                                          fontSize: w * 0.02,
                                          color: white),
                                    ),
                                  ),
                                ],
                              ),
                              Bounce(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                duration: Duration(milliseconds: 100),
                                child: CircleAvatar(
                                    backgroundColor: primary,
                                    radius: w * 0.035,
                                    child: Icon(
                                      Icons.close,
                                      color: Colors.black,
                                      size: w * 0.04,
                                    )),
                              ),
                            ],
                          ),
                          Divider(),
                          Expanded(
                            child: ListView.builder(
                              itemCount: (students.length + tutors.length),
                              itemBuilder: (context, index) {
                                if (index < tutors.length) {
                                  return Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Row(
                                      children: [
                                        tutorMap[tutors[index]]['photo_url'] ==
                                                ""
                                            ? CircleAvatar(
                                                backgroundColor:
                                                    Colors.grey.shade100,
                                                backgroundImage: AssetImage(
                                                    'assets/icons/graduation.png'),
                                              )
                                            : CircleAvatar(
                                                backgroundImage:
                                                    CachedNetworkImageProvider(
                                                        tutorMap[tutors[index]]
                                                            ['photo_url']),
                                              ),
                                        SizedBox(
                                          width: w * 0.05,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '${tutorMap[tutors[index]]['display_name']}',
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w * 0.035,
                                                  color: Colors.grey.shade700),
                                            ),
                                            Text(
                                              'Teacher',
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: w * 0.02,
                                                  color: Colors.grey.shade700),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                }

                                return Padding(
                                  padding: EdgeInsets.only(top: 10),
                                  child: StreamBuilder<DocumentSnapshot>(
                                      stream: FirebaseFirestore.instance
                                          .collection('candidates')
                                          .doc(students[index - tutors.length])
                                          .snapshots(),
                                      builder: (context, snapshot) {
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: CircularProgressIndicator(),
                                          );
                                        }
                                        var data = snapshot.data;
                                        return Row(
                                          children: [
                                            data!['photo'] == ""
                                                ? CircleAvatar(
                                                    backgroundColor:
                                                        Colors.grey.shade100,
                                                    backgroundImage: AssetImage(
                                                        'assets/icons/graduation.png'),
                                                  )
                                                : CircleAvatar(
                                                    backgroundColor:
                                                        Colors.grey.shade100,
                                                    backgroundImage:
                                                        CachedNetworkImageProvider(
                                                            data['photo']),
                                                  ),
                                            SizedBox(
                                              width: w * 0.05,
                                            ),
                                            Text(
                                              user!.display_name ==
                                                      '${data?['name']} ${data?['lastName']}'
                                                  ? 'You'
                                                  : '${data?['name']} ${data?['lastName']}',
                                              style: GoogleFonts.lexend(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w * 0.035,
                                                  color: Colors.grey.shade700),
                                            ),
                                          ],
                                        );
                                      }),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ));
              },
            ));
  }
}

String formattedTime(DateTime dateTime) {
  return DateFormat().add_jm().format(dateTime);
}
