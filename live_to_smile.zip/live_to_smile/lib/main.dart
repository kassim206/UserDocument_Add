import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:live_to_smile/Models/user_model.dart';
import 'package:live_to_smile/bottom_bar/bottomBar.dart';
import 'package:live_to_smile/core/common/error.dart';
import 'package:live_to_smile/core/common/loader.dart';
import 'package:live_to_smile/feature/authentication/controller/auth_controller.dart';
import 'package:live_to_smile/feature/authentication/screen/login_screen.dart';
import 'package:live_to_smile/firebase_options.dart';
import 'feature/Splash/screen/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      name: 'lts-copy',
      options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ProviderScope(child:MyApp()));
}
class MyApp extends ConsumerStatefulWidget {
  const MyApp({super.key});
  @override
  ConsumerState<MyApp> createState() => _MyAppState();
}

class _MyAppState extends ConsumerState<MyApp> {

  UsersModel? usersModel;

  getData(BuildContext context, User? data) {
    // GoogleSignIn().signOut();
    // FirebaseAuth.instance.signOut();
    if (data != null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => BottomBar()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => LoginPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ref.watch(authStateChangeProvider).when(
      data: (data) {
        return MaterialApp(
          home:Splash(),
          title: 'Live to Smile',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            primarySwatch: Colors.blue,
          ),
        );
      },
      error: (error, stackTrace) => ErrorText(error: error.toString()),
      loading: () => const Loader(),
    );
  }
}