const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp(functions.config().firebase);
const db = admin.firestore();
const Razorpay = require("razorpay");
const express = require("express");
const app = express();
app.use(express.json());
exports.sendAdminNotificationFirestore =



exports.razorpay_create_order =
functions.https.onCall(async (data, context) => {
  const instance =
  new Razorpay({key_id: "rzp_live_C190kQus1hA6p6",
    key_secret: "OUikvDm9CsPAJq6LjYaGCIOa"});
  const order=await instance.orders.create(data);
  console.log(order);
  return order;
});

exports.razorpayWebhook=functions.https.onRequest(async ( req, res ) => {
  console.log(req.body);
  const docId=req.body.payload.payment.entity.order_id;
  const paymentId=req.body.payload.payment.entity.id;
  //  const b2b=req.body.payload.payment.entity.notes.b2b;
  //  console.log(b2b);
  const event=req.body.event;
  console.log(event);
  if (event=="payment.captured") {
    const Ref=db.collection("pendingCandidates").doc(docId);
    const settingsRef=db.collection("settings").doc('O0juQP9oPBfxZveBeWzn');
    const data=await Ref.get();
    if (data.exists) {
      const settings=await settingsRef.get();
      const MapData=data.data();
      const feeList=data.get("feeDetails");
      console.log(paymentId);
      feeList[0].paymentId=paymentId;
      const tuitionFee=feeList[0].tuitionFee;
      tuitionFee[0].paymentId=paymentId;
      feeList[0].tuitionFee=tuitionFee;
      const studentId=settings.get('studentId')+1;
      const lid="LTS"
      let result=lid.concat("", studentId)
      console.log('1234567890');
      const classDoc=db.collection("class").doc(MapData.classDoc);
      const enquiryDoc=db.collection("class").doc(MapData.enquiryDoc);
      enquiryDoc.update({"status":1, "studentId":result});
      classDoc.update({"students": admin.firestore.FieldValue.arrayUnion(result)});
      await Ref.update({"studentId":result, "feeDetails":feeList});
      settingsRef.update({"studentId":studentId});
      const Test=db.collection("pendingCandidates").doc(docId);
      const item=await Test.get();
      console.log(item.data());
      await db.collection("candidates").doc(result).set(item.data());
      await db.collection("candidates").doc(result).update({"studentId":result});
      await db.collection("mail").add({
      "date":item.get("date"),
      "html":"<body><p>Hi <var>"+item.get("emailN")+"</var></p><p>Your admission for <var>"+item.get("emailC")+"</var> for the academic year <var>"+item.get("emailI")+"</var> with Live To Smile Digital Academy is successfully registered.</p><p></p><p>Lets do it together.</p><p>Coordinator-<var>"+item.get("emailC")+"</var></p><p></p></body>",
      "emailList":[item.get("email")],
      "status":"Registration successful"
      });
      Test.delete();
    }

  }


  db.collection("rzorpzyResponse").add( req.body );
  res.sendStatus(200);
});

exports.razorpayWeb=functions.https.onRequest(async ( req, res ) => {
  console.log("req.body");
  console.log(req.body);
  const docId=req.body.payload.payment.entity.order_id;
  const paymentId=req.body.payload.payment.entity.id;
  //  const b2b=req.body.payload.payment.entity.notes.b2b;
  //  console.log(b2b);
  const event=req.body.event;
  console.log("live to smile");
  console.log(docId);
  const lid="LTS"
  let result=lid.concat("", event)
  console.log(result);
  if (event=="payment.captured") {
    console.log("working here");
    const Ref=db.collection("pendingPayments").doc(docId);
    const data=await Ref.get();
    if (data.exists) {
      const feeList=data.get("feeDetails");
      console.log(paymentId);
      const tuitionFee=feeList[data.get("yearIndex")].tuitionFee;
      tuitionFee[data.get("feeIndex")].paymentId=paymentId;
      feeList[data.get("yearIndex")].tuitionFee=tuitionFee;
      await Ref.update({"feeDetails":feeList});
      const Test=db.collection("pendingPayments").doc(docId);
      const item=await Test.get();
      console.log(item.data());
      await db.collection("candidates").doc(data.get("studentId")).set(item.data());
//      await db.collection("candidates").doc(data.get("studentId")).update({"feeDetails":feeList});
      await db.collection("mail").add({
      "date":item.get("eDate"),
      "html":"<body><p>Hi <var>"+item.get("eName")+"</var></p><p>Your payment of <var>"+item.get("eAmount")+"</var> towards <var>Bank</var> for <var>"+item.get("eCourse")+"</var> of the academic year <var>"+item.get("eIntake")+"</var> is successfully received. </p><p></p><p></p><p>Coordinator</p><p>(<var>"+item.get("eCourse")+"</var>)</p><p>Live to smile digital academy</p></body>",
      "emailList":[item.get("email")],
      "status":"payment success"
      });
    }

  }


  db.collection("rzorpzyResponse").add( req.body );
  res.sendStatus(200);
});

exports.sendEmailFromWeb =
 functions.firestore.document("/mail/{uid}").onCreate((event, context) =>{
   console.log("==========================================");
   const html =event.data().html;
   const status =event.data().status;
   const emailList =event.data().emailList;
   console.log(" ============ transporter function =====================");
   const nodemailer =require("nodemailer");
   const transporter = nodemailer.createTransport({
     host: "smtp.zoho.com",
     port: 465,
     secure: true,
     ssl: true,
     auth: {
       user: "academy@livetosmile.in",
       pass: "Academy@1234",
     },
   });
   console.log(transporter);
   emailList.forEach(function(element) {
     const rslt = transporter.sendMail({
       from: "academy@livetosmile.in",
       to: element,
       subject: status,
       html: html,
     });
     console.log("**");
     console.log(rslt);
     return rslt;
   });
 });


app.post("/verification", ( req, res ) => {
  console.log("received webhook", req.body );
  db.collection("rzorpzyResponse").add( req.body );

  res.sendStatus(200);
} );
app.listen(9000, ()=>console.log("nodejs server started on port 90000"));